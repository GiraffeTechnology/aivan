# Known gaps and evidence limits

## Confirmed source defects or mismatches
1. **abcdYi entrypoint:** pinned `frontend/src/App.tsx` displays “Platform loading...”. Its local frontend build is not proof that Aivan is wired. Inspect current domain/reverse-proxy routing first; an existing independent myAivan entrypoint may already exist. Do not create a replacement frontend solely from this source observation.
2. **Acceptance shortcut:** `scripts/run_v1_acceptance_apparel_order.py`, Step 19, lines 229–237 directly writes `QC_PENDING` through SQLAlchemy. A PASS from that script cannot prove the natural end-to-end business transition. Do not treat absence of an unauthorized formal-contract gate as the defect.
3. **DB English-policy mismatch:** pinned `src/giraffe_db/db/canonical_language.py`, blob `09318f7e291dfbaa41ce48d30998b09fbe003946`, retains permissive raw/localized/pair exceptions. Prior controlled API reproduction identified `raw_evidence_records.raw_text`, `communication_events.raw_text`, pricing explanation `localized_output_text` under language/trace conditions, and supplier metadata `raw_supplier_comment` with an English pair/provenance. These violate the owner's enterprise/user-profiles-only exemption. Historical open PR27/PR16 use the same validator blob and are not fixes. Reproduce all four cases through the actual configured API and verify no unauthorized text is persisted. External deployed validator configuration could alter actual runtime behavior; source mismatch alone does not prove a current production write succeeds.
4. **English cleanup unfinished:** documentation/source representation work is merged, but business-language runtime/fixtures and compatibility migration remain open.

The exact inspected source URLs, blob SHAs and excerpts are in `evidence/source-excerpts.json`.

## Candidate/CI is not production acceptance
- Aivan PR129: 8 CI jobs and 2 security jobs are successful; fresh job/step metadata is included.
- Previously verified Linux result: 1041 passed, 3 skipped; coverage 82.71%; Gateway harness 30/30. Two live GLTG tests and an optional selected-provider HTTP test are skipped.
- DB cross-repository scanner checkout/scan are visibly skipped when the required token is unavailable. Consumer tests still execute, but that does not establish DB scanner execution.
- Stage 6 has five successful automated preflight runs and explicitly records `production_acceptance=false`.
- Windows 1034 passed/10 skipped and 82.47% coverage are PR-author-reported; Windows raw logs were not independently verified in this handoff. The PR describes eight POSIX skips plus two live GLTG skips. A retained native Windows Semgrep engine failure is not a successful Windows scan.
- Local provider HTTP/restart tests use SQLite. They do not certify CTYun MySQL or whichever deployment engine is actually selected. A seeded order-segment diagnostic is not the complete RFQ workflow.
- Image upload/storage/preview does not claim OCR.
- abcdYi run37101205755 has five successful jobs, but GLTG is mocked in several jobs and five opt-in LLM tests were previously observed skipped. This is not proof of actual live dependencies.
- Prior GLTG cross-repository E2E jobs skipped clone/install/real HTTP checks; a green label must not erase that qualification.

## Public browser observations only
On 2026-10-03 at approximately 17:15–17:17 UTC, two attempts in the cloud browser saw:
- `https://abcdyi.com`: certificate hostname mismatch.
- `https://abcdyi.cn` and `https://myaivan.com`: connection refused.

This is one browser/network vantage point. It is not a worldwide outage diagnosis and does not establish server cause. Do not bypass the certificate warning. Validate DNS, certificate hostname, current routing and approved service ports from authorized operations access.

## Still unverified
Deployed SHA/image digests; existing frontend routes; authenticated public UI workflow; actual DB write/readback/restart and engine migrations; live GLTG/GPM/model/provider/translation; deployed OpenClaw Gateway; tenant isolation/replay behavior in the deployment; actual human confirmation before every commercial send. No claim of successful production deployment or final product acceptance is made.
