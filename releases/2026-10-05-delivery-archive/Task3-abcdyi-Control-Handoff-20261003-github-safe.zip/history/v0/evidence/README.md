# Evidence provenance

- `live-github-checks.json`: direct read-only GitHub PR129 metadata and job/step results obtained approximately 18:26 UTC on 2026-10-03, after the 18:23 snapshot. No PR state was changed. PR text is retained as an author statement; status/steps are separately recorded.
- `source-excerpts.json`: pinned source URLs, blob hashes and line excerpts read approximately 18:27 UTC. These support the frontend placeholder, direct Step19 status write and DB language-exception source findings.
- Other historical merged-change and Linux/test-count evidence is identified as recorded handover evidence; it was not all rerun during packaging.
- Windows counts are PR-reported only. They are not independently certified logs.
- Public browser outcomes are limited observations from 17:15–17:17 UTC, not diagnosis of a global outage or server cause.

Exact current evidence links:
- https://github.com/GiraffeTechnology/aivan/pull/129
- https://github.com/GiraffeTechnology/aivan/actions/runs/37116285915
- https://github.com/GiraffeTechnology/aivan/actions/runs/37116285917
- https://github.com/GiraffeTechnology/abcdYi/actions/runs/37101205755
- https://github.com/GiraffeTechnology/aivan/issues/110 (historical integrated-boundary issue, status not freshly rechecked)
- https://github.com/GiraffeTechnology/GLTG/actions/runs/36891812947/job/110469021615 (historical skipped integration evidence)

A successful job may contain skipped steps. The bundled job detail preserves these. Green CI, author-reported results, source inspection and actual deployed acceptance are different evidence classes.
