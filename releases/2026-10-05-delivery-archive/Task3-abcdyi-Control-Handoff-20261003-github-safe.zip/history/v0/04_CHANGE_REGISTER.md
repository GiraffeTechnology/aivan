# Delivered and outstanding change register

This register covers the Task 3 work represented in the handoff. It is not an assertion that every historical commit in every repository was independently audited. Refer to the linked PRs for complete changed-file diffs.

## Merged PRD/AGENTS/README alignment, 2026-10-02
All seven targets were recorded as merged after exact-head required CI passed; later target-tree and push-CI checks were recorded as successful.

| Repository/target | PR | Merge commit |
|---|---:|---|
| abcdYi/main | [29](https://github.com/GiraffeTechnology/abcdYi/pull/29) | e14330345e1f3d4508c3850f7fe7abdfc0a8a81d |
| aivan/main | [119](https://github.com/GiraffeTechnology/aivan/pull/119) | e27deae15f54416daad7086b8f5efdaf7b4f6d8a |
| aivan/myaivan-web | [120](https://github.com/GiraffeTechnology/aivan/pull/120) | 6858ac5ad0dc068c3b5e9b9b84b50f47cfbd9fc9 |
| GLTG/main | [16](https://github.com/GiraffeTechnology/GLTG/pull/16) | ca8a9141a8ce1a23c380ad846a624fd0ac5341d6 |
| giraffe-db/main | [28](https://github.com/GiraffeTechnology/giraffe-db/pull/28) | 08dc2c0dd1fc48fa2a6beae7fbdc1272941913c9 |
| giraffe-agent/main | [36](https://github.com/GiraffeTechnology/giraffe-agent/pull/36) | 16f6af7d1ba2b398cf1d17954a5afb9e1aea72ce |
| giraffe-language-skill/main | [2](https://github.com/GiraffeTechnology/giraffe-language-skill/pull/2) | 818f41932d0b987a10dc24bd0ea0354138538466 |

An earlier abcdYi [PR28](https://github.com/GiraffeTechnology/abcdYi/pull/28) also rewrote English product/agent documentation. Later owner corrections in PR29 take precedence. The unauthorized formal-contract gate must not be restored from earlier text.

## Approved security CI repair
Aivan [PR121](https://github.com/GiraffeTechnology/aivan/pull/121) (web, recorded short merge 3f0ae67) and [PR122](https://github.com/GiraffeTechnology/aivan/pull/122) (main, recorded short merge 38f0602) were merged. Developer dependencies and unavailable security-service checks were repaired using actual open-source scanning, including offline OSV matching. This is not a claim of equivalence to CodeQL/GHAS. Full merge SHAs for these two historical changes were not retained in this package; resolve them through the PR links rather than guessing.

## Merged English cleanup batches
| Repository/target | PR | Merge commit |
|---|---:|---|
| aivan/main | [123](https://github.com/GiraffeTechnology/aivan/pull/123) | 10bf5b3b4e23dbf2a41a11c0c13d0d15aa6b0540 |
| aivan/myaivan-web | [124](https://github.com/GiraffeTechnology/aivan/pull/124) | 60a4e17586b157c34b5053558b537acc220d7540 |
| giraffe-agent/main | [37](https://github.com/GiraffeTechnology/giraffe-agent/pull/37) | 6acc7d1ad61dbfbcdc41a955d2d454d37d7d0c8b |
| giraffe-language-skill/main | [3](https://github.com/GiraffeTechnology/giraffe-language-skill/pull/3) | db69e07344abc5ab5245df989de66a0adb2818de |
| abcdYi/main | [30](https://github.com/GiraffeTechnology/abcdYi/pull/30) | 75fce92df2ba813ad51327cb9ef46eb99bb02031 |
| giraffe-db/main | [29](https://github.com/GiraffeTechnology/giraffe-db/pull/29) | 8e67161703cbd4087203a5b7225916274f91b47e |
| abcdYi/main | [31](https://github.com/GiraffeTechnology/abcdYi/pull/31) | 5cdc26a444bee4103fd8c69c5540064d1694a845 |
| abcdYi/main | [32](https://github.com/GiraffeTechnology/abcdYi/pull/32) | 25a0c1ea532ca2b205150a4d0ea1978a381ce958 |
| giraffe-agent/main | [38](https://github.com/GiraffeTechnology/giraffe-agent/pull/38) | 248aecc358695b05291d5072e5acd91d4399af67 |
| aivan/main | [125](https://github.com/GiraffeTechnology/aivan/pull/125) | abb08f80d354e694f1e7a7a47306e600b18793cb |
| aivan/myaivan-web | [126](https://github.com/GiraffeTechnology/aivan/pull/126) | 546aeb7e4c593b379b1f787c14e626da973d7a7b |

These batches include documentation, comments/prose and reviewed source-representation work. They did not complete all business fixtures, `*_zh` runtime migration or the DB language-policy fixes. Exact source/hash maintenance must not be described as translating persisted runtime content. Recorded pre/postmerge CI checks passed for these batches; do not generalize that to production acceptance.

## Merged CTYun 443 AGENTS constraint, 2026-10-03
The Task 3 subset is GLTG #18, giraffe-agent #39, giraffe-language-skill #4, abcdYi #33, Aivan #127/main and #128/web, and giraffe-db #30. Exact final commits are in `02_SOURCE_REFS.json`. These were documentation-only, +8/-0 per target, with pre/postmerge verification recorded. They made no server changes. The later owner instruction additionally covers Aliyun SIN and preserving the AIVAN-SIN bridge; do not rely solely on the earlier CTYun-only wording.

## Open frozen candidate: Aivan #129
[PR129](https://github.com/GiraffeTechnology/aivan/pull/129), `ab81668fb1e52460d537baa71ebb93598b3ca583`, targets `myaivan-web` and remains draft/unmerged. The candidate connects the welcome/conversation/draft UI to authenticated persistence, file/image intake, dynamic language translation and manual-copy confirmation. It adds consumer-result integrity checks, GPM quote/price/currency lineage, tenant/actor binding and fail-closed OpenClaw handling. Candidate scope is described in the bundled current PR metadata; deployed behavior remains to be tested.

## Open work retained for abcdyi master control
- Complete English runtime/fixture migration without deleting tests or hiding values through Unicode escaping.
- Correct DB non-English business-persistence exemptions and their permissive regression tests.
- Reconcile DB PR16/PR27, consumer schema/provider contracts and actual deployment engine compatibility.
- Complete real GLTG/GPM/translation/provider/OpenClaw and public UI acceptance using the two approved simulated DBs.
- Verify existing routing to myAivan before deciding whether the abcdYi placeholder is a deployed defect.
- Replace the acceptance script's direct status write with evidence through the genuine business action path; preserve the diagnostic nature of the current script meanwhile.
- Inventory and preserve any remaining expanded-scope artifacts; there is no authority here to delete them.
