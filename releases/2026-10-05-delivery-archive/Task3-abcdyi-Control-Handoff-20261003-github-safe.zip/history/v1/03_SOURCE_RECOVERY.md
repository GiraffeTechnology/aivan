# Source recovery and version discipline

All source repositories are under https://github.com/GiraffeTechnology . Use existing authorized repository access; do not create or share new credentials as part of package recovery.

## Recover a pinned revision
For each repository listed in `02_SOURCE_REFS.json`, clone or use a clean authorized clone, fetch the required branch/PR ref, and inspect the exact 40-character commit. An example for the final merged MyAivan release:

```sh
git clone https://github.com/GiraffeTechnology/aivan.git
cd aivan
git fetch origin myaivan-web
git cat-file -e 4f640f9dbb046a0202d8d31186f506977146dfc0^{commit}
git switch --detach 4f640f9dbb046a0202d8d31186f506977146dfc0
git rev-parse HEAD
git rev-parse HEAD^{tree}
```

Expected tree: `4033edc0fccc4a8883ae07b82e1a3c63e62812cc`.
These are recovery instructions, not commands executed during packaging. Detached checkout avoids silently advancing or overwriting a working branch. Do not apply this over uncommitted work.

## Preserve exact source bytes
Use Git blobs/archives from pinned commits; do not substitute CRLF-converted Windows source archives for exact candidate artifacts. Keep original branch direction. Reconcile shared fixes deliberately rather than merging all of myaivan-web into main.

## Preserved pre-cleanup references
Previously recorded preservation refs:
- GLTG: `preservation/pre-prd-cleanup-2026-10-02-668fe9a9`
- giraffe-db: `preservation/pre-prd-cleanup-2026-10-02-2fdac466`
- giraffe-agent: `preservation/pre-prd-cleanup-2026-10-02-e800fc95`

Confirm their remote existence before relying on them; these refs were not re-fetched during packaging. Never delete them or other frozen scope inventory to make the repository appear complete.

## Full authoritative change history
`04_CHANGE_REGISTER.md` names the delivered work and outstanding work known to this handoff. Git history and each linked PR diff are the authoritative file-by-file records. For a selected preserved base and target, use read-only `git log --oneline BASE..TARGET` and `git diff --name-status BASE TARGET`. Do not assume DB PR16 and PR27 are a linear sequence: the prior audit found divergence with eight unique commits on each side.

A historical nine-target AGENTS/443 evidence archive exists in Library as `ctyun-port-443-agents-sync-20261003.zip`, version 2, SHA256 `14199658a2041d2e8fca83cf5ab2765324d03e136d1f5848d3960490522a5279`, 558683 bytes. It verifies the earlier documentation batch only and is not deployment evidence. The full cross-project archive is not duplicated here unless provided among the authorized original materials.
