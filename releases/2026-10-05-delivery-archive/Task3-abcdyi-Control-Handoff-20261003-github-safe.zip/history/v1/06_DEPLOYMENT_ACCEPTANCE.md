# Deployment and acceptance continuation checklist

Deployment and deployment-acceptance owner: abcdyi master control. Non-deployment code, tests and documentation: Xiong An. Execute only within the owner's existing authorization and approved operational access. This file is a continuation plan, not evidence that any command ran.

## A. Receive and establish the real baseline
- [ ] Acknowledge package receipt separately from product acceptance.
- [ ] Verify all SHA256SUMS; review original materials and authoritative corrections.
- [ ] Obtain the separate operations package using approved access. Do not duplicate secrets into tickets, reports, logs or this archive.
- [ ] Identify actual running host/service, domain route, current SHA/image digest, config source and database/provider for each component. Record references, never credential values.
- [ ] Confirm existing AIVAN-SIN/SSH bridge and TCP443 usage on all CTYun hosts and Aliyun SIN. Preserve it; reuse authorized access rather than rebinding or opening a new listener.
- [ ] Check whether abcdYi currently routes into an existing myAivan frontend. Compare actual UI against the original Welcome/Start Working/conversation/draft requirements.
- [ ] Pin the selected candidate and dependency revisions. Do not silently deploy a branch name that has advanced.

## B. Prepare controlled recovery and deploy
- [ ] Record current release identifiers, service configuration references and a rollback plan using existing supported deployment procedures.
- [ ] Select one of the owner's two approved simulated DB datasets, with isolated tenant/test identifiers; record which one. Real customer data is not required.
- [ ] Verify actual configured provider and engine compatibility, schema/migrations and ability to read/write/restart with retained history. SQLite-only local evidence cannot certify another engine.
- [ ] Reconcile known DB language enforcement and consumer schema contract issues with the implementation owner. Do not label permissive existing tests as policy compliance.
- [ ] Run exact-current-head required CI before any merge. Keep myaivan-web permanent and separate from main. Do not automatically merge PR129 because this package exists.
- [ ] Build from verified exact source bytes using repository instructions, preserve artifact digests, and deploy through existing approved routing. Do not invent deployment commands or ports from examples.
- [ ] Confirm TLS for the real hostname and route; do not bypass browser security warnings.

## C. Complete the real application path
- [ ] Start from the public/approved UI; authenticate a controlled actor and tenant.
- [ ] Submit an inquiry. Exercise English and non-English intake; prove language-skill translation succeeds before business workflow/persistence.
- [ ] Read the inquiry and process state through the selected DB API. Close/reopen the UI and recover from DB, not conversation context.
- [ ] Upload supported text and image files and verify authorized readback/preview. Do not claim OCR unless actually provided by approved scope.
- [ ] Invoke actual GLTG and GPM APIs with the selected model/provider. Record request correlation, quote identity/revision, price/currency, actual supplier-reply lineage and result persistence.
- [ ] Produce and review a quote; progress to order confirmation using genuine UI/API operations. Never directly update a status column as evidence of the business transition.
- [ ] Verify history/process readback after application/provider restart under the approved restart procedure. Record before/after IDs, not secrets.
- [ ] Execute the original applicable five-pass/clean-state checks honestly. Separate full runs from preflight or partial persistence-only diagnostics.

## D. Safety and negative tests
Use controlled test destinations and datasets. Every commercial send still requires its particular human confirmation; this checklist is not blanket permission to send externally.
- [ ] No human approval: verify no API-email, IM or other commercial send occurs.
- [ ] Approve the exact recipient/content version, then verify one controlled send and its audit linkage; changed/stale drafts require fresh approval.
- [ ] Denied approval, dependency error, gateway/transport error and stale/replayed events must not trigger fallback sends.
- [ ] Validate tenant/role boundaries, unauthorized caller rejection and replay/conflict handling.
- [ ] Attempt the four documented non-English business-persistence cases through the deployed API; reject or canonicalize under policy, and verify prohibited text did not land in primary/side/raw/audit storage. Profile exceptions remain allowed.
- [ ] Validate dependency failure and translation-unavailable behavior. HTTP 200 or capability labels alone cannot stand for business success.

## E. Report without overclaiming
Use `07_ACCEPTANCE_MATRIX.json`: exact commit/artifact, URL/service, DB dataset and engine, executed path, correlation/evidence reference, result, skip reason, operator and UTC time. Mark rows PASS, FAIL, BLOCKED or NOT_RUN. Do not erase skips or promote preflight/local mock evidence to full acceptance. Supply remaining defects and next owner. Complete the receipt separately; final acceptance requires evidence for the applicable defined product scope, without invented gates.


## Task 5 continuation supplement

Use `10_TASK5_DEPLOYMENT_REQUIREMENTS.md` and current source refs for the dependency release/migration order, exact version pins, canonical-language failures, recovery/idempotency, message preview/approval and rollback responsibilities. The source fixes listed as merged no longer need to be rediscovered; the unpublished consumer and explicit authorization pending items remain open. Do not change production/network settings merely because this document exists.
