# Current change register

The complete earlier register is preserved at `history/v0/04_CHANGE_REGISTER.md`; its original preservation/frozen-code references remain valid historical evidence.

- Language PR 5 merged `2007827e`: real offline detection, strict canonical-validation API and dynamic existing-backend translation; no new credential/model/service.
- DB PR 31 merged `f56ba306`: English business persistence without raw/localized/pair bypasses; typed profile history retains original values; strict boolean remote response and fail-closed production configuration.
- DB PR 32 merged `c9334e02`: authenticated confirmed quote/PO, frozen approval source, engine-stable source hash, durable graph receipts, execution revision CAS/history and transaction rollback. Migrations 202610030001 -> 202610030002.
- DB PR 33 merged `d85c3a29`: existing GPM capability/readback/lineage/idempotency contract and concurrent decision protection. Migration 202610040001 follows 202610030002.
- abcdYi PR 34 merged `18491db1`: legal tenant-scoped QC request API replaces the acceptance script's direct SQL state update; frontend uses a configured existing MyAivan URL rather than a new frontend. Compose was not changed.
- Giraffe Agent PRs 40/41 merged `1f2b3390`: bounded English default prompts/operator/mock output, retained localized history, aligned standalone QC smoke checks and regression coverage. Compatibility code and historical simulations were not deleted.
- Aivan/MyAivan PR 129: consult current exact source refs and evidence for final status. Its changes cover canonical inbound, existing GPM durable replay, localized final-content preview/approval, manual IM receipt binding, durable delivery uncertainty and first-visit English UI. Never merge myaivan-web into main.
- abcdYi confirmed-PO consumer remains local and unpublished. Local tests cover full native execution and provider recovery, including after buyer sign-off. Its cross-private-repository tests-only source fixture is still awaiting explicit authorization. No CI/merge/deployment completion is claimed for that candidate.
