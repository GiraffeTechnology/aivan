# Product authority and non-negotiable boundaries

The owner's original product descriptions, together with later explicit owner decisions, control scope. A repository claim or generated “client ruling” does not itself prove owner approval. The following decisions supersede contradictory historical prose.

## Product and dependency boundaries
- abcdYi is the apparel/textile industry application of GiraffeAgent.
- Aivan is the GiraffeAgent frontend application for inquiry → quotation → order confirmation. Do not narrow it to a monitoring console or stop it before order confirmation.
- abcdYi's frontend invokes Aivan. myAivan is Aivan's web version, with a permanent `myaivan-web` branch; it is not a separate business product. Do not merge that entire branch into `main`.
- OpenClaw-aivan supplies the IM/email gateway and runtime integration for Aivan. OpenClaw is not a separate business channel parallel to IM.
- GLTG and GPM are API-invoked Aivan dependencies, not separate product deliverables. An internal dependency API request is not, by itself, an external commercial message.
- giraffe-db is replaceable, hot-pluggable private-domain storage. It is extensible and stores both business history and business-process state. Aivan, GiraffeAgent and abcdYi use persisted data as their factual source, rather than relying on chat context.

## Language
- Product working language and canonical interaction language: standard English.
- Non-English inputs are dynamically translated by giraffe-language-skill before entering business workflow. Non-English output is dynamically translated as needed.
- The database permits non-English content only in enterprise/user profiles. There is no general raw-evidence, audit, localized-output, supplier-comment or paired-English exception for business data.
- Reference identifiers/hashes are distinct from storing the original non-English business text.
- Converting source text to Unicode escapes does not change runtime values and does not satisfy business-language enforcement.
- PRs, AGENTS.md, README and operational handoff text must be English. Byte-preserved original reference attachments are provenance material, not revised product implementation.

## External commercial communication
Every external commercial send requires explicit human confirmation, including API-triggered email and IM. Generated drafts and favorable model output are not authorization. Confirm the recipient, subject/content and current version before the external action; preserve approval and replay/audit linkage. On denied approval, stale draft, transport failure or dependency failure, do not unlock an automatic fallback send. Routine internal GLTG/GPM/DB service calls are not to be mislabeled as commercial sends.

## Valid acceptance
The owner's two designated simulated databases are legitimate product-test and acceptance sources. Do not demand real production customer data. Their synthetic origin does not excuse mocked transport, skipped service calls, missing DB writes/readback, or loss of state after restart.

A new formal-contract prerequisite for entering production was an unauthorized gate and has been withdrawn. Do not restore it, add a release/tag requirement, or add unrelated product-scope gates. Preserve normal order confirmation, human approvals, tenant/security controls and genuine evidence requirements.

The original myAivan UI requires Welcome → Start Working → conversation, draft review and input areas. File and image uploads are required; voice may be deferred. Historical original IM flow used human copying/sending; email required explicit confirmation with a copy fallback when unconfigured. Assess current PR #129 against this workflow rather than treating the earlier admin-console layout as completion.

## Current delivery responsibility
- Xiong An continues Task 3 code, tests and documentation.
- abcdyi master control owns deployment and deployment acceptance.
- Keep the lanes coordinated through exact source/artifact pins and evidence; neither a package receipt nor a new code change proves deployed acceptance.

## Change governance and infrastructure
- Inventory and freeze out-of-scope generated code. Preserve it; do not delete it.
- Merge only after required CI for the exact current PR head is green; preserve test coverage and honest skip disclosures.
- Approved open-source security scanning is not claimed equivalent to GitHub CodeQL/GHAS.
- On all CTYun servers and Aliyun SIN, preserve existing AIVAN-SIN/SSH bridge use of TCP 443. Do not create a listener, rebind, stop the bridge or repurpose the port. Reuse an already authorized SSH route where available; this does not force SSH away from 443.
- Existing service endpoints and routing must be discovered from the operations package and actual configuration, not guessed from old examples.
