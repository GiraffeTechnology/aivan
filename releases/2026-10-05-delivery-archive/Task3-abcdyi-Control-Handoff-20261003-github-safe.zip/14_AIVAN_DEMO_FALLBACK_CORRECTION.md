# Local demo supplier fallback correction

PR 131 follows the completed PR 130 review's specific remaining supplier-matching finding. At baseline `7ab322deb6f5f63cf022f43680c747c7ec581f75`, four added regressions failed because the already-gated local/dev fallback returned all demo suppliers after no registry match. Production remote-provider behavior was not affected by that fallback path.

One source line now applies the same requirement filter to the demo catalog. Six cases cover category-only, material-only, no matches, unfiltered demo compatibility, and registry precedence. Local focused checks passed 49 tests; the full suite passed 1,181 with 3 existing optional integration skips and 83.23% coverage. Ruff, affected-source Mypy, Bandit high severity, module budgets and all nine UI runtime scripts passed.

Candidate `807f11d14573490be729f86a8debd4b629a33f28` merged only into `myaivan-web` at `94d4a3f0e163fef023ac0f0ba6b36fd584298bac` with identical tested tree `6364e39a8cd9080c651cab04b100c43b5c5f1648`. Exact-head and post-merge CI/security evidence is in `evidence/PR131_VERIFICATION.json`. Demo fallback remains gated and is not a production private-DB truth source. No deployment, migration, new credential, real commercial send or cross-repository source upload occurred.
