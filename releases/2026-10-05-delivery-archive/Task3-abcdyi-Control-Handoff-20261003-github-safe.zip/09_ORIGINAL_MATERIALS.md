# Original materials

Original task-related owner attachments and reference documents are preserved byte-for-byte under `user-originals/`, with an accompanying source manifest. The four product originals are included. Markdown originals are included just like other formats. Never replace an original with a translation; English operational summaries belong in the handoff documents.

Credential-bearing originals such as private-key files, credential ZIPs, password/API-token files and configuration containing active secrets are excluded. They must be accessed only through their existing authorized source or the separate operations handoff; do not copy or paste their contents here.

Repository source is pinned in `02_SOURCE_REFS.json` and recovered through authorized Git access. This package does not claim to contain complete Git clones or a deployable binary release. `ORIGINAL_ATTACHMENTS.md` and `user-originals/manifest.json` identify all four included originals and the exclusion of credential-bearing originals, whose source inventory belongs to the separate operations package.
