# Aivan final non-deployment candidate

PR: https://github.com/GiraffeTechnology/aivan/pull/129

Frozen head: `c819dd60eec625886a7e6627d300c4ff15ad84a7`.
Parent: `b30e7a3a3c62f891f415efc3f816aee6a016e4e2`.
Tree: `a703c343f0ae7d3182471c622966606b15609194`.
Target: `myaivan-web` only.

All 36 changed blobs were read back from GitHub and match the tested source.
All sibling commits through b30e7a3 are preserved.

Local validation: 1,147 passed, 3 skipped, 83.22% coverage; Ruff, Mypy on
23 safety-boundary files, Bandit high-severity scan, module budgets, diff check
and all nine JavaScript runtime scripts passed. Skips are controlled live
integration tests in the general suite. Separate actual-service verification
passed nine scoped HTTP assertions and two live GLTG contract tests; the verifier
will bind that result to the published scope blobs.

The candidate includes durable GPM replay, actual source-cost advisory input,
English source notes, exact localized commercial preview/approval binding,
non-retryable uncertain delivery with a pre-I/O durable claim, and English
first-visit UI while retaining explicit locale choices.

Translator and outbound sender tests are explicitly synthetic. No commercial
messages were sent. Real translation-model quality, actual configured delivery
providers, browser/device verification and production deployment remain in the
deployment handoff. The finite remaining multilingual source-literal inventory
is separate and does not remove language support.

Exact-head CI is being checked separately before any merge recommendation.

## Security metadata follow-up

Final head `ab5efe0a2be9c3cc1787b0137ad33a06f2d61915`, tree `b5f27652ddd39725a8683fdde0c382d0f1216805`, adds only exact Semgrep rule/path/count/whole-file review metadata for literal source reads in two UI tests. Product and test code remains c819. The c819 main CI passed all eight jobs; its Semgrep gate correctly demanded re-review. New exact-head checks remain required.

## Final remote result

Exact ab5efe0 CI run 37155723668: all eight jobs passed. Security run 37155723646: Semgrep and zizmor passed. All 37 changed remote blobs match the source manifest. The only difference from the independent c819 actual-service attestation is reviewed-findings.json; product source is unchanged. Code is ready for the authorized merge to myaivan-web, subject to the controller final check.
