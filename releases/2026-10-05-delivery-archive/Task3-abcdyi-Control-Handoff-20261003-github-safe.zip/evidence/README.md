# Evidence provenance and current scope

Current implementation results are in `TASK5_VERIFICATION.json`, the Aivan exact-head/post-merge job records, and the version-bound actual HTTP reports/results/source attestations. Product and test source is byte-identical between the final reviewed candidate and merged MyAivan release; the merge retains a different base AGENTS.md. Exact trees and that one-file difference are recorded in `aivan-merge-tree-equivalence.json`.

The nine-check actual GLTG/GPM run and the separate eleven-check graph/restart run are bound to their stated revisions, not silently relabeled as a production run. Tests use explicit synthetic business inputs, real deterministic GLTG and actual dependency transports, with GPM mock-model execution labeled. The English language detector/API is real; synthetic translator output is identified where used. No live customer deployment or external commercial send is certified.

The retained `live-github-checks.json` and `source-excerpts.json` describe the old 18:23-18:27 UTC snapshot. They are historical evidence for defects subsequently repaired and must not override current pins. Original versions of this evidence index and all prior handoff documents remain in `history/v0/`.

## Current verified CI links

- [Aivan final candidate CI](https://github.com/GiraffeTechnology/aivan/actions/runs/37155723668)
- [Aivan final candidate security](https://github.com/GiraffeTechnology/aivan/actions/runs/37155723646)
- [Aivan merged release CI](https://github.com/GiraffeTechnology/aivan/actions/runs/37156007829)
- [Aivan merged release security](https://github.com/GiraffeTechnology/aivan/actions/runs/37156007821)
- [Final DB/GPM merged release CI](https://github.com/GiraffeTechnology/giraffe-db/actions/runs/37153989056)
- [Language merged release CI](https://github.com/GiraffeTechnology/giraffe-language-skill/actions/runs/37152629144)
- [Giraffe Agent merged defaults/smoke CI](https://github.com/GiraffeTechnology/giraffe-agent/actions/runs/37154892764)

A successful workflow may include a conditional skip. Aivan post-merge Dependency Review is skipped on push; its seven applicable CI jobs and two security jobs succeeded. The ordinary local suite's optional service skips are not passes; separately executed actual-service checks are identified distinctly. Historical Windows and Stage 6 preflight reports remain qualified, with production_acceptance=false.

The unpublished consumer and test-only source archives awaiting owner authorization are not presented as uploaded PRs or completed reproducible CI.
