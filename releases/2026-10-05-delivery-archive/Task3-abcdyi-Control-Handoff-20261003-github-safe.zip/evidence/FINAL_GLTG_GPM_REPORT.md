# Final bounded GLTG/GPM compatibility verification

Status: **BOUNDED_PASSED** for the final exact Aivan head and actual dependency APIs. Aivan `c819dd60eec625886a7e6627d300c4ff15ad84a7` has been independently byte-attested: all 182 Python source files plus the two executed integration-test/fixture files match their remote Git blobs. The original nine narrow checks were rerun after synchronizing final changes, with nine passes. No unresolved failure remains in this bounded verification.

## Final narrow run

Final exact-head evidence: `final-verification/run-1zht4ym5/results.json` and the sibling actual service HTTP logs, transparent GPM/provider request capture, and `source-hashes.json`. Byte attestation: `final-verification/final-aivan-exact-head-attestation.json`. The preceding working-snapshot run `run-pjunnqc1` is retained as historical evidence.

**9 of 9 checks passed**, including two genuinely executed live GLTG pytest tests with no skip. The test uses loopback HTTP services, not simulated GLTG/GPM transports.

- Actual deterministic GLTG v2 -> Aivan RFQ DTO -> real provider graph write/readback retains p50=61.0, p80=71.98, p90=82.35.
- Actual Aivan GPM HTTP client -> standalone GPM -> selected DB -> actual canonical-English language service preserves the quote/case/actor, USD price/totals, original model result and GLTG lineage.
- Actual `generate_buyer_options` -> `create_stage1_gpm_guidance` -> GPM/provider succeeds. The generated UI option changes identity on regeneration, while its source quotation reference and persisted GPM packet stay unchanged.
- The internal supplier cost is 1250.0 for 100 units at 12.5 USD even when the buyer-facing option hides supplier costs. The generated advisory note is standard English; source references remain structured.
- Same business input with a new transport trace replays the original packet and original lineage. Changed price under the same idempotency key returns 409. An authenticated different tenant receives 403.
- DB outage fails closed. Restarting both DB and GPM recovers the same persisted packet.
- With the model endpoint changed to a closed loopback port, an already committed request still replays its original packet; a new request returns 503. This proves durable replay does not need a newly available model. No model was installed, started or provisioned.

## Reviewed existing GLTG/graph evidence

Independently inspected the controller's `abcdyi-nondeployment/graph-real-compat/run-_n20tcl9/results.json`, harness and source hashes: **11 of 11 actual-HTTP checks passed**. All recorded source hashes still match the designated source snapshots: GLTG 87 files, Aivan 177, DB 66 and language 53.

That evidence includes real supplier reads, cross-tenant fail-closed behavior, all three fractional quantiles 27.85/32.86/37.6, GLTG self-history write with independent SQL readback, complete Aivan graph replay, DB restart readback and same-event graph replay after restart. The earlier duplicate-graph and language-catalog failures are corrected. These are preserved as separate version-bound results; they are not relabeled as tests of an unseen later Aivan head.

## Version identity

- GLTG: `33730dd10c2788c4eed920181475178280cc6a86`, all 87 Python source blobs verified against remote Git.
- DB final main: `d85c3a29a807b08cfe3962a52b2283ed01586854`, tree `bc650192b741049d3b06d6df67bf7408f164365b`. This is byte-identical to the verified PR 33 tree at `a10294a0d936fb2bd1b4889dfa162be8a188af6a`; all 66 Python source blobs checked.
- Language final main: `2007827e2d34379a85a52d51546358c3771a78cd`, all 53 Python source blobs checked.
- Aivan final PR 129 head: `c819dd60eec625886a7e6627d300c4ff15ad84a7`, tree `a703c343f0ae7d3182471c622966606b15609194`, base `myaivan-web`. Tested immutable local snapshot: `final-verification/aivan-final-c819dd60`. Every one of its 182 remote Python source files and the two executed integration-test/fixture files is Git-blob matched to that final head. The prior working snapshot had a later-changed OpenClaw contract among its imported files; the final remote version was synchronized and the same nine checks rerun, rather than silently relabeling old evidence.

## The former v1 assertion

The old live test expected the retired sum of four supplier stages, 28. Pinned GLTG actually returns 124.0 because v1 now maps graph-engine dates, as documented in `src/gltg/services/engine_adapter.py`. At evaluation date 2026-10-03, p50 is 62 days to earliest delivery, p80 is 90 days to most-likely delivery, and p90/estimated is 124 days to committable delivery. The corrected Aivan test verifies those documented date deltas, ordering, selected supplier and calculation trace, rather than substituting a new unexplained constant. The GLTG algorithm was not changed. Raw original response: `v1-current-engine-response.json`.

## Limits and stop condition

- Synthetic business inputs are explicit. GLTG uses its actual deterministic implementation. GPM uses its existing explicitly identified mock-model mode for initial guidance; no live GPM LLM quality or model availability is claimed.
- SQLite is isolated and schema-created for API verification. No production database, MySQL, deployment or migration acceptance is claimed here.
- No external commercial email/IM, production host access, SSH/network configuration, new credentials or cross-private-repository source upload occurred.
- This is the requested existing dependency/consumer compatibility boundary, not a full product audit or a new dependency roadmap. Final source-byte attestation is complete. Verification is finished; no further audit or monitoring is started.
