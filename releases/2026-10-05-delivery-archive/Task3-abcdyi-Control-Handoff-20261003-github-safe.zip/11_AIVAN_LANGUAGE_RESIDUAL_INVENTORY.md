# Finite English source inventory

Scope: current Aivan candidate based on b30e7a3 plus the reviewed local changes, and the frozen language candidate whose tested tree was merged. This is a literal-source inventory, not a claim that every Unicode character is a language violation.

## Default UI correction

The first-visit locale now defaults to English. The template declares lang=en and ordinary labels use the existing English catalog. Explicit saved locale choices and selector endonyms are preserved. Runtime regressions cover no saved choice, invalid saved choice, Chinese and French saved choices.

## Remaining Aivan literals

No CJK-script text was found in the scanned README, AGENTS or docs. The following paths retain multilingual source literals. Language capability and regression inputs must be preserved; an English-only source representation can use Unicode escapes. This report does not replace the working translation mechanism with keyword detection.

- `src/aivan/agents/clarification_agent.py`: lines 7, 11. Existing localized recipient/operator response or synthetic mock fixture; retain canonical English workflow storage and encode non-English source literals if normalized.
- `src/aivan/agents/requirement_agent.py`: lines 89, 97, 101, 110, 112. Existing multilingual input recognition or controlled label; preserve language coverage, use escaped representation rather than deleting matches.
- `src/aivan/agents/supplier_response_agent.py`: lines 54, 63, 73, 75. Existing multilingual input recognition or controlled label; preserve language coverage, use escaped representation rather than deleting matches.
- `src/aivan/app/static/app.js`: lines 17, 18, 19, 22, 23, 24, 25, 134, 154, 171, 206, 209, 218, 219, 226, 227, 257, 265, 266, 272, 306, 324, 326, 329, 330, 334, 335, 339, 340, 341, 342, 343, 346, 353, 354, 359, 422, 425, 426, 427, 432, 434, 437, 449, 452, 454, 458, 464, 467, 525, 526, 530, 536, 538, 543, 550, 551, 553, 564, 566, 573, 575, 576, 577, 579, 580. Existing localization key/catalog or explicit language label; preserve stable message identifiers and language choices.
- `src/aivan/app/static/i18n.js`: lines 5, 6, 8, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 197, 208, 234, 260, 309. Existing localization key/catalog or explicit language label; preserve stable message identifiers and language choices.
- `src/aivan/app/templates/index.html`: lines 19, 20, 24, 25, 53, 54, 58, 59, 82. Existing localization key/catalog or explicit language label; preserve stable message identifiers and language choices.
- `src/aivan/app/ui_catalog.py`: lines 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170. Existing localization key/catalog or explicit language label; preserve stable message identifiers and language choices.
- `src/aivan/execution/event_interpretation.py`: lines 137, 139, 155, 158, 160, 161. Existing multilingual input recognition or controlled label; preserve language coverage, use escaped representation rather than deleting matches.
- `src/aivan/execution/rfq_execution.py`: lines 485, 486, 498. Existing localized recipient/operator response or synthetic mock fixture; retain canonical English workflow storage and encode non-English source literals if normalized.
- `src/aivan/execution/rfq_user_control.py`: lines 189, 190, 191, 192, 193, 195, 207, 209, 212, 215, 216, 217, 218, 219, 220. Existing multilingual input recognition or controlled label; preserve language coverage, use escaped representation rather than deleting matches.
- `src/aivan/execution/safety.py`: lines 166, 189, 191, 193, 195, 197, 199, 200, 218, 219, 220, 221, 226, 227, 228. Existing multilingual input recognition or controlled label; preserve language coverage, use escaped representation rather than deleting matches.
- `src/aivan/llm/providers/mock_provider.py`: lines 26, 27, 28, 29, 30, 32, 66, 67. Existing localized recipient/operator response or synthetic mock fixture; retain canonical English workflow storage and encode non-English source literals if normalized.
- `src/aivan/rfq/dependency_policy.py`: lines 57, 58, 73, 74, 89, 90, 105, 106, 120, 121. Existing localized recipient/operator response or synthetic mock fixture; retain canonical English workflow storage and encode non-English source literals if normalized.
- `src/aivan/rfq/operator_reply.py`: lines 38, 48, 50, 103, 110, 111, 113, 121, 124, 126, 127, 129, 151. Existing localized recipient/operator response or synthetic mock fixture; retain canonical English workflow storage and encode non-English source literals if normalized.
- `src/aivan/sourcing/marketplaces/search_query_builder.py`: lines 43. Existing multilingual input recognition or controlled label; preserve language coverage, use escaped representation rather than deleting matches.
- `src/aivan/utils/language.py`: lines 6. Existing multilingual input recognition or controlled label; preserve language coverage, use escaped representation rather than deleting matches.
- `scripts/full_business_closure_e2e.py`: lines 80, 91, 92, 93, 94, 95, 381, 394, 425, 454. Multilingual test or smoke input/assertion; preserve semantics, escape literals if source normalization is required.
- `scripts/repro_paris_designated_supplier.py`: lines 51, 62, 63, 64, 65, 66, 67. Multilingual test or smoke input/assertion; preserve semantics, escape literals if source normalization is required.
- `scripts/run_aivan_e2e.py`: lines 62, 63, 64, 92, 93. Multilingual test or smoke input/assertion; preserve semantics, escape literals if source normalization is required.
- `scripts/run_aivan_prod_smoke.py`: lines 94, 116, 128, 135, 173. Multilingual test or smoke input/assertion; preserve semantics, escape literals if source normalization is required.
- `scripts/run_private_domain_rfq_e2e.py`: lines 69, 82, 83. Multilingual test or smoke input/assertion; preserve semantics, escape literals if source normalization is required.
- `tests/myaivan-i18n-runtime.test.mjs`: lines 23, 103, 104, 105, 108, 109, 110, 119, 120, 123, 124, 127, 128, 139, 141, 148, 171, 202, 207, 212, 217, 222, 228. Multilingual test or smoke input/assertion; preserve semantics, escape literals if source normalization is required.
- `tests/myaivan-inquiry-runtime.test.mjs`: lines 69, 81, 96, 109, 123, 139, 205, 206. Multilingual test or smoke input/assertion; preserve semantics, escape literals if source normalization is required.
- `tests/myaivan-message-readback-runtime.test.mjs`: lines 35. Multilingual test or smoke input/assertion; preserve semantics, escape literals if source normalization is required.
- `tests/test_event_adapter.py`: lines 15, 33, 63. Multilingual test or smoke input/assertion; preserve semantics, escape literals if source normalization is required.
- `tests/test_execution_safety_gates.py`: lines 115, 117. Multilingual test or smoke input/assertion; preserve semantics, escape literals if source normalization is required.
- `tests/test_gltg_client.py`: lines 196. Multilingual test or smoke input/assertion; preserve semantics, escape literals if source normalization is required.
- `tests/test_inbound_english_persistence.py`: lines 15, 26, 28, 38, 60, 142. Multilingual test or smoke input/assertion; preserve semantics, escape literals if source normalization is required.
- `tests/test_issue83_session_auth_nonascii.py`: lines 100, 124, 191. Multilingual test or smoke input/assertion; preserve semantics, escape literals if source normalization is required.
- `tests/test_language_normalize_semantics.py`: lines 11, 43. Multilingual test or smoke input/assertion; preserve semantics, escape literals if source normalization is required.
- `tests/test_language_skill_integration.py`: lines 21, 29, 30, 216, 217. Multilingual test or smoke input/assertion; preserve semantics, escape literals if source normalization is required.
- `tests/test_llm_token_guard.py`: lines 165, 171. Multilingual test or smoke input/assertion; preserve semantics, escape literals if source normalization is required.
- `tests/test_myaivan_workbench.py`: lines 229, 230, 234, 235. Multilingual test or smoke input/assertion; preserve semantics, escape literals if source normalization is required.
- `tests/test_no_business_semantic_hardcoding.py`: lines 21, 22, 23, 24. Multilingual test or smoke input/assertion; preserve semantics, escape literals if source normalization is required.
- `tests/test_no_external_model_api_in_private_domain.py`: lines 127, 128, 149, 165. Multilingual test or smoke input/assertion; preserve semantics, escape literals if source normalization is required.
- `tests/test_openclaw_wechat_smoke.py`: lines 83. Multilingual test or smoke input/assertion; preserve semantics, escape literals if source normalization is required.
- `tests/test_operator_reply_renderer.py`: lines 50, 52, 54, 57, 65, 66, 73, 96, 97, 107, 112, 116, 122, 125, 126, 181, 189. Multilingual test or smoke input/assertion; preserve semantics, escape literals if source normalization is required.
- `tests/test_requirement_schema.py`: lines 97, 103, 121, 138. Multilingual test or smoke input/assertion; preserve semantics, escape literals if source normalization is required.
- `tests/test_rfq_execution_iteration.py`: lines 57, 71, 72, 73, 74, 153, 190, 239, 787, 806. Multilingual test or smoke input/assertion; preserve semantics, escape literals if source normalization is required.
- `tests/test_rfq_execution_reliability_e2e.py`: lines 82, 94, 115, 166, 167, 185. Multilingual test or smoke input/assertion; preserve semantics, escape literals if source normalization is required.

## Frozen language tree

The same scan found no literal CJK-script content in its source, tests, scripts, README, AGENTS or docs. Multilingual detector and translation regression inputs are represented with Unicode escapes. Latin-script natural-language fixtures also exist; this scan is not an exhaustive semantic language classifier.

## Limits

New commercial preview, approval binding, delivery-state code and documentation are English. Full repository-wide rewriting of legacy localization keys or multilingual fixtures was not performed in this safety fix. Real model, browser/device and deployment acceptance remain separately documented.
