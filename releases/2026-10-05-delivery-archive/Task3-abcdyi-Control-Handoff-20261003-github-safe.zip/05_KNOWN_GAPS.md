# Current gaps and evidence limits

## Fixed in source; deployment still unverified

The prior frontend placeholder, direct-SQL QC acceptance shortcut and permissive DB business-language exceptions are corrected in the merged versions listed in `02_SOURCE_REFS.json`. The prior defect evidence remains at `history/v0/05_KNOWN_GAPS.md` and the retained `evidence/source-excerpts.json`; it must not be mistaken for the current source verdict.

## Explicitly incomplete non-deployment work

1. The abcdYi confirmed-PO execution consumer is not fully uploaded, has no PR and is not merged. Local evidence: 496 passed / 2 optional skips; 13 actual provider tests; one full actual-language HTTP path through production/QC/cache-loss recovery/shipping/delivery/buyer sign-off and second recovery. Its old provider fixture pin is not claimed as the final merged provider. Exact source-fixture upload authorization remains pending; final pin/reproducible CI/PR/review/merge remain to be done after authorization.
2. Additional private Aivan source-fixture-based GPM CI integration is prepared locally but not uploaded. Existing provider changes and their own CI have merged. The actual HTTP integration was independently executed locally with exact blob attestation; this is distinct from a checked-in cross-repository fixture.
3. Full repository-wide English rewriting is not complete. The bounded inventories distinguish actual defaults, multilingual test/recognition/catalog content, explicit compatibility fields and preserved historical simulations. Unicode escapes do not turn runtime business text into English.

## Retained compatibility paths

Standalone Giraffe Agent reference routes are different from the selected Aivan application entry point. abcdYi also retains mounted legacy demonstration/QC routes; mounted does not mean unreachable. Its role-switching demo writes an English B-side JSON response and process JSONL, while old QC comparison writes bilingual/raw model JSON reports. These are preserved compatibility paths and are not used to claim acceptance of the selected native order/QC workflow. The ordinary native QC path and selected-provider projection use the newer execution models. Details and file identities are in the Task 5 supplement and inventories. No hidden route removal or live network/security change was performed.

## Production and model limits

- Actual running SHA/image, production database engine/provider binding, migrations, public-domain TLS/routing and authenticated deployed UI have not been verified by this task.
- Existing TLS/connection observations in version 0 are historical, vantage-limited observations; they are not a new outage diagnosis. Do not bypass certificate warnings or guess deployment ports.
- Actual dependency HTTP tests use isolated SQLite, the real deterministic GLTG engine, the actual language detector/validator and the existing explicit GPM mock-model mode. Synthetic translator responses are labeled where used. These tests do not certify live LLM quality, MySQL, production deployment or real commercial delivery.
- UI runtime behavior tests passed; Chromium visual/device launch was blocked by the test environment. Do not claim visual/device acceptance.
- All actual commercial sends remain subject to final recipient/content human confirmation. A timeout or missing acknowledgement is delivery-unconfirmed, not permission to repeat the send.
- Historical non-English business records were not deleted or automatically cleaned. New-write/update validation can reject a legacy before-snapshot; authorized canonicalization must retain meaningful history and profile exceptions.

The old Windows report and Stage 6 preflight results are retained as historical evidence, not promoted to current product acceptance. `production_acceptance` remains false.

## Subsequently corrected review findings

PR130 reproduced and fixed the four PR129 review findings on the prior merged source. That changes the version 1 source verdict for these four paths. It does not convert earlier CI into proof that the old defects were absent, nor does it certify production exposure. New evidence includes authenticated participant API negatives and delegated order-confirmation UI behavior. The pending consumer/cross-repository fixture items above remain incomplete.
