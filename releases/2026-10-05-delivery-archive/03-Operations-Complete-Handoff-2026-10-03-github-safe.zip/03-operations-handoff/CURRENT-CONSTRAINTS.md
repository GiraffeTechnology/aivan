# Current Operations Constraints

Effective snapshot: 2026-10-03 UTC. Read these constraints before any archived connection recipe or configuration example.

## Protected bridge

TCP 443 on all CTYun hosts and on the Aliyun Singapore host is reserved for the existing AIVAN-SIN bridge arrangement. Preserve the existing listeners, forwarding, and protocol routing. Do not create a competing listener, rebind the port, replace its ownership, stop the bridge, or restore a historical alternative bridge.

Normal use of an already approved SSH connection is permitted, including an existing SSH-over-443 route. The protected-port rule does not prohibit connecting to an existing SSH service on 443 and does not require inventing a non-443 management port. A connection attempt is different from binding a new listening service.

The user's current direction is to use SSH for CTYun access. The latest user-provided mapping uses `root` for both abcdYi and AIVAN; see [Current SSH mapping](CURRENT-SSH-MAPPING.md). It supersedes the historical abcdYi `dev` account. Neither supplied command includes `-p`; resolve the effective port from existing SSH configuration rather than inferring a listener change. Confirm the actual approved host, account, host fingerprint, route, and existing credentials before connecting. Do not bypass host-key checking or create new credentials as part of this archive handoff.

## Existing server tooling

Prefer the ChatGPT CLI and GitHub CLI already installed on abcdYi once authorized SSH access works. Confirm the actual command names, executable paths, versions, working directory, and current login state on the server. Do not assume a particular CLI binary or treat an old inventory entry as proof of present availability.

Reuse existing authenticated tooling within its approved scope. Do not reinstall tools, generate credentials, export authentication files, or place tokens or private keys in this archive to work around local execution restrictions.

## Before configuration work

1. Inspect the current live state and locate the existing operations directory and log.
2. Record the exact target, current configuration or release, and intended change.
3. Preserve a dated backup and a practical rollback path without copying secrets into ordinary documentation.
4. Use the smallest change needed and preserve the protected bridge.
5. Run the appropriate syntax, local health, public-route, and bridge-continuity checks.
6. Update the operations log after each actual change. Record failures and rollbacks honestly.

Security-sensitive access, credential, firewall, or permission changes may require specific approval. General optimization permission is not approval to create or broaden persistent access.

## Historical instructions that must not be applied automatically

- The August VPN/proxy document's recommendation about adding a new TCP 443 bridge is superseded by the current requirement to preserve existing bridge ownership.
- Historical Nginx, SSLH, TLS, service, port, and DNS examples are evidence to compare with live configuration, not commands to apply blindly.
- Historical credential-rotation and least-privilege-key suggestions remain proposals. No new key or rotation was performed for this handoff.
- Historical verified listener states, CRUD tests, and installed-tool claims require current verification before operational reliance.

## Latest work boundary

The user's latest tasks 4 and 5 continue Xiongan's tasks 1-3 work except deployment, including code, tests, and documentation. Server operations and deployment remain stopped and are handed off to the appropriate ArtFi or abcdYi control operator. This package is documentation-only; it does not authorize resuming SSH, server changes, or deployment during package preparation. Record deployment requirements for the receiving operator, and preserve the earlier log as a chronological record.
