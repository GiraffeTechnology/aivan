# Operations Handoff Package 3

This is the entry point for the operations ZIP, package 3 of the requested three-package handoff. It combines the original 30 operations attachments and relevant non-secret user originals with current constraints, observed differences, credential references, and the operations log. Read [Handoff status](HANDOFF-STATUS.md) first.

Status: prepared locally on 2026-10-03 UTC. Under the latest tasks 4 and 5, Xiongan continues tasks 1-3 work that does not involve deployment. Server operations and deployment are handed off to the ArtFi and abcdYi control operators. SSH client commands were actually attempted, but no server session was established. This archive has not been written to the server, and no server configuration was changed while preparing it.

## Read first

1. [Current constraints](CURRENT-CONSTRAINTS.md) and [current SSH mapping](CURRENT-SSH-MAPPING.md): protect the existing AIVAN-SIN bridge and use the latest user-provided root-account mappings.
2. [Current differences](CURRENT-DIFFERENCES.md): distinguish October observations from the August historical record.
3. [Installation and updates](INSTALL-AND-UPDATE.md): find the existing server operations directory before placing this archive.
4. [Credential references](CREDENTIAL-REFERENCES.md): references only; no private keys or credential values are included.
5. [Operations log](logs/operations.log) and [entry template](templates/operations-log-entry.md): record actual work and verification, including unsuccessful attempts.
6. [Original attachment inventory](ORIGINAL_ATTACHMENTS.md), [controlled credential references](CONTROLLED_CREDENTIAL_REFERENCES.md), and [original-file hashes](USER-ORIGINALS-MANIFEST.json).
7. [Redaction and integrity report](REDACTION-REPORT.md), [provenance](PROVENANCE.json), and [manifest](MANIFEST.json).

## Storage destination

Reuse the server's existing operations directory if one already exists. Otherwise the proposed root-level destination is `/operations`. This means a directory directly beneath `/`, not an assumed `/root/operations` directory. The real destination has not been inspected or confirmed.

The ZIP contains one top-level `03-operations-handoff/` directory. Extract it into a private staging directory first. Do not unpack it blindly over a live operations directory or overwrite an existing log.

## Evidence dates

- The original email was received on 2026-10-03 at 16:43:07 UTC, equivalent to 2026-10-04 at 00:43:07 UTC+08:00.
- The 30 source attachments describe a handoff and server checks dated 2026-08-02, with historical timestamps in Asia/Hong_Kong.
- Their statements such as "verified", "live", and "completed" describe that historical handoff. They are not new October server checks.
- The original files are preserved byte for byte under `originals/2026-08-02-full-handoff/`, including their original language and paths. Their 29 listed SHA-256 values all match the original manifest; that manifest is the thirtieth attachment.
- `CURRENT-STATE.json` provides a machine-readable snapshot. Read the current constraints before using any archived recipe.

## Scope and precedence

Current user directions and the current constraints take precedence over historical recommendations. The broad permission to optimize server configuration does not remove the requirement to preserve the bridge, use authorized access, verify changes, and update the operations log. Historical suggestions to create credentials or new bridges are not current approval to do so.

This is a private infrastructure archive. It includes host addresses, internal topology, and credential locations. Keep it access-restricted and outside web document roots. Do not publish it to GitHub or send it to third parties.

## What is not included

No private-key files, sensitive key ZIP, production credential files, credential values, authentication stores, or executable deployment scripts are included. Sensitive supplied originals are listed by identifier and filename for separate owner-controlled handoff. Newly written Markdown is English; non-English source originals remain in their original language and are not being published to GitHub.

No application deployment, bridge change, DNS change, new credential, or server-side optimization was performed by creating this archive.
