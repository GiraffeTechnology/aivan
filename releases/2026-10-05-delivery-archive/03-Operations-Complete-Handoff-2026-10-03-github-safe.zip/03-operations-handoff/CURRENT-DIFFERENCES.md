# Current Differences and Pending Verification

Snapshot date: 2026-10-03 UTC. These observations were reported from the current read-only checks. No server deployment or configuration change was performed for this archive. The August source files remain unchanged as historical evidence.

## Access to CTYun abcdYi

An earlier cloud Linux shell attempt to the existing SSH endpoint `CONFIGURE_HOST:443` did not establish TCP or reach SSH authentication. Later, at approximately 18:20 UTC, SSH client commands were actually executed for abcdYi, AIVAN, and Aliyun-SIN using the specified PEM files and default port 22. No server session or authentication was established because outbound connectivity was blocked by the execution environment. These results do not establish that the servers are offline. See [Handoff status](HANDOFF-STATUS.md) for the explicit-client configuration detail and current work boundary.

The user's direction is to use CTYun SSH and prefer the existing server ChatGPT CLI and GitHub CLI. At approximately 17:55 UTC, the user supplied current `root` SSH mappings for abcdYi and AIVAN; [Current SSH mapping](CURRENT-SSH-MAPPING.md) records the exact commands and key references. No explicit port was provided, so this does not establish a port change. Actual binary paths, versions, login state, repository paths, and current server configuration have not yet been checked.

## ArtFi and ArtCCH

Current browser observation: `https://io.artcch.com/` opens the three existing sections. The NFT edition, RWA market plus token, fraction market plus token, and DAO destinations were not configured in the observed entry point. This is a report of the visible entry configuration, not a claim that those products have been built or deployed.

The Xiongan Wallet entry repair is in [ArtFi PR 139](https://github.com/GiraffeTechnology/ArtFi/pull/139), merged to `main` at `033dba4ff8a89e23e70f750625c0994b7d69c5bc`.

- Tested PR head: `6a50ce1b0851c8482860571b2f7363f242bc6369`.
- All eight PR checks passed in [run 37140462413](https://github.com/GiraffeTechnology/ArtFi/actions/runs/37140462413).
- Merged tree: `6f049dc17c61ae10e55def4b82b69e51b91c0511`, reported identical to the tested tree.
- Post-merge CI: all eight checks completed successfully for the merged main revision in [run 37141024602](https://github.com/GiraffeTechnology/ArtFi/actions/runs/37141024602), independently checked during the current task.
- Deployment and public entry acceptance remain pending. A merged PR and green code checks do not prove that the public server is running that revision.

Do not expand product scope while deploying the approved entry repair.

## Xiongan Wallet

- `https://xiongan.8415wallet.com/web/index.html` was accessible from the cloud browser.
- `https://xiongan.8415wallet.com/` redirected to `https://xiongan.8415wallet.com:9444/web/index.html` and then returned 502.
- The apex URL `https://8415wallet.com/` was not tested; no failure is asserted for it.
- Current deployment branch reference: Wallet `deploy/xiongan-sin`, commit `1ccafcdd769e9c41e3531876ace1b9714fdc932b`.
- The deployed server commit was not independently read through SSH during this archive preparation.
- `8415wallet.com` is managed at Xinnet, according to the current user-provided domain information. No DNS change was made.

Check the host-specific redirect and reverse-proxy mapping without modifying the protected 443 bridge. Do not expose an internal backend port as a workaround.

## abcdYi and MyAIVAN public entry checks

The cloud browser checked these public URLs on 2026-10-03 at approximately 17:15-17:17 UTC and repeated each once:

- `https://abcdyi.com/`: the browser environment returned 502 with `Certificate verify failed: hostname mismatch`.
- `https://abcdyi.cn/`: the browser environment returned 502 with `[Errno 111] Connection refused`.
- `https://myaivan.com/`: the browser environment returned 502 with `[Errno 111] Connection refused`.

These results establish failed access from that cloud-browser path. They do not prove worldwide downtime or identify the underlying server cause. Certificate checks were not bypassed.

The actual deployed versions, domain-to-service routing, abcdYi-to-MyAIVAN integration, full business workflow, and persistence against the specified simulated database were not accepted from these failed public-entry checks.

## Before marking deployment complete

1. Establish the existing authorized SSH route without changing its listener or bridge.
2. Find and reuse the server operations directory and existing log.
3. Verify live routing, host-specific certificate coverage, actual service ports, deployment paths, and deployed commits.
4. Back up the affected release and configuration before a bounded change.
5. Apply only the approved repair, preserve the protected bridge, and test local and public paths.
6. Record results, failures, any rollback, and remaining acceptance work in the operations log.

## Production responsibility and authorization update

At approximately 18:00 UTC on 2026-10-03, the user assigned Xiongan to complete the production configuration, deployment, and acceptance for tasks 1 through 3 as already defined in the conversation. This records authorized work and responsibility; it is not a completion claim.

Completed work recorded separately: ArtFi PR 139 is merged, its eight PR checks and eight post-merge checks passed, and this operations archive and current SSH mapping have been prepared. Server-side production configuration, deployment, and acceptance for tasks 1 through 3 remain blocked because an authorized working server session has not been established. No server files or configuration were changed.

Aliyun Singapore access is authorized, but login and root-account verification have not succeeded. The recorded access failure occurred at the network layer before authentication. The latest credential attachment contains client-key material only and no `known_hosts`; it does not establish the server host fingerprint and is not included in this archive. Existing bridge constraints continue to apply.

## Transition to handoff

The user subsequently stopped engineering execution and requested three complete ZIP packages. This operations package records the current evidence and pending acceptance. Building it performs no further SSH, server, or code change and does not submit a task to the original control conversations.

## Task 4 direction at the time

The latest user direction resumes Xiongan's task 1-2 work except deployment. Server operations and deployment remain stopped and are handed off, with deployment requirements documented in the receiving packages. Task 3 remains a handoff. This operations package performs no server or code change. Earlier stop/handoff log entries remain historical; this latest direction supersedes their broader work boundary.

## Latest Task 5 Direction

The latest task 5 extends the same boundary to task 3: Xiongan continues its remaining code, tests, and documentation, excluding deployment. Together with task 4, non-deployment work on tasks 1-3 continues. Server operations and deployment remain handed off to the relevant ArtFi or abcdYi control operator, and deployment requirements must be in the receiving packages. This operations ZIP does not execute code or server changes. Production acceptance remains pending.
