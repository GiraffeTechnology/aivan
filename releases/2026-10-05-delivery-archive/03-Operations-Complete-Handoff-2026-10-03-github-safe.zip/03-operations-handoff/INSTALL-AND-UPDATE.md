# Install and Maintain the Operations Archive

This is a handoff checklist, not a claim of server installation. No automatic installer or deployment script is supplied.

## Establish access

Use the existing approved CTYun SSH route and the latest [user-provided SSH mapping](CURRENT-SSH-MAPPING.md). The current abcdYi account is `root`, overriding the historical `dev` entry. Resolve the port from existing SSH configuration; no listener change is implied by the commands without `-p`. An already configured 443 SSH connection is valid; do not create a listener or alter the bridge to obtain access. Verify the server identity against a trusted host fingerprint. Do not disable host-key verification.

An earlier attempt to `CONFIGURE_HOST:443` did not establish TCP. At approximately 18:20 UTC, explicit SSH client attempts to abcdYi, AIVAN, and Aliyun-SIN on default port 22 also failed to establish sessions or authentication because the execution environment blocked outbound connectivity. The SSH clients were actually executed; no remote commands ran. See `HANDOFF-STATUS.md`. This operations-package task is documentation preparation only. Under the latest tasks 4 and 5, non-deployment work on tasks 1-3 continues separately; server operations and deployment are handed off to the appropriate ArtFi or abcdYi control operator.

## Locate the destination

1. Inspect the existing server documentation and operations directories through the authorized SSH session.
2. Reuse an existing operations directory and its established entry point and log. Do not create a parallel archive solely because the proposed name differs.
3. If no existing directory is appropriate, use `/operations` as the proposed location and verify that it is outside every served web root.
4. Use the existing restricted ownership and access policy. Do not broaden file access. Record the actual canonical path in the entry point after placement.

## Stage and verify

1. Transfer only this secret-free archive through the approved route. Keep key material separate.
2. Compare the archive's SHA-256 with the value supplied alongside the deliverable.
3. Extract into a private staging location. The archive has one `operations/` root and contains only regular documentation files and directories.
4. From the staged `03-operations-handoff/` directory, run `sha256sum -c MANIFEST.sha256` or an equivalent SHA-256 verification tool.
5. Compare the destination's current README, log, and documentation with the staged files. Preserve all existing content, version history, and permissions.
6. Merge the original-history directory without overwriting newer versions. Adapt the entry point to the chosen existing directory rather than duplicating it.
7. Append an actual archive-placement event to the existing log. Do not replace the log with the template or imply that local preparation was a server change.
8. Re-read the installed entry point and verify the final hashes and access restrictions. Only then record server placement as complete.

## Subsequent configuration changes

For every actual change, record UTC time, operator, target, reason, before and after state, release or commit, backup location, commands with secrets removed, validation results, rollback result, and outstanding issues. Update the relevant current-state documents after verification.

Use the existing server ChatGPT CLI and GitHub CLI where appropriate after confirming their paths and versions. The archive does not authorize a product expansion or substitute a green code check for deployment acceptance.

If a verification step fails, preserve evidence and record the failure. Do not label the change complete while deployment, public-route acceptance, or bridge continuity remains unverified.
