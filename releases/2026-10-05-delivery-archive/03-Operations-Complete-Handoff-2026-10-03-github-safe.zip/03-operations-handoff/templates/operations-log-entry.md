# Operations Log Entry Template

Copy this structure into the established operations log for a real event. Replace every placeholder and remove inapplicable fields. Do not write credential values.

- Event ID: <unique identifier>
- Started at UTC: <ISO 8601 timestamp>
- Completed at UTC: <ISO 8601 timestamp or pending>
- Operator: <person or authorized tool>
- Scope: <local preparation, read-only check, file placement, configuration change, deployment, or rollback>
- Target host and canonical path: <verified target>
- Authorization and purpose: <approved action and bounded reason>
- Before state: <configuration identifier, release, commit, and non-secret checksum>
- Backup and rollback reference: <restricted location; no secret content>
- Actions actually performed: <ordered, sanitized actions>
- After state: <observed result; do not infer success>
- Validation: <check, exact result, timestamp, and evidence reference>
- Existing AIVAN-SIN bridge continuity: <verified result or not checked>
- Credential handling: <references only; no values>
- Rollback: <not needed, completed with validation, pending, or failed>
- Outcome: <completed, failed, blocked, or pending validation>
- Remaining work: <specific next step and dependency>

For an unsuccessful connection, state whether TCP, SSH handshake, and authentication occurred. For a local preparation event, explicitly state that the server was not changed.
