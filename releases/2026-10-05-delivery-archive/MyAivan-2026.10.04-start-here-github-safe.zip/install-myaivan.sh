#!/bin/sh
# Reassemble verified transport pieces, then run the unchanged prebuilt installer.
# No source code build, package download or separate provider setup is performed.
set -eu
umask 077
script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$script_dir"
fail() { printf '%s\n' "$*" >&2; exit 1; }
command -v sha256sum >/dev/null 2>&1 || fail 'sha256sum is required.'
verify_part() {
    [ -f "$1" ] && [ ! -L "$1" ] || fail "Missing or unsafe part: $1. Extract all fourteen runtime part ZIPs into this folder."
    printf '%s  %s\n' "$2" "$1" | sha256sum --check --status || fail "Corrupt part: $1. Download and extract that part again. Nothing was installed."
}
verify_part 'myaivan-2026.10.04-42d84a84-linux-x86_64.run.part01' 'd2378f662a7310904f84035d618d117d6ba0b5cfdfd75b2a34829fc354ff3c82'
verify_part 'myaivan-2026.10.04-42d84a84-linux-x86_64.run.part02' 'bb6fd7770e5fe5115679b312f52014a44e241b8e3d891cdc928882d57c76a381'
verify_part 'myaivan-2026.10.04-42d84a84-linux-x86_64.run.part03' '0b4066d9f6b46ac3b521c537ad97f3b4dcf3da5d84bc99135deb8e2d07eaefd0'
verify_part 'myaivan-2026.10.04-42d84a84-linux-x86_64.run.part04' '83169de9c24a4fbe78e86e7bb20f02723024cff28ff733625d0f4f3e19d982b9'
verify_part 'myaivan-2026.10.04-42d84a84-linux-x86_64.run.part05' '6dbd72e72ffa37fe0a5f021de37948f212c52e8ede0d23bb647f66177955f8bb'
verify_part 'myaivan-2026.10.04-42d84a84-linux-x86_64.run.part06' '3826bdf43835767c353877e1867f122af87a5b27f3410a6e8793c962fc323ee5'
verify_part 'myaivan-2026.10.04-42d84a84-linux-x86_64.run.part07' 'c831c7f314464be5373ad58d313c75ea122863b9192d7fff64e85418f4c3b155'
verify_part 'myaivan-2026.10.04-42d84a84-linux-x86_64.run.part08' 'f834b3c7d3def173e8ddd8fcf25df3793d79ceb381557f33e20b79e5013fd25d'
verify_part 'myaivan-2026.10.04-42d84a84-linux-x86_64.run.part09' '442e90b2b54aabe363cf73062c5654de68500922fc80ef3a78618d4fc9eabe32'
verify_part 'myaivan-2026.10.04-42d84a84-linux-x86_64.run.part10' 'a8e4e6ea976a5e5b688aa6f84803638b34d22e9341bdb891c630a2437e8d5aac'
verify_part 'myaivan-2026.10.04-42d84a84-linux-x86_64.run.part11' '15b77d0697efb9ac01762bfc113075f2afe39e21b717b05bbbda981c4431a529'
verify_part 'myaivan-2026.10.04-42d84a84-linux-x86_64.run.part12' 'e788102be6273a18e3ed72635f28492a9607b51bae73e3d9c8fcf49f0c8e5368'
verify_part 'myaivan-2026.10.04-42d84a84-linux-x86_64.run.part13' '86312b5a3436481d7651cd19fffaac21f49b72e70188d7785c8ceac0687dfe6b'
verify_part 'myaivan-2026.10.04-42d84a84-linux-x86_64.run.part14' 'd71dd988b16eb6018089a143df85b333caec34b9d0fa214c4516c84d6142ba25'
output='myaivan-2026.10.04-42d84a84-linux-x86_64.run'
expected='76046b061bebd51a030d5c51425d897bde11bf05777df216a8afe5dffbf833be'
[ ! -L "$output" ] || fail 'Refusing to replace an installer symlink.'
if [ -e "$output" ]; then
    [ -f "$output" ] || fail 'The output path is not a regular file.'
    printf '%s  %s\n' "$expected" "$output" | sha256sum --check --status || fail 'An existing installer has the wrong hash. Move it aside before retrying.'
else
    temporary=$(mktemp './.myaivan-assemble.XXXXXX')
    trap 'rm -f "$temporary"' EXIT HUP INT TERM
    cat \
        'myaivan-2026.10.04-42d84a84-linux-x86_64.run.part01' \
        'myaivan-2026.10.04-42d84a84-linux-x86_64.run.part02' \
        'myaivan-2026.10.04-42d84a84-linux-x86_64.run.part03' \
        'myaivan-2026.10.04-42d84a84-linux-x86_64.run.part04' \
        'myaivan-2026.10.04-42d84a84-linux-x86_64.run.part05' \
        'myaivan-2026.10.04-42d84a84-linux-x86_64.run.part06' \
        'myaivan-2026.10.04-42d84a84-linux-x86_64.run.part07' \
        'myaivan-2026.10.04-42d84a84-linux-x86_64.run.part08' \
        'myaivan-2026.10.04-42d84a84-linux-x86_64.run.part09' \
        'myaivan-2026.10.04-42d84a84-linux-x86_64.run.part10' \
        'myaivan-2026.10.04-42d84a84-linux-x86_64.run.part11' \
        'myaivan-2026.10.04-42d84a84-linux-x86_64.run.part12' \
        'myaivan-2026.10.04-42d84a84-linux-x86_64.run.part13' \
        'myaivan-2026.10.04-42d84a84-linux-x86_64.run.part14' > "$temporary"
    printf '%s  %s\n' "$expected" "$temporary" | sha256sum --check --status || fail 'Installer checksum mismatch. Nothing was installed.'
    mv -- "$temporary" "$output"
    trap - EXIT HUP INT TERM
fi
printf '%s\n' 'Verified the original MyAivan installer; no source build was performed.'
if [ "${1-}" = '--assemble-only' ]; then
    [ "$#" -eq 1 ] || fail '--assemble-only cannot be combined with installation arguments.'
    printf '%s\n' "$script_dir/$output"
    exit 0
fi
exec sh "./$output" "$@"
