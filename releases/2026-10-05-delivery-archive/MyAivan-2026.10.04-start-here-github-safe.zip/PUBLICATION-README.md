# English GitHub publication copy

Source archive: MyAivan-2026.10.04-start-here.zip
Source SHA-256: e4346c8b70dfae80a7914e8de7ba1417abd3afd86a45b74cb0b3717998a097f3

This is an explicitly sanitized publication copy. It is not byte-identical to the owner-only original. Private operations attachments and non-English delivery documents are listed in PUBLICATION-EXCLUSIONS.json. Application localization, token metadata and non-English test fixtures are preserved. Existing English installation guidance remains authoritative. CONFIGURE_HOST values require an owner-supplied deployment target.

Status: local verified candidate or superseded historical delivery, as recorded by its original evidence. Mirroring does not establish production deployment, completed GitHub CI, independent security review, or release readiness. Original test/verification receipts are historical evidence and were not rerun for this packaging pass. Source and dependency code are not reimplemented.

Use PUBLICATION-SHA256SUMS to verify this exact copy. Earlier signed or historical manifests may describe the original build; changed checksum lists and package manifests have been refreshed where applicable. Owner-only originals remain the source of omitted historical documents.
