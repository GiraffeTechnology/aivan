# Repository Instructions

## Authority and scope

Follow the user's original product definitions and latest explicit instructions.
The current language and database boundaries are stated in `README.md` and
`docs/INTEGRATION_AIVAN_ABCDYI_GIRAFFE_AGENT.md`. Existing documentation or
implementation behavior does not override those requirements. Do not invent
product permissions, approval gates, or new architecture to resolve a wording
conflict.

This repository owns the shared language boundary: dynamic translation of
non-English input into canonical English before product workflow, and rendering
of requested non-English output after the English workflow. It does not own
product business decisions or persistence. AIVAN, abcdYi, and giraffe-agent rely
on dynamic private DB history and recorded process facts, not chat context, as
their business source of truth.

## Language and data

- Keep current tracked repository content and new GitHub text in English. Do not
  rewrite Git history to apply this requirement.
- English is the internal working and product-to-product interaction language.
- Except for enterprise and user profiles, databases must not store non-English
  business text. Raw-text, audit, and evidence fields are not alternate storage
  paths for it.
- Preserve temporary original-language input, spans, and translation diagnostics
  inside the language module. They are not downstream business truth.
- Keep designated simDBs valid for acceptance; do not introduce a requirement
  that acceptance use production data.

## Current documentation-only work

Keep this phase limited to documentation. Do not resume paused product
development or change engines, translation or extraction rules, runtime
behavior, API/schema fields, multilingual glossary data, or fixtures in this PR.
Do not remove internal raw-span diagnostics to satisfy repository language
requirements.

The already requested repository-wide English conversion remains outstanding
for source, scripts, functional glossary data, and multilingual tests/fixtures
outside this documentation scope. Functional language data is not a permanent
exception: handle its representation or migration in a separate controlled pass
that preserves translation semantics and code behavior. Do not substitute
English literals where doing so would break multilingual processing. This
staging does not add a new authorization requirement or resume paused original
product work.

Distinguish required product boundaries from verified runtime behavior. In
particular, documenting fail-closed handling for non-English input does not mean
the existing provider fallback or product adapters have been fixed. Preserve
their accurate descriptions and report implementation gaps without silently
changing them. Verify documentation diffs and do not claim runtime tests or
enforcement that were not checked.

## CTYun TCP port 443 reservation

On CTYun hosts, TCP port 443 is reserved for SSH. Do not configure HTTP, HTTPS, web servers, reverse proxies, or TLS listeners to bind to TCP port 443. Do not stop, rebind, replace, or otherwise disrupt SSH to free that port.

Before selecting a web or bridge port, inspect the existing deployment and operations configuration and reuse an explicitly confirmed allocation. Do not guess a replacement port. If the allocation is unclear, report the missing configuration rather than changing a service binding.

This constraint applies only to CTYun hosts; do not extend it to SIN or other environments without an explicit instruction. Recording this rule does not authorize server access or changes to SSH, firewalls, credentials, network settings, or security settings.
