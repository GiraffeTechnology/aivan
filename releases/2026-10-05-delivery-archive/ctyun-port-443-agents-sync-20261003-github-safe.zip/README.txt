CTYun TCP port 443 SSH reservation documentation sync: COMPLETE

All nine PRs were merged after the release owner independently verified exact-head CI. Eight PRs target main; Aivan web targets only the permanent myaivan-web branch. Every target branch was read back and its AGENTS.md exactly matches the reviewed candidate. Every merge commit tree SHA exactly matches the tested candidate tree.

Each update appends the same eight-line English section to the existing AGENTS.md and preserves all prior bytes. No other file changed. No server access, runtime, SSH, firewall, credential, network, or security changes were performed.

All pre-merge and post-merge workflow runs succeeded. Aivan main and myaivan-web Dependency review is pull_request-only: it succeeded before merge and is skipped by the unchanged workflow condition for push events. This is an existing event-specific condition, not a bypass or claim that the skipped job ran.

manifest.json is the concise final index: exact base/head/blob/tree/merge identities, confirmed PR URLs, and CI run/check evidence. Before/after files and unified patches are in targets/. final-state.json is the final detailed API snapshot. Other state files preserve historical snapshots, including earlier pending CI status, and should not be mistaken for final status.
