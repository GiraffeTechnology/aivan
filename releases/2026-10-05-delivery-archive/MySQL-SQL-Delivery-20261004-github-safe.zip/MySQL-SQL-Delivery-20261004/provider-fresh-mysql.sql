-- Fresh provider schema only. Choose an empty, approved MySQL database before execution.
-- MySQL DDL implicitly commits. This script does not select/create a database or alter credentials.
CREATE TABLE actors (
	actor_type VARCHAR(64) NOT NULL, 
	display_name VARCHAR(255) NOT NULL, 
	id VARCHAR(36) NOT NULL, 
	tenant_id VARCHAR(36), 
	visibility VARCHAR(64) NOT NULL, 
	source_type VARCHAR(64), 
	created_by VARCHAR(128), 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE approval_requests (
	decision_packet_id VARCHAR(36), 
	status VARCHAR(64) NOT NULL, 
	payload JSON NOT NULL, 
	id VARCHAR(36) NOT NULL, 
	tenant_id VARCHAR(36), 
	visibility VARCHAR(64) NOT NULL, 
	source_type VARCHAR(64), 
	created_by VARCHAR(128), 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE audit_logs (
	event_type VARCHAR(128) NOT NULL, 
	payload JSON NOT NULL, 
	id VARCHAR(36) NOT NULL, 
	tenant_id VARCHAR(36), 
	visibility VARCHAR(64) NOT NULL, 
	source_type VARCHAR(64), 
	created_by VARCHAR(128), 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE audit_records (
	receipt_operation VARCHAR(64), 
	idempotency_key VARCHAR(255), 
	request_sha256 VARCHAR(64), 
	audit_id VARCHAR(64) NOT NULL, 
	actor_type VARCHAR(64) NOT NULL, 
	actor_id VARCHAR(128), 
	action VARCHAR(128) NOT NULL, 
	target_table VARCHAR(128) NOT NULL, 
	target_id VARCHAR(128) NOT NULL, 
	before_json JSON, 
	after_json JSON, 
	reason TEXT, 
	metadata_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (audit_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_audit_records_created_at ON audit_records (created_at);

CREATE INDEX ix_audit_records_tenant_id ON audit_records (tenant_id);

CREATE UNIQUE INDEX uq_graph_receipt_tenant_operation_key ON audit_records (tenant_id, receipt_operation, idempotency_key);

CREATE TABLE behavior_observations (
	behavior_observation_id VARCHAR(64) NOT NULL, 
	procurement_case_id VARCHAR(64), 
	rfq_id VARCHAR(64), 
	quote_id VARCHAR(64), 
	po_id VARCHAR(64), 
	entity_type VARCHAR(64) NOT NULL, 
	entity_id VARCHAR(64) NOT NULL, 
	counterparty_entity_type VARCHAR(64), 
	counterparty_entity_id VARCHAR(64), 
	source_event_id VARCHAR(128), 
	response_to_event_id VARCHAR(64), 
	behavior_type VARCHAR(64) NOT NULL, 
	raw_value_json JSON NOT NULL, 
	normalized_value_json JSON NOT NULL, 
	observed_at DATETIME NOT NULL, 
	working_time_context_json JSON NOT NULL, 
	confidence NUMERIC(5, 4), 
	source VARCHAR(64) NOT NULL, 
	metadata_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (behavior_observation_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_behavior_obs_entity_type_behavior ON behavior_observations (tenant_id, entity_type, entity_id, behavior_type);

CREATE INDEX ix_behavior_obs_entity_type_id ON behavior_observations (tenant_id, entity_type, entity_id);

CREATE INDEX ix_behavior_observations_behavior_type ON behavior_observations (behavior_type);

CREATE INDEX ix_behavior_observations_created_at ON behavior_observations (created_at);

CREATE INDEX ix_behavior_observations_entity_id ON behavior_observations (entity_id);

CREATE INDEX ix_behavior_observations_observed_at ON behavior_observations (observed_at);

CREATE INDEX ix_behavior_observations_po_id ON behavior_observations (po_id);

CREATE INDEX ix_behavior_observations_procurement_case_id ON behavior_observations (procurement_case_id);

CREATE INDEX ix_behavior_observations_quote_id ON behavior_observations (quote_id);

CREATE INDEX ix_behavior_observations_rfq_id ON behavior_observations (rfq_id);

CREATE INDEX ix_behavior_observations_tenant_id ON behavior_observations (tenant_id);

CREATE TABLE buyer_behavior_feature_snapshots (
	snapshot_id VARCHAR(64) NOT NULL, 
	buyer_id VARCHAR(64) NOT NULL, 
	feature_window VARCHAR(64) NOT NULL, 
	procurement_case_id VARCHAR(64), 
	feature_json JSON NOT NULL, 
	source_observation_ids_json JSON NOT NULL, 
	generated_at DATETIME NOT NULL DEFAULT now(), 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (snapshot_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_buyer_behavior_feature_snapshots_buyer_id ON buyer_behavior_feature_snapshots (buyer_id);

CREATE INDEX ix_buyer_behavior_feature_snapshots_created_at ON buyer_behavior_feature_snapshots (created_at);

CREATE INDEX ix_buyer_behavior_feature_snapshots_feature_window ON buyer_behavior_feature_snapshots (feature_window);

CREATE INDEX ix_buyer_behavior_feature_snapshots_procurement_case_id ON buyer_behavior_feature_snapshots (procurement_case_id);

CREATE INDEX ix_buyer_behavior_feature_snapshots_tenant_id ON buyer_behavior_feature_snapshots (tenant_id);

CREATE INDEX ix_buyer_feat_tenant_buyer_window ON buyer_behavior_feature_snapshots (tenant_id, buyer_id, feature_window);

CREATE TABLE buyer_contacts (
	buyer_contact_id VARCHAR(64) NOT NULL, 
	buyer_id VARCHAR(64) NOT NULL, 
	contact_name VARCHAR(255), 
	channel_type VARCHAR(64) NOT NULL, 
	channel_identifier VARCHAR(255) NOT NULL, 
	`role` VARCHAR(128), 
	decision_role VARCHAR(64) NOT NULL, 
	is_primary_contact BOOL NOT NULL, 
	status VARCHAR(64) NOT NULL, 
	metadata_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (buyer_contact_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_buyer_contacts_buyer_id ON buyer_contacts (buyer_id);

CREATE INDEX ix_buyer_contacts_created_at ON buyer_contacts (created_at);

CREATE INDEX ix_buyer_contacts_tenant_id ON buyer_contacts (tenant_id);

CREATE TABLE buyer_supplier_behavior_metrics (
	metric_id VARCHAR(64) NOT NULL, 
	buyer_id VARCHAR(64) NOT NULL, 
	supplier_id VARCHAR(64) NOT NULL, 
	window_start DATETIME, 
	window_end DATETIME, 
	window_type VARCHAR(64) NOT NULL, 
	rfq_count INTEGER NOT NULL, 
	quote_count INTEGER NOT NULL, 
	po_count INTEGER NOT NULL, 
	conversion_rate NUMERIC(7, 4), 
	avg_supplier_response_seconds NUMERIC(14, 4), 
	avg_buyer_response_seconds NUMERIC(14, 4), 
	avg_rounds_to_po NUMERIC(10, 4), 
	avg_price_gap_vs_buyer_target NUMERIC(10, 4), 
	avg_leadtime_gap_vs_buyer_target NUMERIC(10, 4), 
	buyer_selected_supplier_rate NUMERIC(7, 4), 
	supplier_acceptance_rate NUMERIC(7, 4), 
	dispute_count INTEGER NOT NULL, 
	quality_issue_count INTEGER NOT NULL, 
	on_time_delivery_rate NUMERIC(7, 4), 
	relationship_strength_score NUMERIC(7, 4), 
	recommended_pairing_score NUMERIC(7, 4), 
	calculated_at DATETIME NOT NULL DEFAULT now(), 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (metric_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_buyer_supplier_behavior_metrics_buyer_id ON buyer_supplier_behavior_metrics (buyer_id);

CREATE INDEX ix_buyer_supplier_behavior_metrics_created_at ON buyer_supplier_behavior_metrics (created_at);

CREATE INDEX ix_buyer_supplier_behavior_metrics_supplier_id ON buyer_supplier_behavior_metrics (supplier_id);

CREATE INDEX ix_buyer_supplier_behavior_metrics_tenant_id ON buyer_supplier_behavior_metrics (tenant_id);

CREATE INDEX ix_buyer_supplier_behavior_metrics_window_type ON buyer_supplier_behavior_metrics (window_type);

CREATE INDEX ix_pair_metrics_tenant_pair_window ON buyer_supplier_behavior_metrics (tenant_id, buyer_id, supplier_id, window_type);

CREATE TABLE buyers (
	buyer_id VARCHAR(64) NOT NULL, 
	buyer_name VARCHAR(255) NOT NULL, 
	buyer_type VARCHAR(64) NOT NULL, 
	country VARCHAR(128), 
	region VARCHAR(128), 
	industry VARCHAR(128), 
	default_currency VARCHAR(16), 
	default_language VARCHAR(16), 
	timezone VARCHAR(64), 
	working_calendar_id VARCHAR(64), 
	status VARCHAR(64) NOT NULL, 
	risk_level VARCHAR(64), 
	metadata_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (buyer_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_buyers_created_at ON buyers (created_at);

CREATE INDEX ix_buyers_tenant_id ON buyers (tenant_id);

CREATE TABLE case_decision_option_lines (
	decision_option_line_id VARCHAR(64) NOT NULL, 
	decision_option_id VARCHAR(64) NOT NULL, 
	procurement_case_id VARCHAR(64) NOT NULL, 
	rfq_id VARCHAR(64), 
	rfq_line_item_id VARCHAR(64), 
	supplier_id VARCHAR(64), 
	quote_id VARCHAR(64), 
	quote_line_item_id VARCHAR(64), 
	product_category_id VARCHAR(64), 
	product_id VARCHAR(64), 
	product_name VARCHAR(255), 
	quantity NUMERIC(14, 4), 
	quantity_unit VARCHAR(64), 
	buyer_unit_price NUMERIC(14, 4), 
	currency VARCHAR(16), 
	estimated_margin NUMERIC(14, 4), 
	estimated_margin_rate NUMERIC(7, 4), 
	p50_days NUMERIC(10, 2), 
	p80_days NUMERIC(10, 2), 
	p90_days NUMERIC(10, 2), 
	deadline_risk_level VARCHAR(64), 
	line_reason_json JSON NOT NULL, 
	metadata_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (decision_option_line_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_case_decision_option_lines_created_at ON case_decision_option_lines (created_at);

CREATE INDEX ix_case_decision_option_lines_decision_option_id ON case_decision_option_lines (decision_option_id);

CREATE INDEX ix_case_decision_option_lines_procurement_case_id ON case_decision_option_lines (procurement_case_id);

CREATE INDEX ix_case_decision_option_lines_quote_id ON case_decision_option_lines (quote_id);

CREATE INDEX ix_case_decision_option_lines_rfq_id ON case_decision_option_lines (rfq_id);

CREATE INDEX ix_case_decision_option_lines_supplier_id ON case_decision_option_lines (supplier_id);

CREATE INDEX ix_case_decision_option_lines_tenant_id ON case_decision_option_lines (tenant_id);

CREATE INDEX ix_decision_option_lines_tenant_case ON case_decision_option_lines (tenant_id, procurement_case_id);

CREATE INDEX ix_decision_option_lines_tenant_option ON case_decision_option_lines (tenant_id, decision_option_id);

CREATE TABLE case_decision_options (
	decision_option_id VARCHAR(64) NOT NULL, 
	procurement_case_id VARCHAR(64) NOT NULL, 
	rfq_id VARCHAR(64), 
	buyer_id VARCHAR(64), 
	option_label VARCHAR(255) NOT NULL, 
	option_type VARCHAR(64) NOT NULL, 
	input_quote_ids_json JSON NOT NULL, 
	input_quote_line_item_ids_json JSON NOT NULL, 
	input_supplier_ids_json JSON NOT NULL, 
	gltg_run_ids_json JSON NOT NULL, 
	pricing_input_ids_json JSON NOT NULL, 
	behavior_observation_ids_json JSON NOT NULL, 
	buyer_price NUMERIC(14, 4), 
	buyer_currency VARCHAR(16), 
	estimated_margin NUMERIC(14, 4), 
	estimated_margin_rate NUMERIC(7, 4), 
	estimated_lead_time_days INTEGER, 
	p50_days NUMERIC(10, 2), 
	p80_days NUMERIC(10, 2), 
	p90_days NUMERIC(10, 2), 
	deadline_risk_level VARCHAR(64), 
	commercial_risk_level VARCHAR(64), 
	quality_risk_level VARCHAR(64), 
	recommendation_score NUMERIC(10, 4), 
	recommendation_reason_json JSON NOT NULL, 
	tradeoff_summary_json JSON NOT NULL, 
	status VARCHAR(64) NOT NULL, 
	created_by VARCHAR(64) NOT NULL, 
	presented_at DATETIME, 
	selected_at DATETIME, 
	metadata_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (decision_option_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_case_decision_options_buyer_id ON case_decision_options (buyer_id);

CREATE INDEX ix_case_decision_options_created_at ON case_decision_options (created_at);

CREATE INDEX ix_case_decision_options_procurement_case_id ON case_decision_options (procurement_case_id);

CREATE INDEX ix_case_decision_options_rfq_id ON case_decision_options (rfq_id);

CREATE INDEX ix_case_decision_options_status ON case_decision_options (status);

CREATE INDEX ix_case_decision_options_tenant_id ON case_decision_options (tenant_id);

CREATE INDEX ix_decision_options_tenant_case ON case_decision_options (tenant_id, procurement_case_id);

CREATE INDEX ix_decision_options_tenant_rfq ON case_decision_options (tenant_id, rfq_id);

CREATE INDEX ix_decision_options_tenant_status ON case_decision_options (tenant_id, status);

CREATE TABLE communication_events (
	communication_event_id VARCHAR(64) NOT NULL, 
	procurement_case_id VARCHAR(64), 
	rfq_id VARCHAR(64), 
	quote_id VARCHAR(64), 
	po_id VARCHAR(64), 
	channel VARCHAR(64), 
	conversation_id VARCHAR(128), 
	message_id VARCHAR(128), 
	parent_message_id VARCHAR(128), 
	sender_entity_type VARCHAR(64) NOT NULL, 
	sender_entity_id VARCHAR(64), 
	receiver_entity_type VARCHAR(64) NOT NULL, 
	receiver_entity_id VARCHAR(64), 
	sender_contact_id VARCHAR(64), 
	receiver_contact_id VARCHAR(64), 
	message_direction VARCHAR(64) NOT NULL, 
	message_type VARCHAR(64) NOT NULL, 
	raw_text TEXT, 
	attachments_json JSON NOT NULL, 
	sent_at DATETIME, 
	received_at DATETIME, 
	recorded_at DATETIME NOT NULL DEFAULT now(), 
	sender_timezone VARCHAR(64), 
	receiver_timezone VARCHAR(64), 
	is_working_time_sender BOOL, 
	is_working_time_receiver BOOL, 
	is_after_hours BOOL, 
	is_weekend BOOL, 
	is_holiday BOOL, 
	response_to_event_id VARCHAR(64), 
	response_latency_seconds INTEGER, 
	business_hours_latency_seconds INTEGER, 
	parsed_intent VARCHAR(128), 
	parsed_entities_json JSON NOT NULL, 
	confidence NUMERIC(5, 4), 
	source_system VARCHAR(64) NOT NULL, 
	metadata_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (communication_event_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_comm_events_conversation ON communication_events (conversation_id);

CREATE INDEX ix_comm_events_response_to ON communication_events (response_to_event_id);

CREATE INDEX ix_comm_events_tenant_case ON communication_events (tenant_id, procurement_case_id);

CREATE INDEX ix_communication_events_created_at ON communication_events (created_at);

CREATE INDEX ix_communication_events_po_id ON communication_events (po_id);

CREATE INDEX ix_communication_events_procurement_case_id ON communication_events (procurement_case_id);

CREATE INDEX ix_communication_events_quote_id ON communication_events (quote_id);

CREATE INDEX ix_communication_events_rfq_id ON communication_events (rfq_id);

CREATE INDEX ix_communication_events_tenant_id ON communication_events (tenant_id);

CREATE TABLE data_lineage (
	lineage_id VARCHAR(64) NOT NULL, 
	source_table VARCHAR(128) NOT NULL, 
	source_id VARCHAR(128) NOT NULL, 
	target_table VARCHAR(128) NOT NULL, 
	target_id VARCHAR(128) NOT NULL, 
	lineage_type VARCHAR(64) NOT NULL, 
	confidence NUMERIC(5, 4), 
	created_by VARCHAR(128), 
	metadata_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (lineage_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_data_lineage_created_at ON data_lineage (created_at);

CREATE INDEX ix_data_lineage_tenant_id ON data_lineage (tenant_id);

CREATE TABLE data_sources (
	source_platform VARCHAR(128), 
	display_name VARCHAR(255) NOT NULL, 
	id VARCHAR(36) NOT NULL, 
	tenant_id VARCHAR(36), 
	visibility VARCHAR(64) NOT NULL, 
	source_type VARCHAR(64), 
	created_by VARCHAR(128), 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE decision_packets (
	project_id VARCHAR(36), 
	payload JSON NOT NULL, 
	id VARCHAR(36) NOT NULL, 
	tenant_id VARCHAR(36), 
	visibility VARCHAR(64) NOT NULL, 
	source_type VARCHAR(64), 
	created_by VARCHAR(128), 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE execution_events (
	project_id VARCHAR(36), 
	order_id VARCHAR(36), 
	event_type VARCHAR(128) NOT NULL, 
	payload JSON NOT NULL, 
	id VARCHAR(36) NOT NULL, 
	tenant_id VARCHAR(36), 
	visibility VARCHAR(64) NOT NULL, 
	source_type VARCHAR(64), 
	created_by VARCHAR(128), 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE gltg_behavior_inputs (
	gltg_behavior_input_id VARCHAR(64) NOT NULL, 
	gltg_run_id VARCHAR(64) NOT NULL, 
	buyer_feature_snapshot_id VARCHAR(64), 
	supplier_feature_snapshot_id VARCHAR(64), 
	pair_metric_id VARCHAR(64), 
	feature_json JSON NOT NULL, 
	adjustment_json JSON NOT NULL, 
	source_observation_ids_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (gltg_behavior_input_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_gltg_behavior_inputs_created_at ON gltg_behavior_inputs (created_at);

CREATE INDEX ix_gltg_behavior_inputs_gltg_run_id ON gltg_behavior_inputs (gltg_run_id);

CREATE INDEX ix_gltg_behavior_inputs_tenant_id ON gltg_behavior_inputs (tenant_id);

CREATE TABLE gltg_context_bundles (
	project_id VARCHAR(36), 
	payload JSON NOT NULL, 
	id VARCHAR(36) NOT NULL, 
	tenant_id VARCHAR(36), 
	visibility VARCHAR(64) NOT NULL, 
	source_type VARCHAR(64), 
	created_by VARCHAR(128), 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE gltg_delivery_feasibility_packets (
	context_bundle_id VARCHAR(36), 
	payload JSON NOT NULL, 
	id VARCHAR(36) NOT NULL, 
	tenant_id VARCHAR(36), 
	visibility VARCHAR(64) NOT NULL, 
	source_type VARCHAR(64), 
	created_by VARCHAR(128), 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE gltg_simulation_runs (
	gltg_run_id VARCHAR(64) NOT NULL, 
	procurement_case_id VARCHAR(64), 
	rfq_id VARCHAR(64), 
	quote_id VARCHAR(64), 
	po_id VARCHAR(64), 
	buyer_id VARCHAR(64), 
	supplier_id VARCHAR(64), 
	product_category_id VARCHAR(64), 
	product_id VARCHAR(64), 
	base_input_json JSON NOT NULL, 
	behavior_input_json JSON NOT NULL, 
	output_json JSON NOT NULL, 
	base_production_days NUMERIC(10, 2), 
	base_procurement_days NUMERIC(10, 2), 
	supplier_response_buffer_days NUMERIC(10, 2), 
	supplier_uncertainty_buffer_days NUMERIC(10, 2), 
	buyer_decision_buffer_days NUMERIC(10, 2), 
	logistics_buffer_days NUMERIC(10, 2), 
	risk_buffer_days NUMERIC(10, 2), 
	final_p50_days NUMERIC(10, 2), 
	final_p80_days NUMERIC(10, 2), 
	final_p90_days NUMERIC(10, 2), 
	deadline_risk_level VARCHAR(64), 
	explanation_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (gltg_run_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_gltg_simulation_runs_buyer_id ON gltg_simulation_runs (buyer_id);

CREATE INDEX ix_gltg_simulation_runs_created_at ON gltg_simulation_runs (created_at);

CREATE INDEX ix_gltg_simulation_runs_po_id ON gltg_simulation_runs (po_id);

CREATE INDEX ix_gltg_simulation_runs_procurement_case_id ON gltg_simulation_runs (procurement_case_id);

CREATE INDEX ix_gltg_simulation_runs_quote_id ON gltg_simulation_runs (quote_id);

CREATE INDEX ix_gltg_simulation_runs_rfq_id ON gltg_simulation_runs (rfq_id);

CREATE INDEX ix_gltg_simulation_runs_supplier_id ON gltg_simulation_runs (supplier_id);

CREATE INDEX ix_gltg_simulation_runs_tenant_id ON gltg_simulation_runs (tenant_id);

CREATE TABLE gpm_context_bundles (
	project_id VARCHAR(36), 
	payload JSON NOT NULL, 
	id VARCHAR(36) NOT NULL, 
	tenant_id VARCHAR(36), 
	visibility VARCHAR(64) NOT NULL, 
	source_type VARCHAR(64), 
	created_by VARCHAR(128), 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE gpm_decision_packets (
	idempotency_key_hash VARCHAR(64), 
	request_fingerprint VARCHAR(64), 
	context_json JSON, 
	case_id VARCHAR(255), 
	quote_id VARCHAR(255), 
	packet_id VARCHAR(128) NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL DEFAULT 'default', 
	sku VARCHAR(256) NOT NULL, 
	supplier_id VARCHAR(128), 
	supplier_quote FLOAT NOT NULL, 
	currency VARCHAR(16) NOT NULL DEFAULT 'USD', 
	quantity INTEGER, 
	quote_position VARCHAR(64), 
	recommendation VARCHAR(64), 
	confidence VARCHAR(32), 
	human_approval_required BOOL NOT NULL DEFAULT '1', 
	approval_status VARCHAR(32) NOT NULL DEFAULT 'pending', 
	dispatched BOOL NOT NULL DEFAULT '0', 
	llm_reasoning TEXT, 
	evidence_ids TEXT, 
	operator_id VARCHAR(128), 
	notes TEXT, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (packet_id), 
	CONSTRAINT uq_gpm_packet_tenant_idempotency_hash UNIQUE (tenant_id, idempotency_key_hash)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_gpm_decision_packets_case_id ON gpm_decision_packets (case_id);

CREATE INDEX ix_gpm_decision_packets_quote_id ON gpm_decision_packets (quote_id);

CREATE TABLE gpm_quote_strategy_packets (
	context_bundle_id VARCHAR(36), 
	payload JSON NOT NULL, 
	id VARCHAR(36) NOT NULL, 
	tenant_id VARCHAR(36), 
	visibility VARCHAR(64) NOT NULL, 
	source_type VARCHAR(64), 
	created_by VARCHAR(128), 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE imported_api_records (
	source_id VARCHAR(36), 
	raw_evidence_record_id VARCHAR(36), 
	source_platform VARCHAR(128), 
	project_id VARCHAR(36), 
	order_id VARCHAR(36), 
	rfq_id VARCHAR(36), 
	supplier_response_id VARCHAR(36), 
	observed_at DATETIME, 
	captured_at DATETIME, 
	raw_payload_hash VARCHAR(128), 
	payload JSON NOT NULL, 
	id VARCHAR(36) NOT NULL, 
	tenant_id VARCHAR(36), 
	visibility VARCHAR(64) NOT NULL, 
	source_type VARCHAR(64), 
	created_by VARCHAR(128), 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE lead_time_evidence (
	source_id VARCHAR(36), 
	source_platform VARCHAR(128), 
	project_id VARCHAR(36), 
	order_id VARCHAR(36), 
	rfq_id VARCHAR(36), 
	supplier_response_id VARCHAR(36), 
	observed_at DATETIME, 
	captured_at DATETIME, 
	raw_payload_hash VARCHAR(128), 
	payload JSON NOT NULL, 
	id VARCHAR(36) NOT NULL, 
	tenant_id VARCHAR(36), 
	visibility VARCHAR(64) NOT NULL, 
	source_type VARCHAR(64), 
	created_by VARCHAR(128), 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE leadtime_observations (
	leadtime_observation_id VARCHAR(64) NOT NULL, 
	procurement_case_id VARCHAR(64), 
	rfq_id VARCHAR(64), 
	quote_id VARCHAR(64), 
	po_id VARCHAR(64), 
	buyer_id VARCHAR(64), 
	supplier_id VARCHAR(64), 
	product_category_id VARCHAR(64), 
	product_id VARCHAR(64), 
	quoted_lead_time_days NUMERIC(10, 2), 
	actual_lead_time_days NUMERIC(10, 2), 
	aivan_predicted_days NUMERIC(10, 2), 
	gltg_run_id VARCHAR(64), 
	destination VARCHAR(255), 
	quantity NUMERIC(14, 4), 
	observed_at DATETIME NOT NULL, 
	verification_status VARCHAR(64) NOT NULL, 
	source VARCHAR(64) NOT NULL, 
	metadata_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (leadtime_observation_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_leadtime_observations_buyer_id ON leadtime_observations (buyer_id);

CREATE INDEX ix_leadtime_observations_created_at ON leadtime_observations (created_at);

CREATE INDEX ix_leadtime_observations_observed_at ON leadtime_observations (observed_at);

CREATE INDEX ix_leadtime_observations_po_id ON leadtime_observations (po_id);

CREATE INDEX ix_leadtime_observations_procurement_case_id ON leadtime_observations (procurement_case_id);

CREATE INDEX ix_leadtime_observations_quote_id ON leadtime_observations (quote_id);

CREATE INDEX ix_leadtime_observations_rfq_id ON leadtime_observations (rfq_id);

CREATE INDEX ix_leadtime_observations_supplier_id ON leadtime_observations (supplier_id);

CREATE INDEX ix_leadtime_observations_tenant_id ON leadtime_observations (tenant_id);

CREATE TABLE negotiation_rounds (
	negotiation_round_id VARCHAR(64) NOT NULL, 
	procurement_case_id VARCHAR(64) NOT NULL, 
	rfq_id VARCHAR(64), 
	buyer_id VARCHAR(64), 
	supplier_id VARCHAR(64), 
	round_number INTEGER NOT NULL, 
	round_type VARCHAR(64) NOT NULL, 
	started_by_entity_type VARCHAR(64) NOT NULL, 
	started_by_entity_id VARCHAR(64), 
	started_event_id VARCHAR(64), 
	ended_event_id VARCHAR(64), 
	started_at DATETIME NOT NULL, 
	ended_at DATETIME, 
	duration_seconds INTEGER, 
	outcome VARCHAR(64) NOT NULL, 
	metadata_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (negotiation_round_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_negotiation_rounds_buyer_id ON negotiation_rounds (buyer_id);

CREATE INDEX ix_negotiation_rounds_created_at ON negotiation_rounds (created_at);

CREATE INDEX ix_negotiation_rounds_procurement_case_id ON negotiation_rounds (procurement_case_id);

CREATE INDEX ix_negotiation_rounds_rfq_id ON negotiation_rounds (rfq_id);

CREATE INDEX ix_negotiation_rounds_supplier_id ON negotiation_rounds (supplier_id);

CREATE INDEX ix_negotiation_rounds_tenant_id ON negotiation_rounds (tenant_id);

CREATE TABLE order_lines (
	order_id VARCHAR(36) NOT NULL, 
	sku VARCHAR(128), 
	quantity NUMERIC(12, 2), 
	payload JSON NOT NULL, 
	id VARCHAR(36) NOT NULL, 
	tenant_id VARCHAR(36), 
	visibility VARCHAR(64) NOT NULL, 
	source_type VARCHAR(64), 
	created_by VARCHAR(128), 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE orders (
	project_id VARCHAR(36), 
	order_number VARCHAR(128) NOT NULL, 
	status VARCHAR(64) NOT NULL, 
	id VARCHAR(36) NOT NULL, 
	tenant_id VARCHAR(36), 
	visibility VARCHAR(64) NOT NULL, 
	source_type VARCHAR(64), 
	created_by VARCHAR(128), 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE participants (
	project_id VARCHAR(36), 
	actor_id VARCHAR(36), 
	`role` VARCHAR(128) NOT NULL, 
	id VARCHAR(36) NOT NULL, 
	tenant_id VARCHAR(36), 
	visibility VARCHAR(64) NOT NULL, 
	source_type VARCHAR(64), 
	created_by VARCHAR(128), 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE po_quote_links (
	po_quote_link_id VARCHAR(64) NOT NULL, 
	po_id VARCHAR(64) NOT NULL, 
	po_line_item_id VARCHAR(64), 
	procurement_case_id VARCHAR(64) NOT NULL, 
	rfq_id VARCHAR(64), 
	rfq_line_item_id VARCHAR(64), 
	quote_id VARCHAR(64) NOT NULL, 
	quote_line_item_id VARCHAR(64), 
	supplier_id VARCHAR(64) NOT NULL, 
	link_type VARCHAR(64) NOT NULL, 
	selection_rank INTEGER, 
	selection_score NUMERIC(10, 4), 
	selection_reason_json JSON NOT NULL, 
	rejection_reason_json JSON NOT NULL, 
	comparison_snapshot_id VARCHAR(64), 
	created_by VARCHAR(128), 
	metadata_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (po_quote_link_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_po_quote_links_created_at ON po_quote_links (created_at);

CREATE INDEX ix_po_quote_links_link_type ON po_quote_links (link_type);

CREATE INDEX ix_po_quote_links_po_id ON po_quote_links (po_id);

CREATE INDEX ix_po_quote_links_po_line_item_id ON po_quote_links (po_line_item_id);

CREATE INDEX ix_po_quote_links_procurement_case_id ON po_quote_links (procurement_case_id);

CREATE INDEX ix_po_quote_links_quote_id ON po_quote_links (quote_id);

CREATE INDEX ix_po_quote_links_rfq_id ON po_quote_links (rfq_id);

CREATE INDEX ix_po_quote_links_supplier_id ON po_quote_links (supplier_id);

CREATE INDEX ix_po_quote_links_tenant_id ON po_quote_links (tenant_id);

CREATE INDEX ix_po_quote_links_tenant_link_type ON po_quote_links (tenant_id, link_type);

CREATE INDEX ix_po_quote_links_tenant_po ON po_quote_links (tenant_id, po_id);

CREATE INDEX ix_po_quote_links_tenant_quote ON po_quote_links (tenant_id, quote_id);

CREATE INDEX ix_po_quote_links_tenant_supplier ON po_quote_links (tenant_id, supplier_id);

CREATE TABLE price_observations (
	price_observation_id VARCHAR(64) NOT NULL, 
	procurement_case_id VARCHAR(64), 
	rfq_id VARCHAR(64), 
	quote_id VARCHAR(64), 
	po_id VARCHAR(64), 
	buyer_id VARCHAR(64), 
	supplier_id VARCHAR(64), 
	product_category_id VARCHAR(64), 
	product_id VARCHAR(64), 
	quantity NUMERIC(14, 4), 
	unit_price NUMERIC(14, 4) NOT NULL, 
	currency VARCHAR(16) NOT NULL, 
	incoterm VARCHAR(64), 
	destination VARCHAR(255), 
	observed_at DATETIME NOT NULL, 
	verification_status VARCHAR(64) NOT NULL, 
	source VARCHAR(64) NOT NULL, 
	metadata_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (price_observation_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_price_observations_buyer_id ON price_observations (buyer_id);

CREATE INDEX ix_price_observations_created_at ON price_observations (created_at);

CREATE INDEX ix_price_observations_observed_at ON price_observations (observed_at);

CREATE INDEX ix_price_observations_po_id ON price_observations (po_id);

CREATE INDEX ix_price_observations_procurement_case_id ON price_observations (procurement_case_id);

CREATE INDEX ix_price_observations_quote_id ON price_observations (quote_id);

CREATE INDEX ix_price_observations_rfq_id ON price_observations (rfq_id);

CREATE INDEX ix_price_observations_supplier_id ON price_observations (supplier_id);

CREATE INDEX ix_price_observations_tenant_id ON price_observations (tenant_id);

CREATE TABLE pricing_decision_inputs (
	pricing_input_id VARCHAR(64) NOT NULL, 
	procurement_case_id VARCHAR(64), 
	rfq_id VARCHAR(64), 
	quote_id VARCHAR(64), 
	po_id VARCHAR(64), 
	buyer_id VARCHAR(64), 
	supplier_id VARCHAR(64), 
	product_category_id VARCHAR(64), 
	buyer_behavior_snapshot_id VARCHAR(64), 
	supplier_behavior_snapshot_id VARCHAR(64), 
	buyer_supplier_metric_id VARCHAR(64), 
	gltg_run_id VARCHAR(64), 
	input_json JSON NOT NULL, 
	recommended_margin NUMERIC(7, 4), 
	minimum_acceptable_margin NUMERIC(7, 4), 
	risk_buffer_rate NUMERIC(7, 4), 
	discount_allowed BOOL, 
	manual_review_required BOOL, 
	explanation_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (pricing_input_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_pricing_decision_inputs_buyer_id ON pricing_decision_inputs (buyer_id);

CREATE INDEX ix_pricing_decision_inputs_created_at ON pricing_decision_inputs (created_at);

CREATE INDEX ix_pricing_decision_inputs_po_id ON pricing_decision_inputs (po_id);

CREATE INDEX ix_pricing_decision_inputs_procurement_case_id ON pricing_decision_inputs (procurement_case_id);

CREATE INDEX ix_pricing_decision_inputs_quote_id ON pricing_decision_inputs (quote_id);

CREATE INDEX ix_pricing_decision_inputs_rfq_id ON pricing_decision_inputs (rfq_id);

CREATE INDEX ix_pricing_decision_inputs_supplier_id ON pricing_decision_inputs (supplier_id);

CREATE INDEX ix_pricing_decision_inputs_tenant_id ON pricing_decision_inputs (tenant_id);

CREATE TABLE pricing_evidence (
	source_id VARCHAR(36), 
	source_platform VARCHAR(128), 
	project_id VARCHAR(36), 
	order_id VARCHAR(36), 
	rfq_id VARCHAR(36), 
	supplier_response_id VARCHAR(36), 
	observed_at DATETIME, 
	captured_at DATETIME, 
	raw_payload_hash VARCHAR(128), 
	payload JSON NOT NULL, 
	id VARCHAR(36) NOT NULL, 
	tenant_id VARCHAR(36), 
	visibility VARCHAR(64) NOT NULL, 
	source_type VARCHAR(64), 
	created_by VARCHAR(128), 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE private_data_records (
	source_id VARCHAR(36), 
	raw_evidence_record_id VARCHAR(36), 
	source_platform VARCHAR(128), 
	project_id VARCHAR(36), 
	order_id VARCHAR(36), 
	rfq_id VARCHAR(36), 
	supplier_response_id VARCHAR(36), 
	observed_at DATETIME, 
	captured_at DATETIME, 
	raw_payload_hash VARCHAR(128), 
	payload JSON NOT NULL, 
	id VARCHAR(36) NOT NULL, 
	tenant_id VARCHAR(36), 
	visibility VARCHAR(64) NOT NULL, 
	source_type VARCHAR(64), 
	created_by VARCHAR(128), 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE procurement_cases (
	procurement_case_id VARCHAR(64) NOT NULL, 
	buyer_id VARCHAR(64), 
	created_by_user_id VARCHAR(128), 
	source_channel VARCHAR(64), 
	source_conversation_id VARCHAR(128), 
	source_event_id VARCHAR(128), 
	status VARCHAR(64) NOT NULL, 
	closed_at DATETIME, 
	metadata_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (procurement_case_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_procurement_cases_buyer_id ON procurement_cases (buyer_id);

CREATE INDEX ix_procurement_cases_created_at ON procurement_cases (created_at);

CREATE INDEX ix_procurement_cases_tenant_id ON procurement_cases (tenant_id);

CREATE TABLE product_categories (
	product_category_id VARCHAR(64) NOT NULL, 
	category_name VARCHAR(255) NOT NULL, 
	parent_category_id VARCHAR(64), 
	industry VARCHAR(128), 
	metadata_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (product_category_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_product_categories_created_at ON product_categories (created_at);

CREATE INDEX ix_product_categories_tenant_id ON product_categories (tenant_id);

CREATE TABLE products (
	product_id VARCHAR(64) NOT NULL, 
	product_category_id VARCHAR(64), 
	product_name VARCHAR(255) NOT NULL, 
	material VARCHAR(255), 
	spec_json JSON NOT NULL, 
	unit VARCHAR(64), 
	metadata_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (product_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_products_created_at ON products (created_at);

CREATE INDEX ix_products_product_category_id ON products (product_category_id);

CREATE INDEX ix_products_tenant_id ON products (tenant_id);

CREATE TABLE projects (
	name VARCHAR(255) NOT NULL, 
	status VARCHAR(64) NOT NULL, 
	summary TEXT, 
	id VARCHAR(36) NOT NULL, 
	tenant_id VARCHAR(36), 
	visibility VARCHAR(64) NOT NULL, 
	source_type VARCHAR(64), 
	created_by VARCHAR(128), 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE purchase_order_line_items (
	po_line_item_id VARCHAR(64) NOT NULL, 
	po_id VARCHAR(64) NOT NULL, 
	procurement_case_id VARCHAR(64) NOT NULL, 
	rfq_id VARCHAR(64), 
	rfq_line_item_id VARCHAR(64), 
	buyer_id VARCHAR(64) NOT NULL, 
	supplier_id VARCHAR(64) NOT NULL, 
	product_category_id VARCHAR(64), 
	product_id VARCHAR(64), 
	product_name VARCHAR(255), 
	quantity NUMERIC(14, 4), 
	quantity_unit VARCHAR(64), 
	selected_quote_id VARCHAR(64), 
	selected_quote_line_item_id VARCHAR(64), 
	decision_option_id VARCHAR(64), 
	decision_option_line_id VARCHAR(64), 
	gltg_run_id VARCHAR(64), 
	pricing_input_id VARCHAR(64), 
	quoted_unit_price NUMERIC(14, 4), 
	final_unit_price NUMERIC(14, 4), 
	currency VARCHAR(16), 
	quoted_lead_time_days INTEGER, 
	final_committed_lead_time_days INTEGER, 
	incoterms VARCHAR(64), 
	payment_terms VARCHAR(255), 
	quality_terms_json JSON NOT NULL, 
	packaging_terms_json JSON NOT NULL, 
	line_status VARCHAR(64) NOT NULL, 
	metadata_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (po_line_item_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_po_lines_tenant_case ON purchase_order_line_items (tenant_id, procurement_case_id);

CREATE INDEX ix_po_lines_tenant_po ON purchase_order_line_items (tenant_id, po_id);

CREATE INDEX ix_po_lines_tenant_quote ON purchase_order_line_items (tenant_id, selected_quote_id);

CREATE INDEX ix_po_lines_tenant_quote_line ON purchase_order_line_items (tenant_id, selected_quote_line_item_id);

CREATE INDEX ix_purchase_order_line_items_buyer_id ON purchase_order_line_items (buyer_id);

CREATE INDEX ix_purchase_order_line_items_created_at ON purchase_order_line_items (created_at);

CREATE INDEX ix_purchase_order_line_items_po_id ON purchase_order_line_items (po_id);

CREATE INDEX ix_purchase_order_line_items_procurement_case_id ON purchase_order_line_items (procurement_case_id);

CREATE INDEX ix_purchase_order_line_items_rfq_id ON purchase_order_line_items (rfq_id);

CREATE INDEX ix_purchase_order_line_items_selected_quote_id ON purchase_order_line_items (selected_quote_id);

CREATE INDEX ix_purchase_order_line_items_selected_quote_line_item_id ON purchase_order_line_items (selected_quote_line_item_id);

CREATE INDEX ix_purchase_order_line_items_supplier_id ON purchase_order_line_items (supplier_id);

CREATE INDEX ix_purchase_order_line_items_tenant_id ON purchase_order_line_items (tenant_id);

CREATE TABLE purchase_orders (
	idempotency_key VARCHAR(255), 
	request_sha256 VARCHAR(64), 
	execution_revision INTEGER NOT NULL DEFAULT '0', 
	po_id VARCHAR(64) NOT NULL, 
	procurement_case_id VARCHAR(64) NOT NULL, 
	rfq_id VARCHAR(64), 
	buyer_id VARCHAR(64) NOT NULL, 
	supplier_id VARCHAR(64) NOT NULL, 
	selected_quote_id VARCHAR(64), 
	po_number VARCHAR(128), 
	status VARCHAR(64) NOT NULL, 
	issued_at DATETIME, 
	accepted_at DATETIME, 
	completed_at DATETIME, 
	metadata_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (po_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_purchase_orders_buyer_id ON purchase_orders (buyer_id);

CREATE INDEX ix_purchase_orders_created_at ON purchase_orders (created_at);

CREATE INDEX ix_purchase_orders_procurement_case_id ON purchase_orders (procurement_case_id);

CREATE INDEX ix_purchase_orders_rfq_id ON purchase_orders (rfq_id);

CREATE INDEX ix_purchase_orders_supplier_id ON purchase_orders (supplier_id);

CREATE INDEX ix_purchase_orders_tenant_id ON purchase_orders (tenant_id);

CREATE UNIQUE INDEX uq_purchase_orders_tenant_idempotency ON purchase_orders (tenant_id, idempotency_key);

CREATE TABLE quote_comparison_snapshots (
	comparison_snapshot_id VARCHAR(64) NOT NULL, 
	procurement_case_id VARCHAR(64) NOT NULL, 
	rfq_id VARCHAR(64), 
	buyer_id VARCHAR(64), 
	snapshot_type VARCHAR(64) NOT NULL, 
	quote_ids_json JSON NOT NULL, 
	supplier_ids_json JSON NOT NULL, 
	gltg_run_ids_json JSON NOT NULL, 
	pricing_input_ids_json JSON NOT NULL, 
	behavior_observation_ids_json JSON NOT NULL, 
	comparison_json JSON NOT NULL, 
	ranking_json JSON NOT NULL, 
	excluded_quotes_json JSON NOT NULL, 
	selected_quote_ids_json JSON NOT NULL, 
	selected_reason_json JSON NOT NULL, 
	created_by VARCHAR(64) NOT NULL, 
	metadata_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (comparison_snapshot_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_comparison_snapshots_tenant_case ON quote_comparison_snapshots (tenant_id, procurement_case_id);

CREATE INDEX ix_comparison_snapshots_tenant_rfq ON quote_comparison_snapshots (tenant_id, rfq_id);

CREATE INDEX ix_comparison_snapshots_tenant_type ON quote_comparison_snapshots (tenant_id, snapshot_type);

CREATE INDEX ix_quote_comparison_snapshots_buyer_id ON quote_comparison_snapshots (buyer_id);

CREATE INDEX ix_quote_comparison_snapshots_created_at ON quote_comparison_snapshots (created_at);

CREATE INDEX ix_quote_comparison_snapshots_procurement_case_id ON quote_comparison_snapshots (procurement_case_id);

CREATE INDEX ix_quote_comparison_snapshots_rfq_id ON quote_comparison_snapshots (rfq_id);

CREATE INDEX ix_quote_comparison_snapshots_snapshot_type ON quote_comparison_snapshots (snapshot_type);

CREATE INDEX ix_quote_comparison_snapshots_tenant_id ON quote_comparison_snapshots (tenant_id);

CREATE TABLE quote_revision_links (
	quote_revision_link_id VARCHAR(64) NOT NULL, 
	procurement_case_id VARCHAR(64) NOT NULL, 
	rfq_id VARCHAR(64) NOT NULL, 
	supplier_id VARCHAR(64) NOT NULL, 
	previous_quote_id VARCHAR(64), 
	revised_quote_id VARCHAR(64) NOT NULL, 
	revision_number INTEGER NOT NULL, 
	revision_type VARCHAR(64) NOT NULL, 
	revision_reason TEXT, 
	changed_fields_json JSON NOT NULL, 
	old_value_json JSON NOT NULL, 
	new_value_json JSON NOT NULL, 
	source_event_id VARCHAR(128), 
	negotiation_round_id VARCHAR(64), 
	behavior_observation_ids_json JSON NOT NULL, 
	verification_status VARCHAR(64) NOT NULL, 
	confidence NUMERIC(5, 4), 
	confirmed_by VARCHAR(128), 
	confirmed_at DATETIME, 
	metadata_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (quote_revision_link_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_quote_rev_tenant_case ON quote_revision_links (tenant_id, procurement_case_id);

CREATE INDEX ix_quote_rev_tenant_previous ON quote_revision_links (tenant_id, previous_quote_id);

CREATE INDEX ix_quote_rev_tenant_revised ON quote_revision_links (tenant_id, revised_quote_id);

CREATE INDEX ix_quote_rev_tenant_supplier ON quote_revision_links (tenant_id, supplier_id);

CREATE INDEX ix_quote_revision_links_created_at ON quote_revision_links (created_at);

CREATE INDEX ix_quote_revision_links_previous_quote_id ON quote_revision_links (previous_quote_id);

CREATE INDEX ix_quote_revision_links_procurement_case_id ON quote_revision_links (procurement_case_id);

CREATE INDEX ix_quote_revision_links_revised_quote_id ON quote_revision_links (revised_quote_id);

CREATE INDEX ix_quote_revision_links_rfq_id ON quote_revision_links (rfq_id);

CREATE INDEX ix_quote_revision_links_supplier_id ON quote_revision_links (supplier_id);

CREATE INDEX ix_quote_revision_links_tenant_id ON quote_revision_links (tenant_id);

CREATE TABLE raw_evidence_records (
	source_id VARCHAR(36), 
	source_platform VARCHAR(128), 
	project_id VARCHAR(36), 
	order_id VARCHAR(36), 
	rfq_id VARCHAR(36), 
	supplier_response_id VARCHAR(36), 
	observed_at DATETIME, 
	captured_at DATETIME, 
	raw_payload_hash VARCHAR(128), 
	payload JSON NOT NULL, 
	id VARCHAR(36) NOT NULL, 
	tenant_id VARCHAR(36), 
	visibility VARCHAR(64) NOT NULL, 
	source_type VARCHAR(64), 
	created_by VARCHAR(128), 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE requirements (
	project_id VARCHAR(36) NOT NULL, 
	requirement_type VARCHAR(128) NOT NULL, 
	payload JSON NOT NULL, 
	id VARCHAR(36) NOT NULL, 
	tenant_id VARCHAR(36), 
	visibility VARCHAR(64) NOT NULL, 
	source_type VARCHAR(64), 
	created_by VARCHAR(128), 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE rfq_line_items (
	rfq_line_item_id VARCHAR(64) NOT NULL, 
	rfq_id VARCHAR(64) NOT NULL, 
	product_category_id VARCHAR(64), 
	product_id VARCHAR(64), 
	product_name VARCHAR(255), 
	quantity NUMERIC(14, 4), 
	quantity_unit VARCHAR(64), 
	material VARCHAR(255), 
	color VARCHAR(128), 
	destination VARCHAR(255), 
	target_delivery_date DATE, 
	target_delivery_days INTEGER, 
	quality_requirements_json JSON NOT NULL, 
	packaging_requirements_json JSON NOT NULL, 
	metadata_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (rfq_line_item_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_rfq_line_items_created_at ON rfq_line_items (created_at);

CREATE INDEX ix_rfq_line_items_rfq_id ON rfq_line_items (rfq_id);

CREATE INDEX ix_rfq_line_items_tenant_id ON rfq_line_items (tenant_id);

CREATE TABLE rfq_outcomes (
	rfq_outcome_id VARCHAR(64) NOT NULL, 
	procurement_case_id VARCHAR(64) NOT NULL, 
	rfq_id VARCHAR(64), 
	buyer_id VARCHAR(64), 
	outcome VARCHAR(64) NOT NULL, 
	po_id VARCHAR(64), 
	closed_at DATETIME, 
	outcome_reason TEXT, 
	metadata_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (rfq_outcome_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_rfq_outcomes_buyer_id ON rfq_outcomes (buyer_id);

CREATE INDEX ix_rfq_outcomes_created_at ON rfq_outcomes (created_at);

CREATE INDEX ix_rfq_outcomes_po_id ON rfq_outcomes (po_id);

CREATE INDEX ix_rfq_outcomes_procurement_case_id ON rfq_outcomes (procurement_case_id);

CREATE INDEX ix_rfq_outcomes_rfq_id ON rfq_outcomes (rfq_id);

CREATE INDEX ix_rfq_outcomes_tenant_id ON rfq_outcomes (tenant_id);

CREATE TABLE rfq_recipients (
	rfq_id VARCHAR(36) NOT NULL, 
	supplier_actor_id VARCHAR(36), 
	status VARCHAR(64) NOT NULL, 
	id VARCHAR(36) NOT NULL, 
	tenant_id VARCHAR(36), 
	visibility VARCHAR(64) NOT NULL, 
	source_type VARCHAR(64), 
	created_by VARCHAR(128), 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE rfq_revision_links (
	rfq_revision_link_id VARCHAR(64) NOT NULL, 
	procurement_case_id VARCHAR(64) NOT NULL, 
	previous_rfq_id VARCHAR(64), 
	revised_rfq_id VARCHAR(64) NOT NULL, 
	revision_number INTEGER NOT NULL, 
	revision_type VARCHAR(64) NOT NULL, 
	revision_reason TEXT, 
	changed_fields_json JSON NOT NULL, 
	old_value_json JSON NOT NULL, 
	new_value_json JSON NOT NULL, 
	source_event_id VARCHAR(128), 
	started_by_entity_type VARCHAR(64) NOT NULL, 
	started_by_entity_id VARCHAR(64), 
	verification_status VARCHAR(64) NOT NULL, 
	confidence NUMERIC(5, 4), 
	confirmed_by VARCHAR(128), 
	confirmed_at DATETIME, 
	metadata_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (rfq_revision_link_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_rfq_rev_tenant_case ON rfq_revision_links (tenant_id, procurement_case_id);

CREATE INDEX ix_rfq_rev_tenant_previous ON rfq_revision_links (tenant_id, previous_rfq_id);

CREATE INDEX ix_rfq_rev_tenant_revised ON rfq_revision_links (tenant_id, revised_rfq_id);

CREATE INDEX ix_rfq_revision_links_created_at ON rfq_revision_links (created_at);

CREATE INDEX ix_rfq_revision_links_previous_rfq_id ON rfq_revision_links (previous_rfq_id);

CREATE INDEX ix_rfq_revision_links_procurement_case_id ON rfq_revision_links (procurement_case_id);

CREATE INDEX ix_rfq_revision_links_revised_rfq_id ON rfq_revision_links (revised_rfq_id);

CREATE INDEX ix_rfq_revision_links_tenant_id ON rfq_revision_links (tenant_id);

CREATE TABLE rfq_supplier_invitations (
	invitation_id VARCHAR(64) NOT NULL, 
	procurement_case_id VARCHAR(64) NOT NULL, 
	rfq_id VARCHAR(64) NOT NULL, 
	supplier_id VARCHAR(64) NOT NULL, 
	source_draft_id VARCHAR(64), 
	channel VARCHAR(64), 
	status VARCHAR(64) NOT NULL, 
	sent_at DATETIME, 
	first_response_at DATETIME, 
	last_response_at DATETIME, 
	metadata_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (invitation_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_rfq_supplier_inv_tenant_supplier ON rfq_supplier_invitations (tenant_id, supplier_id);

CREATE INDEX ix_rfq_supplier_invitations_created_at ON rfq_supplier_invitations (created_at);

CREATE INDEX ix_rfq_supplier_invitations_procurement_case_id ON rfq_supplier_invitations (procurement_case_id);

CREATE INDEX ix_rfq_supplier_invitations_rfq_id ON rfq_supplier_invitations (rfq_id);

CREATE INDEX ix_rfq_supplier_invitations_supplier_id ON rfq_supplier_invitations (supplier_id);

CREATE INDEX ix_rfq_supplier_invitations_tenant_id ON rfq_supplier_invitations (tenant_id);

CREATE TABLE rfqs (
	project_id VARCHAR(64) NOT NULL, 
	title VARCHAR(255) NOT NULL, 
	status VARCHAR(64) NOT NULL, 
	procurement_case_id VARCHAR(64), 
	buyer_id VARCHAR(64), 
	requirement_confirmed_by VARCHAR(128), 
	requirement_confirmed_at DATETIME, 
	metadata_json JSON NOT NULL, 
	id VARCHAR(36) NOT NULL, 
	tenant_id VARCHAR(36), 
	visibility VARCHAR(64) NOT NULL, 
	source_type VARCHAR(64), 
	created_by VARCHAR(128), 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE supplier_behavior_feature_snapshots (
	snapshot_id VARCHAR(64) NOT NULL, 
	supplier_id VARCHAR(64) NOT NULL, 
	feature_window VARCHAR(64) NOT NULL, 
	procurement_case_id VARCHAR(64), 
	rfq_id VARCHAR(64), 
	feature_json JSON NOT NULL, 
	source_observation_ids_json JSON NOT NULL, 
	generated_at DATETIME NOT NULL DEFAULT now(), 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (snapshot_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_supplier_behavior_feature_snapshots_created_at ON supplier_behavior_feature_snapshots (created_at);

CREATE INDEX ix_supplier_behavior_feature_snapshots_feature_window ON supplier_behavior_feature_snapshots (feature_window);

CREATE INDEX ix_supplier_behavior_feature_snapshots_procurement_case_id ON supplier_behavior_feature_snapshots (procurement_case_id);

CREATE INDEX ix_supplier_behavior_feature_snapshots_rfq_id ON supplier_behavior_feature_snapshots (rfq_id);

CREATE INDEX ix_supplier_behavior_feature_snapshots_supplier_id ON supplier_behavior_feature_snapshots (supplier_id);

CREATE INDEX ix_supplier_behavior_feature_snapshots_tenant_id ON supplier_behavior_feature_snapshots (tenant_id);

CREATE INDEX ix_supplier_feat_tenant_supplier_window ON supplier_behavior_feature_snapshots (tenant_id, supplier_id, feature_window);

CREATE TABLE supplier_contacts (
	supplier_contact_id VARCHAR(64) NOT NULL, 
	supplier_id VARCHAR(64) NOT NULL, 
	contact_name VARCHAR(255), 
	channel_type VARCHAR(64) NOT NULL, 
	channel_identifier VARCHAR(255) NOT NULL, 
	`role` VARCHAR(128), 
	is_primary_contact BOOL NOT NULL, 
	status VARCHAR(64) NOT NULL, 
	metadata_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (supplier_contact_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_supplier_contacts_created_at ON supplier_contacts (created_at);

CREATE INDEX ix_supplier_contacts_supplier_id ON supplier_contacts (supplier_id);

CREATE INDEX ix_supplier_contacts_tenant_id ON supplier_contacts (tenant_id);

CREATE TABLE supplier_quote_line_items (
	quote_line_item_id VARCHAR(64) NOT NULL, 
	quote_id VARCHAR(64) NOT NULL, 
	rfq_line_item_id VARCHAR(64), 
	product_category_id VARCHAR(64), 
	product_id VARCHAR(64), 
	unit_price NUMERIC(14, 4), 
	currency VARCHAR(16), 
	moq NUMERIC(14, 4), 
	lead_time_days INTEGER, 
	sample_days INTEGER, 
	payment_terms VARCHAR(255), 
	incoterms VARCHAR(64), 
	validity_days INTEGER, 
	remarks TEXT, 
	metadata_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (quote_line_item_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_supplier_quote_line_items_created_at ON supplier_quote_line_items (created_at);

CREATE INDEX ix_supplier_quote_line_items_quote_id ON supplier_quote_line_items (quote_id);

CREATE INDEX ix_supplier_quote_line_items_tenant_id ON supplier_quote_line_items (tenant_id);

CREATE TABLE supplier_quotes (
	idempotency_key VARCHAR(255), 
	request_sha256 VARCHAR(64), 
	quote_id VARCHAR(64) NOT NULL, 
	procurement_case_id VARCHAR(64) NOT NULL, 
	rfq_id VARCHAR(64) NOT NULL, 
	supplier_id VARCHAR(64) NOT NULL, 
	invitation_id VARCHAR(64), 
	source_event_id VARCHAR(128), 
	quote_status VARCHAR(64) NOT NULL, 
	received_at DATETIME, 
	parsed_confidence NUMERIC(5, 4), 
	verification_status VARCHAR(64) NOT NULL, 
	metadata_json JSON NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (quote_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_supplier_quotes_created_at ON supplier_quotes (created_at);

CREATE INDEX ix_supplier_quotes_procurement_case_id ON supplier_quotes (procurement_case_id);

CREATE INDEX ix_supplier_quotes_rfq_id ON supplier_quotes (rfq_id);

CREATE INDEX ix_supplier_quotes_supplier_id ON supplier_quotes (supplier_id);

CREATE INDEX ix_supplier_quotes_tenant_id ON supplier_quotes (tenant_id);

CREATE UNIQUE INDEX uq_supplier_quotes_tenant_idempotency ON supplier_quotes (tenant_id, idempotency_key);

CREATE TABLE supplier_response_packets (
	supplier_response_id VARCHAR(36) NOT NULL, 
	payload JSON NOT NULL, 
	id VARCHAR(36) NOT NULL, 
	tenant_id VARCHAR(36), 
	visibility VARCHAR(64) NOT NULL, 
	source_type VARCHAR(64), 
	created_by VARCHAR(128), 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE supplier_responses (
	rfq_id VARCHAR(36) NOT NULL, 
	supplier_actor_id VARCHAR(36), 
	status VARCHAR(64) NOT NULL, 
	payload JSON NOT NULL, 
	id VARCHAR(36) NOT NULL, 
	tenant_id VARCHAR(36), 
	visibility VARCHAR(64) NOT NULL, 
	source_type VARCHAR(64), 
	created_by VARCHAR(128), 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE suppliers (
	supplier_id VARCHAR(64) NOT NULL, 
	supplier_name VARCHAR(255) NOT NULL, 
	company_type VARCHAR(128), 
	country VARCHAR(128), 
	region VARCHAR(128), 
	timezone VARCHAR(64), 
	working_calendar_id VARCHAR(64), 
	status VARCHAR(64) NOT NULL, 
	risk_level VARCHAR(64), 
	metadata_json JSON NOT NULL, 
	name_en VARCHAR(255), 
	name_local VARCHAR(255), 
	legal_name_local VARCHAR(255), 
	local_language_code VARCHAR(16), 
	romanized_name VARCHAR(255), 
	name_source_type VARCHAR(64), 
	name_confidence_score FLOAT, 
	city VARCHAR(128), 
	address TEXT, 
	latitude FLOAT, 
	longitude FLOAT, 
	categories_json JSON, 
	capabilities_json JSON, 
	materials_json JSON, 
	languages_json JSON, 
	channels_json JSON, 
	email VARCHAR(255), 
	openclaw_peer_id VARCHAR(128), 
	payment_terms VARCHAR(128), 
	incoterms_json JSON, 
	logistics_modes_json JSON, 
	quality_score FLOAT, 
	delivery_score FLOAT, 
	price_score FLOAT, 
	past_performance_score FLOAT, 
	risk_tags_json JSON, 
	notes TEXT, 
	active BOOL, 
	is_synthetic BOOL, 
	source_type VARCHAR(64), 
	source_platform VARCHAR(128), 
	source_record_id VARCHAR(128), 
	seed_record_id VARCHAR(128), 
	generation_rule_version VARCHAR(128), 
	confidence_score FLOAT, 
	verified_by_human BOOL, 
	tenant_id VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (supplier_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_suppliers_created_at ON suppliers (created_at);

CREATE INDEX ix_suppliers_tenant_id ON suppliers (tenant_id);

CREATE TABLE system_generated_records (
	source_id VARCHAR(36), 
	raw_evidence_record_id VARCHAR(36), 
	source_platform VARCHAR(128), 
	project_id VARCHAR(36), 
	order_id VARCHAR(36), 
	rfq_id VARCHAR(36), 
	supplier_response_id VARCHAR(36), 
	observed_at DATETIME, 
	captured_at DATETIME, 
	raw_payload_hash VARCHAR(128), 
	payload JSON NOT NULL, 
	id VARCHAR(36) NOT NULL, 
	tenant_id VARCHAR(36), 
	visibility VARCHAR(64) NOT NULL, 
	source_type VARCHAR(64), 
	created_by VARCHAR(128), 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE tenants (
	name VARCHAR(255) NOT NULL, 
	id VARCHAR(36) NOT NULL, 
	tenant_id VARCHAR(36), 
	visibility VARCHAR(64) NOT NULL, 
	source_type VARCHAR(64), 
	created_by VARCHAR(128), 
	created_at DATETIME NOT NULL DEFAULT now(), 
	updated_at DATETIME NOT NULL DEFAULT now(), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE gpm_approval_audit (
	audit_id VARCHAR(128) NOT NULL, 
	packet_id VARCHAR(128) NOT NULL, 
	tenant_id VARCHAR(64) NOT NULL DEFAULT 'default', 
	operator_id VARCHAR(128) NOT NULL, 
	action VARCHAR(32) NOT NULL, 
	timestamp DATETIME NOT NULL DEFAULT now(), 
	notes TEXT, 
	PRIMARY KEY (audit_id), 
	FOREIGN KEY(packet_id) REFERENCES gpm_decision_packets (packet_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;


-- Version baseline for this complete, empty-database-only schema.
CREATE TABLE alembic_version (version_num VARCHAR(32) NOT NULL PRIMARY KEY) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin;
INSERT INTO alembic_version (version_num) VALUES ('202610040002');
