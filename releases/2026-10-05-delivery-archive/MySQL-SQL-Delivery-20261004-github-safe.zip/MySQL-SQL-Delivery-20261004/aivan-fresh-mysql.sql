-- Fresh aivan schema only. Choose an empty, approved MySQL database before execution.
-- MySQL DDL implicitly commits. This script does not select/create a database or alter credentials.
CREATE TABLE aivan_schema_migrations (
	version VARCHAR(64) NOT NULL, 
	candidate_sha VARCHAR(40) NOT NULL, 
	authorization_digest VARCHAR(64) NOT NULL, 
	backup_digest VARCHAR(64) NOT NULL, 
	evidence_digest VARCHAR(64) NOT NULL, 
	applied_at DATETIME NOT NULL, 
	PRIMARY KEY (version)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_aivan_schema_migrations_candidate_sha ON aivan_schema_migrations (candidate_sha);

CREATE TABLE approvals (
	approval_id VARCHAR(64) NOT NULL, 
	tenant_id VARCHAR(128) NOT NULL, 
	case_id VARCHAR(64) NOT NULL, 
	draft_id VARCHAR(64) NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	requested_by_actor_id VARCHAR(128) NOT NULL, 
	requested_by_actor_role VARCHAR(64) NOT NULL, 
	approver_id VARCHAR(128) NOT NULL, 
	approver_role VARCHAR(64) NOT NULL, 
	source_trace_id VARCHAR(255) NOT NULL, 
	authorization_basis TEXT NOT NULL, 
	rejection_reason TEXT NOT NULL, 
	created_at DATETIME NOT NULL, 
	decided_at DATETIME, 
	PRIMARY KEY (approval_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_approvals_approver_id ON approvals (approver_id);

CREATE INDEX ix_approvals_approver_role ON approvals (approver_role);

CREATE INDEX ix_approvals_case_id ON approvals (case_id);

CREATE INDEX ix_approvals_draft_id ON approvals (draft_id);

CREATE INDEX ix_approvals_source_trace_id ON approvals (source_trace_id);

CREATE INDEX ix_approvals_status ON approvals (status);

CREATE INDEX ix_approvals_tenant_id ON approvals (tenant_id);

CREATE TABLE audit_logs (
	audit_id VARCHAR(64) NOT NULL, 
	tenant_id VARCHAR(128) NOT NULL, 
	case_id VARCHAR(64) NOT NULL, 
	source_trace_id VARCHAR(255) NOT NULL, 
	event_type VARCHAR(128) NOT NULL, 
	actor_id VARCHAR(128) NOT NULL, 
	actor_role VARCHAR(64) NOT NULL, 
	conversation_role VARCHAR(64) NOT NULL, 
	authorization_basis TEXT NOT NULL, 
	before_json JSON NOT NULL, 
	after_json JSON NOT NULL, 
	rejection_reason TEXT NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (audit_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_audit_logs_actor_id ON audit_logs (actor_id);

CREATE INDEX ix_audit_logs_actor_role ON audit_logs (actor_role);

CREATE INDEX ix_audit_logs_case_id ON audit_logs (case_id);

CREATE INDEX ix_audit_logs_created_at ON audit_logs (created_at);

CREATE INDEX ix_audit_logs_event_type ON audit_logs (event_type);

CREATE INDEX ix_audit_logs_source_trace_id ON audit_logs (source_trace_id);

CREATE INDEX ix_audit_logs_tenant_id ON audit_logs (tenant_id);

CREATE TABLE case_conversations (
	conversation_record_id VARCHAR(64) NOT NULL, 
	tenant_id VARCHAR(128) NOT NULL, 
	case_id VARCHAR(64) NOT NULL, 
	external_conversation_id VARCHAR(128) NOT NULL, 
	conversation_role VARCHAR(64) NOT NULL, 
	channel VARCHAR(64) NOT NULL, 
	channel_account_id VARCHAR(128) NOT NULL, 
	thread_key VARCHAR(255) NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (conversation_record_id), 
	CONSTRAINT uq_case_conversation_binding UNIQUE (tenant_id, case_id, external_conversation_id, conversation_role, channel, channel_account_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_case_conversations_case_id ON case_conversations (case_id);

CREATE INDEX ix_case_conversations_conversation_role ON case_conversations (conversation_role);

CREATE INDEX ix_case_conversations_external_conversation_id ON case_conversations (external_conversation_id);

CREATE INDEX ix_case_conversations_tenant_id ON case_conversations (tenant_id);

CREATE INDEX ix_case_conversations_thread_key ON case_conversations (thread_key);

CREATE TABLE case_messages (
	message_record_id VARCHAR(64) NOT NULL, 
	tenant_id VARCHAR(128) NOT NULL, 
	case_id VARCHAR(64) NOT NULL, 
	conversation_record_id VARCHAR(64) NOT NULL, 
	participant_id VARCHAR(64) NOT NULL, 
	source_message_id VARCHAR(255) NOT NULL, 
	source_trace_id VARCHAR(255) NOT NULL, 
	actor_id VARCHAR(128) NOT NULL, 
	actor_role VARCHAR(64) NOT NULL, 
	asserted_by_actor_id VARCHAR(128) NOT NULL, 
	asserted_by_actor_role VARCHAR(64) NOT NULL, 
	conversation_role VARCHAR(64) NOT NULL, 
	message_type VARCHAR(64) NOT NULL, 
	payload_digest VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (message_record_id), 
	CONSTRAINT uq_case_message_source UNIQUE (tenant_id, case_id, conversation_record_id, source_message_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_case_messages_actor_id ON case_messages (actor_id);

CREATE INDEX ix_case_messages_actor_role ON case_messages (actor_role);

CREATE INDEX ix_case_messages_asserted_by_actor_id ON case_messages (asserted_by_actor_id);

CREATE INDEX ix_case_messages_asserted_by_actor_role ON case_messages (asserted_by_actor_role);

CREATE INDEX ix_case_messages_case_id ON case_messages (case_id);

CREATE INDEX ix_case_messages_conversation_record_id ON case_messages (conversation_record_id);

CREATE INDEX ix_case_messages_conversation_role ON case_messages (conversation_role);

CREATE INDEX ix_case_messages_participant_id ON case_messages (participant_id);

CREATE INDEX ix_case_messages_source_message_id ON case_messages (source_message_id);

CREATE INDEX ix_case_messages_source_trace_id ON case_messages (source_trace_id);

CREATE INDEX ix_case_messages_tenant_id ON case_messages (tenant_id);

CREATE TABLE case_participants (
	participant_id VARCHAR(64) NOT NULL, 
	tenant_id VARCHAR(128) NOT NULL, 
	case_id VARCHAR(64) NOT NULL, 
	conversation_record_id VARCHAR(64) NOT NULL, 
	actor_id VARCHAR(128) NOT NULL, 
	business_role VARCHAR(64) NOT NULL, 
	conversation_role VARCHAR(64) NOT NULL, 
	display_name VARCHAR(256) NOT NULL, 
	active BOOL NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (participant_id), 
	CONSTRAINT uq_case_participant_membership UNIQUE (tenant_id, case_id, actor_id, business_role, conversation_record_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_case_participants_actor_id ON case_participants (actor_id);

CREATE INDEX ix_case_participants_business_role ON case_participants (business_role);

CREATE INDEX ix_case_participants_case_id ON case_participants (case_id);

CREATE INDEX ix_case_participants_conversation_record_id ON case_participants (conversation_record_id);

CREATE INDEX ix_case_participants_conversation_role ON case_participants (conversation_role);

CREATE INDEX ix_case_participants_tenant_id ON case_participants (tenant_id);

CREATE TABLE event_reversals (
	reversal_id VARCHAR(64) NOT NULL, 
	tenant_id VARCHAR(128) NOT NULL, 
	case_id VARCHAR(64) NOT NULL, 
	source_event_id VARCHAR(64) NOT NULL, 
	correction_event_id VARCHAR(64) NOT NULL, 
	idempotency_key VARCHAR(64) NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	actor_id VARCHAR(128) NOT NULL, 
	actor_role VARCHAR(64) NOT NULL, 
	source_trace_id VARCHAR(255) NOT NULL, 
	reason TEXT NOT NULL, 
	source_payload_digest VARCHAR(64) NOT NULL, 
	impact_digest VARCHAR(64) NOT NULL, 
	before_ref_json JSON NOT NULL, 
	after_ref_json JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (reversal_id), 
	CONSTRAINT uq_event_reversal_source UNIQUE (tenant_id, source_event_id), 
	CONSTRAINT uq_event_reversal_idempotency UNIQUE (tenant_id, idempotency_key)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_event_reversals_actor_id ON event_reversals (actor_id);

CREATE INDEX ix_event_reversals_case_id ON event_reversals (case_id);

CREATE INDEX ix_event_reversals_correction_event_id ON event_reversals (correction_event_id);

CREATE INDEX ix_event_reversals_created_at ON event_reversals (created_at);

CREATE INDEX ix_event_reversals_idempotency_key ON event_reversals (idempotency_key);

CREATE INDEX ix_event_reversals_source_event_id ON event_reversals (source_event_id);

CREATE INDEX ix_event_reversals_source_trace_id ON event_reversals (source_trace_id);

CREATE INDEX ix_event_reversals_status ON event_reversals (status);

CREATE INDEX ix_event_reversals_tenant_id ON event_reversals (tenant_id);

CREATE TABLE execution_events (
	event_id VARCHAR(64) NOT NULL, 
	tenant_id VARCHAR(128) NOT NULL, 
	project_id VARCHAR(64) NOT NULL, 
	source_trace_id VARCHAR(255) NOT NULL, 
	event_type VARCHAR(128) NOT NULL, 
	actor VARCHAR(128) NOT NULL, 
	actor_id VARCHAR(128) NOT NULL, 
	actor_role VARCHAR(64) NOT NULL, 
	conversation_role VARCHAR(64) NOT NULL, 
	authorization_basis TEXT NOT NULL, 
	before_json JSON NOT NULL, 
	after_json JSON NOT NULL, 
	rejection_reason TEXT NOT NULL, 
	derived_from_event_id VARCHAR(64) NOT NULL, 
	payload_digest VARCHAR(64) NOT NULL, 
	correction_status VARCHAR(32) NOT NULL, 
	summary TEXT NOT NULL, 
	payload_json JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (event_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_execution_events_actor_id ON execution_events (actor_id);

CREATE INDEX ix_execution_events_correction_status ON execution_events (correction_status);

CREATE INDEX ix_execution_events_created_at ON execution_events (created_at);

CREATE INDEX ix_execution_events_derived_from_event_id ON execution_events (derived_from_event_id);

CREATE INDEX ix_execution_events_event_type ON execution_events (event_type);

CREATE INDEX ix_execution_events_payload_digest ON execution_events (payload_digest);

CREATE INDEX ix_execution_events_project_id ON execution_events (project_id);

CREATE INDEX ix_execution_events_source_trace_id ON execution_events (source_trace_id);

CREATE INDEX ix_execution_events_tenant_id ON execution_events (tenant_id);

CREATE TABLE inquiry_drafts (
	draft_id VARCHAR(64) NOT NULL, 
	tenant_id VARCHAR(128) NOT NULL, 
	project_id VARCHAR(64) NOT NULL, 
	participant_id VARCHAR(64) NOT NULL, 
	source_trace_id VARCHAR(255) NOT NULL, 
	conversation_id VARCHAR(128) NOT NULL, 
	channel VARCHAR(64) NOT NULL, 
	channel_account_id VARCHAR(128) NOT NULL, 
	target_peer_id VARCHAR(256) NOT NULL, 
	target_role VARCHAR(64) NOT NULL, 
	message_text TEXT NOT NULL, 
	message_type VARCHAR(64) NOT NULL, 
	attachments_json JSON NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	created_by_agent VARCHAR(128) NOT NULL, 
	created_by_actor_id VARCHAR(128) NOT NULL, 
	created_by_actor_role VARCHAR(64) NOT NULL, 
	approved_by VARCHAR(128) NOT NULL, 
	approval_id VARCHAR(64) NOT NULL, 
	authorization_basis TEXT NOT NULL, 
	notes TEXT NOT NULL, 
	created_at DATETIME NOT NULL, 
	approved_at DATETIME, 
	sent_at DATETIME, 
	PRIMARY KEY (draft_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_inquiry_drafts_approval_id ON inquiry_drafts (approval_id);

CREATE INDEX ix_inquiry_drafts_channel_account_id ON inquiry_drafts (channel_account_id);

CREATE INDEX ix_inquiry_drafts_participant_id ON inquiry_drafts (participant_id);

CREATE INDEX ix_inquiry_drafts_project_id ON inquiry_drafts (project_id);

CREATE INDEX ix_inquiry_drafts_source_trace_id ON inquiry_drafts (source_trace_id);

CREATE INDEX ix_inquiry_drafts_status ON inquiry_drafts (status);

CREATE INDEX ix_inquiry_drafts_tenant_id ON inquiry_drafts (tenant_id);

CREATE TABLE openclaw_accounts (
	account_connection_id VARCHAR(128) NOT NULL, 
	logical_account_connection_id VARCHAR(128) NOT NULL, 
	tenant_id VARCHAR(128) NOT NULL, 
	platform VARCHAR(64) NOT NULL, 
	channel VARCHAR(64) NOT NULL, 
	channel_account_id VARCHAR(256) NOT NULL, 
	owner_user_id VARCHAR(128) NOT NULL, 
	display_name VARCHAR(256) NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	permissions_json JSON NOT NULL, 
	allowed_actions_json JSON NOT NULL, 
	expires_at VARCHAR(64) NOT NULL, 
	metadata_json JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (account_connection_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_openclaw_accounts_logical_account_connection_id ON openclaw_accounts (logical_account_connection_id);

CREATE INDEX ix_openclaw_accounts_platform ON openclaw_accounts (platform);

CREATE INDEX ix_openclaw_accounts_status ON openclaw_accounts (status);

CREATE INDEX ix_openclaw_accounts_tenant_id ON openclaw_accounts (tenant_id);

CREATE TABLE platforms (
	platform_id VARCHAR(64) NOT NULL, 
	logical_platform_id VARCHAR(64) NOT NULL, 
	tenant_id VARCHAR(128) NOT NULL, 
	display_name VARCHAR(256) NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	domain_patterns_json JSON NOT NULL, 
	supported_channels_json JSON NOT NULL, 
	supported_connectors_json JSON NOT NULL, 
	allow_marketplace_search BOOL NOT NULL, 
	allow_openclaw_account_management BOOL NOT NULL, 
	allow_seller_im BOOL NOT NULL, 
	risk_weight_modifier FLOAT NOT NULL, 
	added_by VARCHAR(128) NOT NULL, 
	user_confirmed BOOL NOT NULL, 
	built_in BOOL NOT NULL, 
	notes TEXT NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (platform_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_platforms_logical_platform_id ON platforms (logical_platform_id);

CREATE INDEX ix_platforms_status ON platforms (status);

CREATE INDEX ix_platforms_tenant_id ON platforms (tenant_id);

CREATE TABLE processed_inbound_events (
	id VARCHAR(64) NOT NULL, 
	tenant_id VARCHAR(128) NOT NULL, 
	idempotency_key VARCHAR(255) NOT NULL, 
	project_id VARCHAR(64) NOT NULL, 
	event_type VARCHAR(128) NOT NULL, 
	result_json JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_processed_inbound_events_created_at ON processed_inbound_events (created_at);

CREATE UNIQUE INDEX ix_processed_inbound_events_idempotency_key ON processed_inbound_events (idempotency_key);

CREATE INDEX ix_processed_inbound_events_project_id ON processed_inbound_events (project_id);

CREATE INDEX ix_processed_inbound_events_tenant_id ON processed_inbound_events (tenant_id);

CREATE TABLE projects (
	project_id VARCHAR(64) NOT NULL, 
	tenant_id VARCHAR(128) NOT NULL, 
	conversation_id VARCHAR(128) NOT NULL, 
	channel VARCHAR(64) NOT NULL, 
	channel_account_id VARCHAR(128) NOT NULL, 
	customer_id VARCHAR(128) NOT NULL, 
	customer_display_name VARCHAR(256) NOT NULL, 
	status VARCHAR(64) NOT NULL, 
	case_state VARCHAR(64) NOT NULL, 
	source_trace_id VARCHAR(255) NOT NULL, 
	category VARCHAR(128) NOT NULL, 
	requirement_json JSON, 
	selected_option_json JSON, 
	notes TEXT NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (project_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_projects_case_state ON projects (case_state);

CREATE INDEX ix_projects_conversation_id ON projects (conversation_id);

CREATE INDEX ix_projects_customer_id ON projects (customer_id);

CREATE INDEX ix_projects_source_trace_id ON projects (source_trace_id);

CREATE INDEX ix_projects_status ON projects (status);

CREATE INDEX ix_projects_tenant_id ON projects (tenant_id);

CREATE TABLE relay_receipts (
	receipt_id VARCHAR(64) NOT NULL, 
	tenant_id VARCHAR(128) NOT NULL, 
	draft_id VARCHAR(64) NOT NULL, 
	case_id VARCHAR(64) NOT NULL, 
	channel VARCHAR(64) NOT NULL, 
	channel_account_id VARCHAR(128) NOT NULL, 
	conversation_id VARCHAR(128) NOT NULL, 
	external_message_id VARCHAR(255) NOT NULL, 
	receipt_reference VARCHAR(255) NOT NULL, 
	idempotency_key VARCHAR(255) NOT NULL, 
	confirmed_by VARCHAR(128) NOT NULL, 
	source_trace_id VARCHAR(255) NOT NULL, 
	metadata_json JSON NOT NULL, 
	confirmed_at DATETIME NOT NULL, 
	PRIMARY KEY (receipt_id), 
	CONSTRAINT uq_relay_receipt_draft UNIQUE (tenant_id, draft_id), 
	CONSTRAINT uq_relay_receipt_idempotency UNIQUE (tenant_id, idempotency_key)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_relay_receipts_case_id ON relay_receipts (case_id);

CREATE INDEX ix_relay_receipts_channel ON relay_receipts (channel);

CREATE INDEX ix_relay_receipts_confirmed_by ON relay_receipts (confirmed_by);

CREATE INDEX ix_relay_receipts_draft_id ON relay_receipts (draft_id);

CREATE INDEX ix_relay_receipts_idempotency_key ON relay_receipts (idempotency_key);

CREATE INDEX ix_relay_receipts_source_trace_id ON relay_receipts (source_trace_id);

CREATE INDEX ix_relay_receipts_tenant_id ON relay_receipts (tenant_id);

CREATE TABLE suppliers (
	supplier_id VARCHAR(64) NOT NULL, 
	logical_supplier_id VARCHAR(64) NOT NULL, 
	tenant_id VARCHAR(128) NOT NULL, 
	name VARCHAR(256) NOT NULL, 
	company_type VARCHAR(128) NOT NULL, 
	categories_json JSON NOT NULL, 
	capabilities_json JSON NOT NULL, 
	materials_json JSON NOT NULL, 
	moq_min INTEGER NOT NULL, 
	moq_max INTEGER NOT NULL, 
	daily_capacity INTEGER NOT NULL, 
	monthly_capacity INTEGER NOT NULL, 
	region VARCHAR(128) NOT NULL, 
	country VARCHAR(64) NOT NULL, 
	languages_json JSON NOT NULL, 
	channels_json JSON NOT NULL, 
	email VARCHAR(256) NOT NULL, 
	openclaw_peer_id VARCHAR(256) NOT NULL, 
	payment_terms VARCHAR(256) NOT NULL, 
	incoterms_json JSON NOT NULL, 
	logistics_modes_json JSON NOT NULL, 
	quality_score FLOAT NOT NULL, 
	delivery_score FLOAT NOT NULL, 
	price_score FLOAT NOT NULL, 
	past_performance_score FLOAT NOT NULL, 
	risk_tags_json JSON NOT NULL, 
	notes TEXT NOT NULL, 
	active BOOL NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (supplier_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_suppliers_logical_supplier_id ON suppliers (logical_supplier_id);

CREATE INDEX ix_suppliers_name ON suppliers (name);

CREATE INDEX ix_suppliers_tenant_id ON suppliers (tenant_id);

CREATE TABLE user_preferences (
	preference_id VARCHAR(64) NOT NULL, 
	tenant_id VARCHAR(128) NOT NULL, 
	user_id VARCHAR(128) NOT NULL, 
	preference_type VARCHAR(128) NOT NULL, 
	value_json JSON NOT NULL, 
	source VARCHAR(128) NOT NULL, 
	confidence FLOAT NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (preference_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_user_preferences_preference_type ON user_preferences (preference_type);

CREATE INDEX ix_user_preferences_tenant_id ON user_preferences (tenant_id);

CREATE INDEX ix_user_preferences_user_id ON user_preferences (user_id);

