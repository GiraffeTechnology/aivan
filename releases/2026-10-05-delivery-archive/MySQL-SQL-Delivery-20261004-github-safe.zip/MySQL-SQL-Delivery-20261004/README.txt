MySQL delivery | 2026-10-04 | Locally verified candidate

Supersedes the withdrawn earlier SQL bundle
The SQL-only ZIP previously delivered on 4 October 2026 at 19:59 UTC is withdrawn.
Its SHA256 was 95ee1d8467e75e7825c05fd22225c584eb3c8488da58d76896c818dd4591f983.
Do not use its provider schema for rollout. This revision preserves full prefixed
source-event identifiers in five VARCHAR(128) columns and adds a safe existing-
schema migration. If earlier SQL was already applied, do not reimport fresh SQL;
use the installed read-only plan and reviewed migration path below.

Purpose
Prepare the approved MySQL databases without an onsite source build. This bundle
contains no credentials, account grants or production data. SQL and code files
contain no actual deployment addresses. The separate private manual handoff is
for the authorized operator only. It is
not proof of production activation or an accepted all-green release.

Contents
- abcdyi-fresh-mysql.sql: 81 application tables plus the Alembic version baseline.
- aivan-fresh-mysql.sql: 16 application tables.
- provider-fresh-mysql.sql: 61 application tables plus its Alembic baseline.
- drivers/: verified prebuilt pure-Python aiomysql0.3.2 and PyMySQL1.2.3 wheels.
- verification.json: exact local verification scope and checksums.
- SHA256SUMS: validate these bytes before use.

Use only on separate, approved, empty database namespaces
These stores have overlapping table names and different schemas. They can share
an existing MySQL server, but must not be imported into one unnamespaced database.
The files do not create/select databases or create users. Reuse existing approved
DB names, accounts, port, TLS settings and least-privilege grants from private ops.
Do not place a password in a command line, repository, chat or this bundle.

Read-only preflight through the existing private client profile
mysql --defaults-extra-file=/APPROVED/PRIVATE/client.cnf --database="$ABCDYI_DB" \
  --execute="SELECT VERSION(), DATABASE(); SELECT COUNT(*) AS existing_tables FROM information_schema.tables WHERE table_schema=DATABASE();"
Repeat for Aivan and the reference-provider namespace. Require zero existing
tables before using any fresh-schema SQL file. Verify a recoverable backup for an
existing namespace. MySQL DDL implicitly commits; there is no automatic rollback.

Manual application, after target, permission and empty-schema checks
mysql --defaults-extra-file=/APPROVED/PRIVATE/client.cnf --database="$ABCDYI_DB" < abcdyi-fresh-mysql.sql
mysql --defaults-extra-file=/APPROVED/PRIVATE/client.cnf --database="$AIVAN_DB" < aivan-fresh-mysql.sql
mysql --defaults-extra-file=/APPROVED/PRIVATE/client.cnf --database="$PROVIDER_DB" < provider-fresh-mysql.sql
Use the actual approved client profile for each namespace if the accounts differ.
Never add --force. Stop on the first failure and preserve the partial result.
If an existing compatible private-provider HTTP API is used, do not import a
reference-provider schema into that external service.

Existing populated databases
Do NOT run these fresh-schema files. Use the SQL-capable candidate's read-only
' database-plan ' and explicit plan-bound ' database-migrate ' workflow. An older
SQLite-only installer does not have this workflow and must not be used as a
production fallback. The private handoff document describes the exact commands.
Populated unversioned schemas need explicit reconciliation; they are not silently
stamped as compatible. Re-plan after any partial migration failure.

Runtime bindings
Aivan: AIVAN_DB_URL=mysql+pymysql://.../APPROVED_AIVAN_DB
abcdYi: DATABASE_URL=mysql+aiomysql://.../APPROVED_ABCDYI_DB
Reference provider: GIRAFFE_DB_DATABASE_URL=mysql+pymysql://.../APPROVED_PROVIDER_DB
The private-provider HTTP endpoint is a separate setting from these SQL URLs.
Keep full URLs in the existing protected configuration source, never this bundle.
The driver wheels are packaging inputs; do not bypass an installed runtime's
integrity inventory with an ad-hoc site-packages edit. SQL application itself
uses the existing MySQL client and requires no Python package build.

Verified evidence
Real isolated MySQL Community8.4.11: all three complete fresh schemas applied;
native Alembic upgrade head and final downgrade/re-upgrade passed;60 critical
API tests passed, including authentication, requirements, RFQ/reply/approval,
order, production, QC, logistics and buyer sign-off. The shared GLTG test service
is mocked in this API regression; this is not a live-channel/model test.
The source-level installer SQL runner independently planned/applied all three
MySQL schemas, verified a repeat no-op and rejected incompatible identity
collation. PostgreSQL regression retained1286 passing tests and7 optional skips.
No formal target server was connected, configured, migrated or publicly deployed.

Provider lineage correction
Alembic 202610040002 widens the five existing source_event_id fields to 128
characters. Original stable IDs and existing rows remain intact. An online
downgrade checks all affected tables before any DDL and refuses to truncate
long lineage. Database restore is a separately authorized operations procedure.
Actual MySQL migration tests covered upgrade, restart, preservation, refusal
of destructive shrink, safe downgrade and re-upgrade.
