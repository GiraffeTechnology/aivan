-- Fresh abcdyi schema only. Choose an empty, approved MySQL database before execution.
-- MySQL DDL implicitly commits. This script does not select/create a database or alter credentials.
CREATE TABLE actors (
	actor_id VARCHAR(36) NOT NULL, 
	name VARCHAR(255) NOT NULL, 
	actor_type VARCHAR(64) NOT NULL, 
	default_language VARCHAR(16), 
	contact_channels_json JSON NOT NULL, 
	capabilities_json JSON NOT NULL, 
	profile_json JSON NOT NULL, 
	is_active BOOL NOT NULL, 
	created_at DATETIME(6) NOT NULL, 
	updated_at DATETIME(6) NOT NULL, 
	PRIMARY KEY (actor_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_actors_actor_type ON actors (actor_type);

CREATE TABLE audit_logs (
	id CHAR(32) NOT NULL, 
	tenant_id CHAR(32) NOT NULL, 
	user_id CHAR(32), 
	action VARCHAR(255) NOT NULL, 
	resource_type VARCHAR(100), 
	resource_id VARCHAR(255), 
	payload JSON, 
	ip_address VARCHAR(64), 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE decision_packets (
	id CHAR(32) NOT NULL, 
	project_id CHAR(32) NOT NULL, 
	generated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	comparison_summary TEXT, 
	risk_summary TEXT, 
	missing_field_summary TEXT, 
	human_approval_status VARCHAR(50) NOT NULL, 
	recommended_option_id CHAR(32), 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE delivery_feasibility_packets (
	id CHAR(32) NOT NULL, 
	tenant_id CHAR(32) NOT NULL, 
	project_id CHAR(32), 
	order_id CHAR(32) NOT NULL, 
	source VARCHAR(50) NOT NULL, 
	status VARCHAR(50) NOT NULL, 
	earliest_delivery_date DATE, 
	most_likely_delivery_date DATE, 
	risk_adjusted_delivery_date DATE, 
	committable_delivery_date DATE, 
	required_delivery_date DATE, 
	delivery_feasibility VARCHAR(50) NOT NULL, 
	days_vs_deadline INTEGER, 
	critical_path_json JSON, 
	critical_path_days INTEGER, 
	ranked_options_json JSON, 
	option_count INTEGER NOT NULL, 
	risk_flags_json JSON, 
	missing_evidence_json JSON, 
	raw_gltg_packet_json JSON, 
	explanation TEXT, 
	confidence VARCHAR(20) NOT NULL, 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE legal_notices (
	notice_id VARCHAR(36) NOT NULL, 
	notice_type VARCHAR(64) NOT NULL, 
	version VARCHAR(16) NOT NULL, 
	text_en TEXT NOT NULL, 
	text_zh TEXT, 
	effective_at DATETIME(6) NOT NULL, 
	metadata_json JSON NOT NULL, 
	created_at DATETIME(6) NOT NULL, 
	PRIMARY KEY (notice_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE media_evidence (
	media_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36), 
	milestone_id VARCHAR(36), 
	uploaded_by_actor_id VARCHAR(36), 
	artifact_id VARCHAR(36), 
	media_type VARCHAR(32), 
	description TEXT, 
	visibility_check_status VARCHAR(16), 
	completeness_check_status VARCHAR(16), 
	buyer_review_status VARCHAR(32), 
	notes TEXT, 
	created_at DATETIME(6), 
	updated_at DATETIME(6), 
	metadata_json JSON, 
	PRIMARY KEY (media_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_media_evidence_milestone_id ON media_evidence (milestone_id);

CREATE INDEX ix_media_evidence_project_id ON media_evidence (project_id);

CREATE TABLE merchandiser_execution_plans (
	plan_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36), 
	order_id VARCHAR(36), 
	supplier_actor_id VARCHAR(36), 
	buyer_actor_id VARCHAR(36), 
	category VARCHAR(64), 
	current_order_state VARCHAR(64), 
	task_ids_json JSON, 
	milestone_ids_json JSON, 
	created_at DATETIME(6), 
	updated_at DATETIME(6), 
	metadata_json JSON, 
	PRIMARY KEY (plan_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_merchandiser_execution_plans_order_id ON merchandiser_execution_plans (order_id);

CREATE INDEX ix_merchandiser_execution_plans_project_id ON merchandiser_execution_plans (project_id);

CREATE TABLE merchandiser_tasks (
	task_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36), 
	order_id VARCHAR(36), 
	assigned_side VARCHAR(32), 
	assigned_actor_id VARCHAR(36), 
	role_context_id VARCHAR(36), 
	task_type VARCHAR(64), 
	due_at DATETIME(6), 
	status VARCHAR(32), 
	priority VARCHAR(16), 
	payload_json JSON, 
	created_at DATETIME(6), 
	updated_at DATETIME(6), 
	metadata_json JSON, 
	PRIMARY KEY (task_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_merchandiser_tasks_project_id ON merchandiser_tasks (project_id);

CREATE INDEX ix_merchandiser_tasks_status ON merchandiser_tasks (status);

CREATE INDEX ix_merchandiser_tasks_task_type ON merchandiser_tasks (task_type);

CREATE TABLE order_exceptions (
	exception_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36), 
	order_id VARCHAR(36), 
	raised_by_actor_id VARCHAR(36), 
	exception_type VARCHAR(64), 
	severity VARCHAR(16), 
	description TEXT, 
	proposed_options_json JSON, 
	buyer_confirmation_required BOOL, 
	human_review_required BOOL, 
	status VARCHAR(32), 
	created_at DATETIME(6), 
	updated_at DATETIME(6), 
	metadata_json JSON, 
	PRIMARY KEY (exception_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_order_exceptions_project_id ON order_exceptions (project_id);

CREATE TABLE order_milestones (
	milestone_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36), 
	order_id VARCHAR(36), 
	milestone_type VARCHAR(64), 
	sequence_no INTEGER, 
	expected_at DATETIME(6), 
	actual_at DATETIME(6), 
	status VARCHAR(32), 
	evidence_required BOOL, 
	required_media_types_json JSON, 
	assigned_actor_id VARCHAR(36), 
	buyer_confirmation_required BOOL, 
	metadata_json JSON, 
	created_at DATETIME(6), 
	updated_at DATETIME(6), 
	PRIMARY KEY (milestone_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_order_milestones_project_id ON order_milestones (project_id);

CREATE TABLE qc_comparison_reports (
	report_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36) NOT NULL, 
	milestone_id VARCHAR(36), 
	overall_result VARCHAR(32) NOT NULL, 
	overall_score FLOAT NOT NULL, 
	severity VARCHAR(16) NOT NULL, 
	provider_name VARCHAR(32) NOT NULL, 
	model_name VARCHAR(64) NOT NULL, 
	requested_provider VARCHAR(32) NOT NULL, 
	fallback_used BOOL NOT NULL, 
	m_side_feedback_zh TEXT NOT NULL, 
	m_side_feedback_en TEXT NOT NULL, 
	b_side_summary TEXT NOT NULL, 
	image_count INTEGER NOT NULL, 
	frames_used INTEGER NOT NULL, 
	buyer_confirmation_required BOOL NOT NULL, 
	saved_at VARCHAR(32) NOT NULL, 
	PRIMARY KEY (report_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_qc_comparison_reports_milestone_id ON qc_comparison_reports (milestone_id);

CREATE INDEX ix_qc_comparison_reports_project_id ON qc_comparison_reports (project_id);

CREATE TABLE qc_process_cards (
	process_card_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36) NOT NULL, 
	category VARCHAR(64) NOT NULL, 
	material_spec TEXT, 
	color_spec VARCHAR(256), 
	size_spec TEXT, 
	finish_spec VARCHAR(256), 
	defect_criteria TEXT, 
	supplier_notes TEXT, 
	is_active BOOL NOT NULL, 
	created_at VARCHAR(32) NOT NULL, 
	updated_at VARCHAR(32) NOT NULL, 
	PRIMARY KEY (process_card_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_qc_process_cards_project_id ON qc_process_cards (project_id);

CREATE TABLE qc_reference_images (
	ref_image_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36) NOT NULL, 
	milestone_type VARCHAR(64), 
	image_path VARCHAR(512) NOT NULL, 
	description TEXT, 
	uploaded_by_actor_id VARCHAR(36) NOT NULL, 
	is_active BOOL NOT NULL, 
	created_at VARCHAR(32) NOT NULL, 
	PRIMARY KEY (ref_image_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_qc_reference_images_project_id ON qc_reference_images (project_id);

CREATE TABLE schema_registry (
	schema_id VARCHAR(36) NOT NULL, 
	industry VARCHAR(64) NOT NULL, 
	category VARCHAR(64) NOT NULL, 
	schema_version VARCHAR(16) NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	created_at DATETIME(6) NOT NULL, 
	updated_at DATETIME(6) NOT NULL, 
	metadata_json JSON NOT NULL, 
	PRIMARY KEY (schema_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE tenants (
	id CHAR(32) NOT NULL, 
	name VARCHAR(255) NOT NULL, 
	slug VARCHAR(100) NOT NULL, 
	is_active BOOL NOT NULL, 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	UNIQUE (slug)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE unit_dictionary (
	unit_id VARCHAR(36) NOT NULL, 
	unit_name VARCHAR(64) NOT NULL, 
	unit_symbol VARCHAR(32) NOT NULL, 
	unit_type VARCHAR(64) NOT NULL, 
	conversion_rule_json JSON NOT NULL, 
	created_at DATETIME(6) NOT NULL, 
	PRIMARY KEY (unit_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE approval_requests (
	id CHAR(32) NOT NULL, 
	tenant_id CHAR(32) NOT NULL, 
	action_type VARCHAR(100) NOT NULL, 
	resource_type VARCHAR(100), 
	resource_id CHAR(32), 
	proposed_payload JSON, 
	affected_participant_id CHAR(32), 
	evidence JSON, 
	risk_flags JSON, 
	status VARCHAR(50) NOT NULL, 
	reviewed_by CHAR(32), 
	reviewed_at DATETIME(6), 
	review_notes TEXT, 
	consumed_at DATETIME(6), 
	created_by CHAR(32), 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES tenants (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE decision_options (
	id CHAR(32) NOT NULL, 
	packet_id CHAR(32) NOT NULL, 
	option_index INTEGER NOT NULL, 
	supplier_combination JSON, 
	unit_price FLOAT, 
	total_price FLOAT, 
	currency VARCHAR(10), 
	lead_time_breakdown JSON, 
	calculated_total_lead_time_days INTEGER, 
	supplier_stated_lead_time_days INTEGER, 
	risk_flags JSON, 
	missing_fields JSON, 
	recommendation_reason TEXT, 
	evidence JSON, 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(packet_id) REFERENCES decision_packets (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE field_definitions (
	field_id VARCHAR(36) NOT NULL, 
	schema_id VARCHAR(36) NOT NULL, 
	field_name VARCHAR(128) NOT NULL, 
	normalized_field_name VARCHAR(128) NOT NULL, 
	field_type VARCHAR(32) NOT NULL, 
	unit VARCHAR(32), 
	description VARCHAR(512), 
	required_level VARCHAR(32) NOT NULL, 
	validation_rule_json JSON NOT NULL, 
	example_values_json JSON NOT NULL, 
	source VARCHAR(128) NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	created_at DATETIME(6) NOT NULL, 
	updated_at DATETIME(6) NOT NULL, 
	PRIMARY KEY (field_id), 
	FOREIGN KEY(schema_id) REFERENCES schema_registry (schema_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_field_definitions_normalized_field_name ON field_definitions (normalized_field_name);

CREATE TABLE field_proposals (
	proposal_id VARCHAR(36) NOT NULL, 
	schema_id VARCHAR(36) NOT NULL, 
	candidate_field_name VARCHAR(128) NOT NULL, 
	normalized_field_name VARCHAR(128) NOT NULL, 
	field_type VARCHAR(32) NOT NULL, 
	suggested_unit VARCHAR(32), 
	business_reason VARCHAR(1024), 
	example_count INTEGER NOT NULL, 
	project_count INTEGER NOT NULL, 
	supplier_count INTEGER NOT NULL, 
	confidence_score FLOAT NOT NULL, 
	risk_level VARCHAR(32) NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	created_at DATETIME(6) NOT NULL, 
	updated_at DATETIME(6) NOT NULL, 
	metadata_json JSON NOT NULL, 
	PRIMARY KEY (proposal_id), 
	FOREIGN KEY(schema_id) REFERENCES schema_registry (schema_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE participants (
	id CHAR(32) NOT NULL, 
	tenant_id CHAR(32) NOT NULL, 
	name VARCHAR(255) NOT NULL, 
	company_registration VARCHAR(100), 
	country VARCHAR(100), 
	contact_email VARCHAR(255), 
	contact_phone VARCHAR(100), 
	is_active BOOL NOT NULL, 
	profile_completeness_score FLOAT NOT NULL, 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES tenants (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE shop_capability_profiles (
	profile_id VARCHAR(36) NOT NULL, 
	actor_id VARCHAR(36) NOT NULL, 
	profile_name VARCHAR(256), 
	machines_json JSON NOT NULL, 
	tooling_inventory_json JSON NOT NULL, 
	qc_equipment_json JSON NOT NULL, 
	material_inventory_json JSON NOT NULL, 
	in_house_processes_json JSON NOT NULL, 
	outsourced_processes_json JSON NOT NULL, 
	schedule_summary_json JSON NOT NULL, 
	created_at DATETIME(6) NOT NULL, 
	updated_at DATETIME(6) NOT NULL, 
	PRIMARY KEY (profile_id), 
	FOREIGN KEY(actor_id) REFERENCES actors (actor_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE users (
	id CHAR(32) NOT NULL, 
	tenant_id CHAR(32) NOT NULL, 
	email VARCHAR(255) NOT NULL, 
	hashed_password VARCHAR(255) NOT NULL, 
	full_name VARCHAR(255), 
	is_active BOOL NOT NULL, 
	is_platform_admin BOOL NOT NULL, 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES tenants (id), 
	UNIQUE (email)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE field_aliases (
	alias_id VARCHAR(36) NOT NULL, 
	field_id VARCHAR(36) NOT NULL, 
	alias_text VARCHAR(256) NOT NULL, 
	language VARCHAR(16), 
	created_at DATETIME(6) NOT NULL, 
	PRIMARY KEY (alias_id), 
	FOREIGN KEY(field_id) REFERENCES field_definitions (field_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE field_promotion_decisions (
	decision_id VARCHAR(36) NOT NULL, 
	proposal_id VARCHAR(36) NOT NULL, 
	decision VARCHAR(32) NOT NULL, 
	decided_by VARCHAR(128) NOT NULL, 
	reason VARCHAR(1024), 
	created_at DATETIME(6) NOT NULL, 
	metadata_json JSON NOT NULL, 
	PRIMARY KEY (decision_id), 
	FOREIGN KEY(proposal_id) REFERENCES field_proposals (proposal_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE participant_capabilities (
	id CHAR(32) NOT NULL, 
	participant_id CHAR(32) NOT NULL, 
	capability_type VARCHAR(100), 
	description TEXT, 
	verified BOOL NOT NULL, 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(participant_id) REFERENCES participants (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE participant_matches (
	id CHAR(32) NOT NULL, 
	project_id CHAR(32) NOT NULL, 
	participant_id CHAR(32) NOT NULL, 
	recommended_role VARCHAR(100) NOT NULL, 
	match_score FLOAT NOT NULL, 
	score_breakdown JSON, 
	matched_requirements JSON, 
	unmatched_requirements JSON, 
	risk_flags JSON, 
	missing_participant_data JSON, 
	recommendation_reason TEXT, 
	requires_human_approval BOOL NOT NULL, 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(participant_id) REFERENCES participants (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE participant_permissions (
	id CHAR(32) NOT NULL, 
	participant_id CHAR(32) NOT NULL, 
	project_id CHAR(32), 
	permission_name VARCHAR(100) NOT NULL, 
	granted_by CHAR(32) NOT NULL, 
	granted_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(participant_id) REFERENCES participants (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE participant_profiles (
	id CHAR(32) NOT NULL, 
	participant_id CHAR(32) NOT NULL, 
	product_categories JSON, 
	fabric_capabilities JSON, 
	quantity_range_min INTEGER, 
	quantity_range_max INTEGER, 
	moq INTEGER, 
	lead_time_days_min INTEGER, 
	lead_time_days_max INTEGER, 
	supported_trade_terms JSON, 
	supported_countries JSON, 
	certifications JSON, 
	languages JSON, 
	updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	UNIQUE (participant_id), 
	FOREIGN KEY(participant_id) REFERENCES participants (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE participant_roles (
	id CHAR(32) NOT NULL, 
	participant_id CHAR(32) NOT NULL, 
	role_name VARCHAR(100) NOT NULL, 
	is_active BOOL NOT NULL, 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(participant_id) REFERENCES participants (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE projects (
	id CHAR(32) NOT NULL, 
	tenant_id CHAR(32), 
	title VARCHAR(255), 
	status VARCHAR(50) NOT NULL, 
	created_by CHAR(32), 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	project_id VARCHAR(36), 
	original_buyer_actor_id VARCHAR(36), 
	main_supplier_actor_id VARCHAR(36), 
	category VARCHAR(128), 
	product_summary TEXT, 
	quantity INTEGER, 
	product_tier VARCHAR(32), 
	created_by_channel VARCHAR(64), 
	metadata_json JSON, 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES tenants (id), 
	FOREIGN KEY(created_by) REFERENCES users (id), 
	UNIQUE (project_id), 
	FOREIGN KEY(original_buyer_actor_id) REFERENCES actors (actor_id), 
	FOREIGN KEY(main_supplier_actor_id) REFERENCES actors (actor_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE user_roles (
	id CHAR(32) NOT NULL, 
	user_id CHAR(32) NOT NULL, 
	role_name VARCHAR(100) NOT NULL, 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE artifacts (
	artifact_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36), 
	owner_actor_id VARCHAR(36), 
	artifact_type VARCHAR(32) NOT NULL, 
	file_name VARCHAR(512), 
	file_ref VARCHAR(1024) NOT NULL, 
	file_hash VARCHAR(128), 
	mime_type VARCHAR(128), 
	size_bytes INTEGER, 
	metadata_json JSON NOT NULL, 
	product_tier VARCHAR(32) NOT NULL, 
	cap_level VARCHAR(32), 
	encryption_enabled BOOL NOT NULL, 
	dynamic_watermark_enabled BOOL NOT NULL, 
	secure_viewer_enabled BOOL NOT NULL, 
	warning_acknowledged BOOL NOT NULL, 
	created_at DATETIME(6) NOT NULL, 
	updated_at DATETIME(6) NOT NULL, 
	PRIMARY KEY (artifact_id), 
	FOREIGN KEY(project_id) REFERENCES projects (project_id), 
	FOREIGN KEY(owner_actor_id) REFERENCES actors (actor_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE buyer_inquiries (
	id CHAR(32) NOT NULL, 
	project_id CHAR(32) NOT NULL, 
	buyer_participant_id CHAR(32), 
	raw_text TEXT, 
	raw_files_metadata JSON, 
	source_channel VARCHAR(100), 
	received_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(project_id) REFERENCES projects (id), 
	FOREIGN KEY(buyer_participant_id) REFERENCES participants (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE cad_requirement_packets (
	packet_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36) NOT NULL, 
	original_buyer_actor_id VARCHAR(36) NOT NULL, 
	main_supplier_actor_id VARCHAR(36), 
	file_refs_json JSON NOT NULL, 
	source_types_json JSON NOT NULL, 
	part_summary VARCHAR(2048), 
	material VARCHAR(256), 
	quantity INTEGER, 
	dimensions_json JSON NOT NULL, 
	tolerance_requirements_json JSON NOT NULL, 
	surface_finish_requirements_json JSON NOT NULL, 
	thread_requirements_json JSON NOT NULL, 
	heat_treatment_requirements_json JSON NOT NULL, 
	operation_requirements_json JSON NOT NULL, 
	qc_requirements_json JSON NOT NULL, 
	packaging_requirements_json JSON NOT NULL, 
	delivery_deadline VARCHAR(32), 
	missing_information_json JSON NOT NULL, 
	extraction_confidence_score FLOAT NOT NULL, 
	created_at DATETIME(6) NOT NULL, 
	updated_at DATETIME(6) NOT NULL, 
	PRIMARY KEY (packet_id), 
	FOREIGN KEY(project_id) REFERENCES projects (project_id), 
	FOREIGN KEY(original_buyer_actor_id) REFERENCES actors (actor_id), 
	FOREIGN KEY(main_supplier_actor_id) REFERENCES actors (actor_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE dependency_needs (
	dependency_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36) NOT NULL, 
	created_by_actor_id VARCHAR(36) NOT NULL, 
	dependency_type VARCHAR(64) NOT NULL, 
	description VARCHAR(1024) NOT NULL, 
	required_specs_json JSON NOT NULL, 
	quantity_required FLOAT, 
	required_by_date VARCHAR(32), 
	risk_level VARCHAR(32) NOT NULL, 
	why_needed VARCHAR(1024) NOT NULL, 
	candidate_actor_ids_json JSON NOT NULL, 
	source VARCHAR(128) NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	created_at DATETIME(6) NOT NULL, 
	updated_at DATETIME(6) NOT NULL, 
	PRIMARY KEY (dependency_id), 
	FOREIGN KEY(project_id) REFERENCES projects (project_id), 
	FOREIGN KEY(created_by_actor_id) REFERENCES actors (actor_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE dynamic_order_forms (
	id CHAR(32) NOT NULL, 
	project_id CHAR(32) NOT NULL, 
	current_version INTEGER NOT NULL, 
	is_locked BOOL NOT NULL, 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	UNIQUE (project_id), 
	FOREIGN KEY(project_id) REFERENCES projects (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE procurement_edges (
	edge_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36) NOT NULL, 
	from_actor_id VARCHAR(36) NOT NULL, 
	to_actor_id VARCHAR(36) NOT NULL, 
	edge_type VARCHAR(64) NOT NULL, 
	parent_edge_id VARCHAR(36), 
	inquiry_id VARCHAR(36), 
	response_id VARCHAR(36), 
	status VARCHAR(32) NOT NULL, 
	created_at DATETIME(6) NOT NULL, 
	updated_at DATETIME(6) NOT NULL, 
	metadata_json JSON NOT NULL, 
	PRIMARY KEY (edge_id), 
	FOREIGN KEY(project_id) REFERENCES projects (project_id), 
	FOREIGN KEY(from_actor_id) REFERENCES actors (actor_id), 
	FOREIGN KEY(to_actor_id) REFERENCES actors (actor_id), 
	FOREIGN KEY(parent_edge_id) REFERENCES procurement_edges (edge_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_procurement_edges_edge_type ON procurement_edges (edge_type);

CREATE INDEX ix_procurement_edges_from_actor_id ON procurement_edges (from_actor_id);

CREATE INDEX ix_procurement_edges_parent_edge_id ON procurement_edges (parent_edge_id);

CREATE INDEX ix_procurement_edges_project_id ON procurement_edges (project_id);

CREATE INDEX ix_procurement_edges_status ON procurement_edges (status);

CREATE INDEX ix_procurement_edges_to_actor_id ON procurement_edges (to_actor_id);

CREATE TABLE project_memberships (
	id CHAR(32) NOT NULL, 
	project_id CHAR(32) NOT NULL, 
	user_id CHAR(32) NOT NULL, 
	`role` VARCHAR(40) NOT NULL, 
	participant_id CHAR(32), 
	granted_by CHAR(32) NOT NULL, 
	revoked_at DATETIME(6), 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	CONSTRAINT uq_project_member UNIQUE (project_id, user_id), 
	FOREIGN KEY(project_id) REFERENCES projects (id), 
	FOREIGN KEY(user_id) REFERENCES users (id), 
	FOREIGN KEY(participant_id) REFERENCES participants (id), 
	FOREIGN KEY(granted_by) REFERENCES users (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE replacement_alerts (
	id CHAR(32) NOT NULL, 
	participant_id CHAR(32) NOT NULL, 
	project_id CHAR(32), 
	trigger_reason TEXT NOT NULL, 
	quality_issue_count INTEGER NOT NULL, 
	status VARCHAR(50) NOT NULL, 
	reviewed_by CHAR(32), 
	reviewed_at DATETIME(6), 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(participant_id) REFERENCES participants (id), 
	FOREIGN KEY(project_id) REFERENCES projects (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE structured_requirements (
	requirement_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36) NOT NULL, 
	source_actor_id VARCHAR(36) NOT NULL, 
	source_message_id VARCHAR(36), 
	raw_input_refs_json JSON NOT NULL, 
	category VARCHAR(128), 
	quantity INTEGER, 
	material VARCHAR(256), 
	specs_json JSON NOT NULL, 
	deadline VARCHAR(64), 
	destination VARCHAR(256), 
	missing_fields_json JSON NOT NULL, 
	confidence_score FLOAT NOT NULL, 
	created_at DATETIME(6) NOT NULL, 
	updated_at DATETIME(6) NOT NULL, 
	PRIMARY KEY (requirement_id), 
	FOREIGN KEY(project_id) REFERENCES projects (project_id), 
	FOREIGN KEY(source_actor_id) REFERENCES actors (actor_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE supplier_response_rollups (
	rollup_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36) NOT NULL, 
	main_supplier_actor_id VARCHAR(36) NOT NULL, 
	can_accept_order BOOL, 
	main_capacity_summary VARCHAR(2048), 
	approved_upstream_options_json JSON NOT NULL, 
	material_basis_json JSON NOT NULL, 
	trim_basis_json JSON NOT NULL, 
	subcontract_basis_json JSON NOT NULL, 
	qc_basis_json JSON NOT NULL, 
	packaging_basis_json JSON NOT NULL, 
	logistics_basis_json JSON NOT NULL, 
	price_basis_json JSON NOT NULL, 
	lead_time_basis_json JSON NOT NULL, 
	unresolved_dependencies_json JSON NOT NULL, 
	risk_flags_json JSON NOT NULL, 
	completeness_score FLOAT NOT NULL, 
	confidence_score FLOAT NOT NULL, 
	recommended_response_to_buyer_en TEXT, 
	recommended_response_to_buyer_zh TEXT, 
	cad_requirement_packet_id VARCHAR(36), 
	cad_cnc_match_id VARCHAR(36), 
	capability_fit_report_id VARCHAR(36), 
	cnc_parameter_match_summary_json JSON NOT NULL, 
	can_make_in_house BOOL, 
	recommended_machine_ids_json JSON NOT NULL, 
	capability_gaps_json JSON NOT NULL, 
	upstream_dependency_basis_json JSON NOT NULL, 
	created_at DATETIME(6) NOT NULL, 
	updated_at DATETIME(6) NOT NULL, 
	PRIMARY KEY (rollup_id), 
	FOREIGN KEY(project_id) REFERENCES projects (project_id), 
	FOREIGN KEY(main_supplier_actor_id) REFERENCES actors (actor_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_supplier_response_rollups_project_id ON supplier_response_rollups (project_id);

CREATE TABLE supplier_score_snapshots (
	snapshot_id VARCHAR(36) NOT NULL, 
	actor_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36), 
	response_speed_score FLOAT, 
	acceptance_rate_score FLOAT, 
	on_time_delivery_score FLOAT, 
	media_cooperation_score FLOAT, 
	quality_score FLOAT, 
	lead_time_accuracy_score FLOAT, 
	quote_completeness_score FLOAT, 
	capability_confidence_score FLOAT, 
	risk_score FLOAT, 
	computed_from_json JSON NOT NULL, 
	created_at DATETIME(6) NOT NULL, 
	PRIMARY KEY (snapshot_id), 
	FOREIGN KEY(actor_id) REFERENCES actors (actor_id), 
	FOREIGN KEY(project_id) REFERENCES projects (project_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE cad_cnc_match_results (
	match_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36) NOT NULL, 
	actor_id VARCHAR(36) NOT NULL, 
	cad_requirement_packet_id VARCHAR(36) NOT NULL, 
	shop_capability_profile_id VARCHAR(36) NOT NULL, 
	can_make_in_house BOOL NOT NULL, 
	recommended_machine_ids_json JSON NOT NULL, 
	machine_fit_score FLOAT NOT NULL, 
	work_envelope_fit VARCHAR(32) NOT NULL, 
	material_fit VARCHAR(32) NOT NULL, 
	tolerance_fit VARCHAR(32) NOT NULL, 
	surface_finish_fit VARCHAR(32) NOT NULL, 
	tooling_fit VARCHAR(32) NOT NULL, 
	qc_fit VARCHAR(32) NOT NULL, 
	schedule_fit VARCHAR(32) NOT NULL, 
	required_upstream_dependencies_json JSON NOT NULL, 
	required_subcontract_dependencies_json JSON NOT NULL, 
	risk_flags_json JSON NOT NULL, 
	missing_information_json JSON NOT NULL, 
	confidence_score FLOAT NOT NULL, 
	explanation TEXT, 
	created_at DATETIME(6) NOT NULL, 
	updated_at DATETIME(6) NOT NULL, 
	PRIMARY KEY (match_id), 
	FOREIGN KEY(project_id) REFERENCES projects (project_id), 
	FOREIGN KEY(actor_id) REFERENCES actors (actor_id), 
	FOREIGN KEY(cad_requirement_packet_id) REFERENCES cad_requirement_packets (packet_id), 
	FOREIGN KEY(shop_capability_profile_id) REFERENCES shop_capability_profiles (profile_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_cad_cnc_match_results_project_id ON cad_cnc_match_results (project_id);

CREATE TABLE channel_sessions (
	session_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36), 
	edge_id VARCHAR(36), 
	actor_id VARCHAR(36) NOT NULL, 
	counterparty_actor_id VARCHAR(36), 
	channel_type VARCHAR(32) NOT NULL, 
	channel_user_id VARCHAR(256), 
	state_json JSON NOT NULL, 
	last_message_at DATETIME(6), 
	created_at DATETIME(6) NOT NULL, 
	updated_at DATETIME(6) NOT NULL, 
	PRIMARY KEY (session_id), 
	FOREIGN KEY(project_id) REFERENCES projects (project_id), 
	FOREIGN KEY(edge_id) REFERENCES procurement_edges (edge_id), 
	FOREIGN KEY(actor_id) REFERENCES actors (actor_id), 
	FOREIGN KEY(counterparty_actor_id) REFERENCES actors (actor_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE clarification_questions (
	id CHAR(32) NOT NULL, 
	form_id CHAR(32) NOT NULL, 
	question_text TEXT NOT NULL, 
	field_reference VARCHAR(100), 
	status VARCHAR(50) NOT NULL, 
	answer_text TEXT, 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	answered_at DATETIME(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(form_id) REFERENCES dynamic_order_forms (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE dynamic_order_form_versions (
	id CHAR(32) NOT NULL, 
	form_id CHAR(32) NOT NULL, 
	version_number INTEGER NOT NULL, 
	fields JSON NOT NULL, 
	ai_generated_fields JSON, 
	human_confirmed_fields JSON, 
	missing_fields JSON, 
	created_by CHAR(32), 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(form_id) REFERENCES dynamic_order_forms (id), 
	FOREIGN KEY(created_by) REFERENCES users (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE manufacturing_feature_sets (
	feature_set_id VARCHAR(36) NOT NULL, 
	packet_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36) NOT NULL, 
	required_processes_json JSON NOT NULL, 
	required_machine_types_json JSON NOT NULL, 
	min_axis_requirement INTEGER, 
	work_envelope_required_json JSON NOT NULL, 
	material_required VARCHAR(256), 
	tolerance_class VARCHAR(64), 
	surface_finish_class VARCHAR(64), 
	thread_or_hole_features_json JSON NOT NULL, 
	heat_treatment_required BOOL NOT NULL, 
	external_process_likely_required BOOL NOT NULL, 
	qc_required_json JSON NOT NULL, 
	risk_flags_json JSON NOT NULL, 
	missing_information_json JSON NOT NULL, 
	created_at DATETIME(6) NOT NULL, 
	updated_at DATETIME(6) NOT NULL, 
	PRIMARY KEY (feature_set_id), 
	FOREIGN KEY(packet_id) REFERENCES cad_requirement_packets (packet_id), 
	FOREIGN KEY(project_id) REFERENCES projects (project_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE raw_messages (
	id CHAR(32) NOT NULL, 
	project_id CHAR(32) NOT NULL, 
	inquiry_id CHAR(32), 
	direction VARCHAR(20) NOT NULL, 
	sender VARCHAR(255), 
	content TEXT, 
	metadata JSON, 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(project_id) REFERENCES projects (id), 
	FOREIGN KEY(inquiry_id) REFERENCES buyer_inquiries (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE role_contexts (
	role_context_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36) NOT NULL, 
	edge_id VARCHAR(36), 
	actor_id VARCHAR(36) NOT NULL, 
	counterparty_actor_id VARCHAR(36), 
	`role` VARCHAR(32) NOT NULL, 
	role_reason VARCHAR(512) NOT NULL, 
	permissions_json JSON NOT NULL, 
	can_create_upstream_inquiry BOOL NOT NULL, 
	can_approve_upstream_option BOOL NOT NULL, 
	can_submit_response_to_buyer BOOL NOT NULL, 
	created_at DATETIME(6) NOT NULL, 
	metadata_json JSON NOT NULL, 
	PRIMARY KEY (role_context_id), 
	FOREIGN KEY(project_id) REFERENCES projects (project_id), 
	FOREIGN KEY(edge_id) REFERENCES procurement_edges (edge_id), 
	FOREIGN KEY(actor_id) REFERENCES actors (actor_id), 
	FOREIGN KEY(counterparty_actor_id) REFERENCES actors (actor_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_role_contexts_actor_id ON role_contexts (actor_id);

CREATE INDEX ix_role_contexts_project_id ON role_contexts (project_id);

CREATE TABLE supplier_inquiries (
	inquiry_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36) NOT NULL, 
	edge_id VARCHAR(36) NOT NULL, 
	from_actor_id VARCHAR(36) NOT NULL, 
	to_actor_id VARCHAR(36) NOT NULL, 
	requirement_id VARCHAR(36), 
	message_text_en TEXT, 
	message_text_zh TEXT, 
	message_text_local TEXT, 
	requested_fields_json JSON NOT NULL, 
	required_reply_schema_json JSON NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	created_at DATETIME(6) NOT NULL, 
	updated_at DATETIME(6) NOT NULL, 
	PRIMARY KEY (inquiry_id), 
	FOREIGN KEY(project_id) REFERENCES projects (project_id), 
	FOREIGN KEY(edge_id) REFERENCES procurement_edges (edge_id), 
	FOREIGN KEY(from_actor_id) REFERENCES actors (actor_id), 
	FOREIGN KEY(to_actor_id) REFERENCES actors (actor_id), 
	FOREIGN KEY(requirement_id) REFERENCES structured_requirements (requirement_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE upstream_approval_requests (
	approval_request_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36) NOT NULL, 
	dependency_id VARCHAR(36), 
	requested_by_actor_id VARCHAR(36) NOT NULL, 
	approval_mode VARCHAR(32) NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	options_json JSON NOT NULL, 
	approved_option_id VARCHAR(36), 
	approved_by_actor_id VARCHAR(36), 
	approved_by_mode VARCHAR(32), 
	created_at DATETIME(6) NOT NULL, 
	updated_at DATETIME(6) NOT NULL, 
	metadata_json JSON NOT NULL, 
	PRIMARY KEY (approval_request_id), 
	FOREIGN KEY(project_id) REFERENCES projects (project_id), 
	FOREIGN KEY(dependency_id) REFERENCES dependency_needs (dependency_id), 
	FOREIGN KEY(requested_by_actor_id) REFERENCES actors (actor_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE upstream_inquiries (
	upstream_inquiry_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36) NOT NULL, 
	edge_id VARCHAR(36) NOT NULL, 
	dependency_id VARCHAR(36) NOT NULL, 
	parent_main_supplier_actor_id VARCHAR(36) NOT NULL, 
	upstream_actor_id VARCHAR(36) NOT NULL, 
	message_text_en TEXT, 
	message_text_zh TEXT, 
	requested_fields_json JSON NOT NULL, 
	required_reply_schema_json JSON NOT NULL, 
	due_time VARCHAR(64), 
	dispatch_channel VARCHAR(32), 
	status VARCHAR(32) NOT NULL, 
	created_at DATETIME(6) NOT NULL, 
	updated_at DATETIME(6) NOT NULL, 
	PRIMARY KEY (upstream_inquiry_id), 
	FOREIGN KEY(project_id) REFERENCES projects (project_id), 
	FOREIGN KEY(edge_id) REFERENCES procurement_edges (edge_id), 
	FOREIGN KEY(dependency_id) REFERENCES dependency_needs (dependency_id), 
	FOREIGN KEY(parent_main_supplier_actor_id) REFERENCES actors (actor_id), 
	FOREIGN KEY(upstream_actor_id) REFERENCES actors (actor_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE upstream_options (
	option_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36) NOT NULL, 
	dependency_id VARCHAR(36) NOT NULL, 
	upstream_actor_id VARCHAR(36) NOT NULL, 
	option_label VARCHAR(32) NOT NULL, 
	price_summary VARCHAR(256), 
	lead_time_summary VARCHAR(256), 
	risk_summary VARCHAR(512), 
	score FLOAT NOT NULL, 
	reason VARCHAR(1024), 
	response_ids_json JSON NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	created_at DATETIME(6) NOT NULL, 
	updated_at DATETIME(6) NOT NULL, 
	PRIMARY KEY (option_id), 
	FOREIGN KEY(project_id) REFERENCES projects (project_id), 
	FOREIGN KEY(dependency_id) REFERENCES dependency_needs (dependency_id), 
	FOREIGN KEY(upstream_actor_id) REFERENCES actors (actor_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE actor_execution_events (
	event_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36), 
	edge_id VARCHAR(36), 
	actor_id VARCHAR(36), 
	role_context_id VARCHAR(36), 
	event_type VARCHAR(64) NOT NULL, 
	payload_json JSON NOT NULL, 
	source_channel VARCHAR(32), 
	source_message_id VARCHAR(36), 
	confidence_score FLOAT, 
	created_at DATETIME(6) NOT NULL, 
	metadata_json JSON NOT NULL, 
	PRIMARY KEY (event_id), 
	FOREIGN KEY(project_id) REFERENCES projects (project_id), 
	FOREIGN KEY(edge_id) REFERENCES procurement_edges (edge_id), 
	FOREIGN KEY(actor_id) REFERENCES actors (actor_id), 
	FOREIGN KEY(role_context_id) REFERENCES role_contexts (role_context_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_execution_events_created_at ON actor_execution_events (created_at);

CREATE INDEX ix_execution_events_event_type ON actor_execution_events (event_type);

CREATE INDEX ix_execution_events_project_id ON actor_execution_events (project_id);

CREATE TABLE capability_fit_reports (
	report_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36) NOT NULL, 
	actor_id VARCHAR(36) NOT NULL, 
	cad_cnc_match_id VARCHAR(36) NOT NULL, 
	buyer_facing_summary_en TEXT, 
	buyer_facing_summary_zh TEXT, 
	internal_summary TEXT, 
	can_quote_now BOOL NOT NULL, 
	can_make_in_house BOOL NOT NULL, 
	recommended_next_actions_json JSON NOT NULL, 
	required_upstream_inquiries_json JSON NOT NULL, 
	required_subcontractor_inquiries_json JSON NOT NULL, 
	risk_flags_json JSON NOT NULL, 
	confidence_score FLOAT NOT NULL, 
	created_at DATETIME(6) NOT NULL, 
	updated_at DATETIME(6) NOT NULL, 
	PRIMARY KEY (report_id), 
	FOREIGN KEY(project_id) REFERENCES projects (project_id), 
	FOREIGN KEY(actor_id) REFERENCES actors (actor_id), 
	FOREIGN KEY(cad_cnc_match_id) REFERENCES cad_cnc_match_results (match_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE messages (
	message_id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36), 
	project_id VARCHAR(36), 
	edge_id VARCHAR(36), 
	role_context_id VARCHAR(36), 
	sender_actor_id VARCHAR(36), 
	receiver_actor_id VARCHAR(36), 
	channel_type VARCHAR(32) NOT NULL, 
	direction VARCHAR(16) NOT NULL, 
	raw_text TEXT, 
	normalized_text TEXT, 
	attachments_json JSON NOT NULL, 
	parsed_intent VARCHAR(128), 
	parsed_entities_json JSON NOT NULL, 
	confidence_score FLOAT, 
	created_at DATETIME(6) NOT NULL, 
	metadata_json JSON NOT NULL, 
	PRIMARY KEY (message_id), 
	FOREIGN KEY(session_id) REFERENCES channel_sessions (session_id), 
	FOREIGN KEY(project_id) REFERENCES projects (project_id), 
	FOREIGN KEY(edge_id) REFERENCES procurement_edges (edge_id), 
	FOREIGN KEY(role_context_id) REFERENCES role_contexts (role_context_id), 
	FOREIGN KEY(sender_actor_id) REFERENCES actors (actor_id), 
	FOREIGN KEY(receiver_actor_id) REFERENCES actors (actor_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_messages_project_id ON messages (project_id);

CREATE INDEX ix_messages_session_id ON messages (session_id);

CREATE TABLE orders (
	id CHAR(32) NOT NULL, 
	project_id CHAR(32) NOT NULL, 
	approved_option_id CHAR(32), 
	locked_form_version_id CHAR(32), 
	status VARCHAR(50) NOT NULL, 
	order_number VARCHAR(100), 
	buyer_participant_id CHAR(32), 
	confirmed_at DATETIME(6), 
	buyer_signed_off_at DATETIME(6), 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(approved_option_id) REFERENCES decision_options (id), 
	FOREIGN KEY(locked_form_version_id) REFERENCES dynamic_order_form_versions (id), 
	UNIQUE (order_number), 
	FOREIGN KEY(buyer_participant_id) REFERENCES participants (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE rfqs (
	id CHAR(32) NOT NULL, 
	project_id CHAR(32) NOT NULL, 
	form_version_id CHAR(32) NOT NULL, 
	status VARCHAR(50) NOT NULL, 
	rfq_content JSON, 
	ai_generated BOOL NOT NULL, 
	human_approved_by CHAR(32), 
	human_approved_at DATETIME(6), 
	sent_at DATETIME(6), 
	expires_at DATETIME(6), 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(form_version_id) REFERENCES dynamic_order_form_versions (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE upstream_responses (
	upstream_response_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36) NOT NULL, 
	edge_id VARCHAR(36) NOT NULL, 
	upstream_inquiry_id VARCHAR(36) NOT NULL, 
	dependency_id VARCHAR(36) NOT NULL, 
	from_actor_id VARCHAR(36) NOT NULL, 
	can_supply BOOL NOT NULL, 
	matched_specs_json JSON NOT NULL, 
	price FLOAT, 
	currency VARCHAR(8), 
	moq FLOAT, 
	available_quantity FLOAT, 
	lead_time_days INTEGER, 
	earliest_dispatch_date VARCHAR(32), 
	quality_notes VARCHAR(1024), 
	substitute_options_json JSON NOT NULL, 
	risk_flags_json JSON NOT NULL, 
	confidence_score FLOAT NOT NULL, 
	completeness_score FLOAT NOT NULL, 
	raw_message TEXT, 
	created_at DATETIME(6) NOT NULL, 
	updated_at DATETIME(6) NOT NULL, 
	PRIMARY KEY (upstream_response_id), 
	FOREIGN KEY(project_id) REFERENCES projects (project_id), 
	FOREIGN KEY(edge_id) REFERENCES procurement_edges (edge_id), 
	FOREIGN KEY(upstream_inquiry_id) REFERENCES upstream_inquiries (upstream_inquiry_id), 
	FOREIGN KEY(dependency_id) REFERENCES dependency_needs (dependency_id), 
	FOREIGN KEY(from_actor_id) REFERENCES actors (actor_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE upstream_supplier_responses (
	response_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36) NOT NULL, 
	edge_id VARCHAR(36) NOT NULL, 
	inquiry_id VARCHAR(36), 
	from_actor_id VARCHAR(36) NOT NULL, 
	to_actor_id VARCHAR(36) NOT NULL, 
	can_supply BOOL, 
	price FLOAT, 
	currency VARCHAR(8), 
	moq FLOAT, 
	available_quantity FLOAT, 
	lead_time_days INTEGER, 
	earliest_dispatch_date VARCHAR(32), 
	capacity_basis_json JSON NOT NULL, 
	material_basis_json JSON NOT NULL, 
	subcontract_basis_json JSON NOT NULL, 
	qc_basis_json JSON NOT NULL, 
	logistics_basis_json JSON NOT NULL, 
	risk_flags_json JSON NOT NULL, 
	raw_message TEXT, 
	parsed_json JSON NOT NULL, 
	confidence_score FLOAT NOT NULL, 
	completeness_score FLOAT NOT NULL, 
	created_at DATETIME(6) NOT NULL, 
	updated_at DATETIME(6) NOT NULL, 
	PRIMARY KEY (response_id), 
	FOREIGN KEY(project_id) REFERENCES projects (project_id), 
	FOREIGN KEY(edge_id) REFERENCES procurement_edges (edge_id), 
	FOREIGN KEY(inquiry_id) REFERENCES supplier_inquiries (inquiry_id), 
	FOREIGN KEY(from_actor_id) REFERENCES actors (actor_id), 
	FOREIGN KEY(to_actor_id) REFERENCES actors (actor_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE entity_dynamic_values (
	value_id VARCHAR(36) NOT NULL, 
	entity_type VARCHAR(64) NOT NULL, 
	entity_id VARCHAR(36) NOT NULL, 
	field_id VARCHAR(36) NOT NULL, 
	field_value VARCHAR(1024) NOT NULL, 
	unit VARCHAR(32), 
	confidence_score FLOAT NOT NULL, 
	source VARCHAR(128), 
	source_message_id VARCHAR(36), 
	source_artifact_id VARCHAR(36), 
	created_at DATETIME(6) NOT NULL, 
	metadata_json JSON NOT NULL, 
	PRIMARY KEY (value_id), 
	FOREIGN KEY(field_id) REFERENCES field_definitions (field_id), 
	FOREIGN KEY(source_message_id) REFERENCES messages (message_id), 
	FOREIGN KEY(source_artifact_id) REFERENCES artifacts (artifact_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_entity_dynamic_values_entity_type_id ON entity_dynamic_values (entity_type, entity_id);

CREATE TABLE execution_events (
	id CHAR(32) NOT NULL, 
	tenant_id CHAR(32) NOT NULL, 
	project_id CHAR(32), 
	order_id CHAR(32), 
	participant_id CHAR(32), 
	event_type VARCHAR(100) NOT NULL, 
	payload JSON NOT NULL, 
	triggered_by_user_id CHAR(32), 
	occurred_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES tenants (id), 
	FOREIGN KEY(project_id) REFERENCES projects (id), 
	FOREIGN KEY(order_id) REFERENCES orders (id), 
	FOREIGN KEY(participant_id) REFERENCES participants (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE milestones (
	id CHAR(32) NOT NULL, 
	order_id CHAR(32) NOT NULL, 
	milestone_type VARCHAR(100) NOT NULL, 
	planned_date DATETIME(6), 
	predicted_date DATETIME(6), 
	actual_date DATETIME(6), 
	status VARCHAR(50) NOT NULL, 
	responsible_participant_id CHAR(32), 
	notes TEXT, 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(order_id) REFERENCES orders (id), 
	FOREIGN KEY(responsible_participant_id) REFERENCES participants (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE observed_fields (
	observed_field_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36), 
	actor_id VARCHAR(36), 
	source_message_id VARCHAR(36), 
	source_artifact_id VARCHAR(36), 
	candidate_field_name VARCHAR(128) NOT NULL, 
	normalized_field_name VARCHAR(128), 
	candidate_value VARCHAR(512), 
	candidate_unit VARCHAR(32), 
	normalized_value VARCHAR(512), 
	confidence_score FLOAT NOT NULL, 
	evidence_text VARCHAR(2048), 
	created_at DATETIME(6) NOT NULL, 
	metadata_json JSON NOT NULL, 
	PRIMARY KEY (observed_field_id), 
	FOREIGN KEY(project_id) REFERENCES projects (project_id), 
	FOREIGN KEY(actor_id) REFERENCES actors (actor_id), 
	FOREIGN KEY(source_message_id) REFERENCES messages (message_id), 
	FOREIGN KEY(source_artifact_id) REFERENCES artifacts (artifact_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX ix_observed_fields_normalized_field_name ON observed_fields (normalized_field_name);

CREATE TABLE order_lines (
	id CHAR(32) NOT NULL, 
	order_id CHAR(32) NOT NULL, 
	line_number INTEGER NOT NULL, 
	description VARCHAR(500) NOT NULL, 
	quantity INTEGER NOT NULL, 
	unit VARCHAR(50) NOT NULL, 
	unit_price FLOAT, 
	currency VARCHAR(10), 
	attributes JSON, 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(order_id) REFERENCES orders (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE production_monitoring_packets (
	id CHAR(32) NOT NULL, 
	order_id CHAR(32) NOT NULL, 
	standard_completion_date DATETIME(6), 
	predicted_completion_date DATETIME(6), 
	delay_risk_level VARCHAR(50), 
	responsible_participant_id CHAR(32), 
	delayed_milestones JSON, 
	recommended_action TEXT, 
	expedite_alert_required BOOL NOT NULL, 
	human_approval_required BOOL NOT NULL, 
	generated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(order_id) REFERENCES orders (id), 
	FOREIGN KEY(responsible_participant_id) REFERENCES participants (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE provider_order_associations (
	order_id CHAR(32) NOT NULL, 
	tenant_id CHAR(32) NOT NULL, 
	provider_id VARCHAR(255) NOT NULL, 
	provider_tenant_id VARCHAR(255) NOT NULL, 
	source_po_id VARCHAR(255) NOT NULL, 
	source_quote_id VARCHAR(255) NOT NULL, 
	source_snapshot_hash VARCHAR(64) NOT NULL, 
	source_snapshot JSON NOT NULL, 
	execution_revision INTEGER NOT NULL DEFAULT '1', 
	execution_snapshot_hash VARCHAR(64), 
	PRIMARY KEY (order_id), 
	CONSTRAINT uq_provider_order_source UNIQUE (tenant_id, provider_id, source_po_id), 
	FOREIGN KEY(order_id) REFERENCES orders (id), 
	FOREIGN KEY(tenant_id) REFERENCES tenants (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE qc_standards (
	id CHAR(32) NOT NULL, 
	order_id CHAR(32) NOT NULL, 
	measurement_tolerance JSON, 
	fabric_defect_limits JSON, 
	stitching_standards JSON, 
	color_difference_tolerance JSON, 
	size_deviation_limits JSON, 
	washing_requirements JSON, 
	label_requirements JSON, 
	packaging_requirements JSON, 
	compliance_notes TEXT, 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	UNIQUE (order_id), 
	FOREIGN KEY(order_id) REFERENCES orders (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE rfq_recipients (
	id CHAR(32) NOT NULL, 
	rfq_id CHAR(32) NOT NULL, 
	participant_id CHAR(32) NOT NULL, 
	sent_at DATETIME(6), 
	responded_at DATETIME(6), 
	status VARCHAR(50) NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(rfq_id) REFERENCES rfqs (id), 
	FOREIGN KEY(participant_id) REFERENCES participants (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE shipments (
	id CHAR(32) NOT NULL, 
	order_id CHAR(32) NOT NULL, 
	logistics_provider_participant_id CHAR(32), 
	carrier VARCHAR(255), 
	tracking_number VARCHAR(255), 
	trade_term VARCHAR(50), 
	origin VARCHAR(255), 
	destination VARCHAR(255), 
	estimated_departure_date DATETIME(6), 
	estimated_arrival_date DATETIME(6), 
	actual_departure_date DATETIME(6), 
	actual_arrival_date DATETIME(6), 
	logistics_risk_flags JSON, 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(order_id) REFERENCES orders (id), 
	FOREIGN KEY(logistics_provider_participant_id) REFERENCES participants (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE supplier_memory_records (
	id CHAR(32) NOT NULL, 
	participant_id CHAR(32) NOT NULL, 
	order_id CHAR(32), 
	on_time_delivery BOOL, 
	qc_pass_rate FLOAT, 
	response_time_hours FLOAT, 
	price_competitiveness FLOAT, 
	notes TEXT, 
	recorded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(participant_id) REFERENCES participants (id), 
	FOREIGN KEY(order_id) REFERENCES orders (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE supplier_profile_updates (
	update_id VARCHAR(36) NOT NULL, 
	actor_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36), 
	update_type VARCHAR(64) NOT NULL, 
	previous_value_json JSON NOT NULL, 
	new_value_json JSON NOT NULL, 
	evidence_event_id VARCHAR(36), 
	created_at DATETIME(6) NOT NULL, 
	PRIMARY KEY (update_id), 
	FOREIGN KEY(actor_id) REFERENCES actors (actor_id), 
	FOREIGN KEY(project_id) REFERENCES projects (project_id), 
	FOREIGN KEY(evidence_event_id) REFERENCES actor_execution_events (event_id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE supplier_responses (
	id CHAR(32) NOT NULL, 
	rfq_id CHAR(32) NOT NULL, 
	participant_id CHAR(32) NOT NULL, 
	raw_response_text TEXT, 
	raw_response_metadata JSON, 
	received_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(rfq_id) REFERENCES rfqs (id), 
	FOREIGN KEY(participant_id) REFERENCES participants (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE uploaded_file_metadata (
	id CHAR(32) NOT NULL, 
	tenant_id CHAR(32) NOT NULL, 
	project_id CHAR(32), 
	order_id CHAR(32), 
	original_filename VARCHAR(500) NOT NULL, 
	file_type VARCHAR(100), 
	file_size_bytes INTEGER, 
	storage_reference VARCHAR(1000), 
	uploaded_by CHAR(32), 
	uploaded_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES tenants (id), 
	FOREIGN KEY(project_id) REFERENCES projects (id), 
	FOREIGN KEY(order_id) REFERENCES orders (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE expedite_alerts (
	id CHAR(32) NOT NULL, 
	order_id CHAR(32) NOT NULL, 
	monitoring_packet_id CHAR(32), 
	target_participant_id CHAR(32), 
	alert_message TEXT NOT NULL, 
	status VARCHAR(50) NOT NULL, 
	human_approved_by CHAR(32), 
	human_approved_at DATETIME(6), 
	sent_at DATETIME(6), 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(order_id) REFERENCES orders (id), 
	FOREIGN KEY(monitoring_packet_id) REFERENCES production_monitoring_packets (id), 
	FOREIGN KEY(target_participant_id) REFERENCES participants (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE production_updates (
	id CHAR(32) NOT NULL, 
	order_id CHAR(32) NOT NULL, 
	milestone_id CHAR(32), 
	update_text TEXT, 
	submitted_by_participant_id CHAR(32), 
	evidence JSON, 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(order_id) REFERENCES orders (id), 
	FOREIGN KEY(milestone_id) REFERENCES milestones (id), 
	FOREIGN KEY(submitted_by_participant_id) REFERENCES participants (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE qc_records (
	id CHAR(32) NOT NULL, 
	order_id CHAR(32) NOT NULL, 
	qc_standard_id CHAR(32), 
	inspector_participant_id CHAR(32), 
	measurement_results JSON, 
	fabric_defects JSON, 
	stitching_defects JSON, 
	color_difference JSON, 
	size_deviation JSON, 
	washing_result JSON, 
	label_compliance BOOL, 
	packaging_compliance BOOL, 
	photo_evidence_metadata JSON, 
	inspection_report_metadata JSON, 
	result VARCHAR(50) NOT NULL, 
	rework_required BOOL NOT NULL, 
	responsible_participant_id CHAR(32), 
	inspected_at DATETIME(6), 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(order_id) REFERENCES orders (id), 
	FOREIGN KEY(qc_standard_id) REFERENCES qc_standards (id), 
	FOREIGN KEY(inspector_participant_id) REFERENCES participants (id), 
	FOREIGN KEY(responsible_participant_id) REFERENCES participants (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE shipment_tracking_events (
	id CHAR(32) NOT NULL, 
	shipment_id CHAR(32) NOT NULL, 
	event_type VARCHAR(100) NOT NULL, 
	location VARCHAR(255), 
	description TEXT, 
	occurred_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(shipment_id) REFERENCES shipments (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE supplier_response_packets (
	id CHAR(32) NOT NULL, 
	supplier_response_id CHAR(32) NOT NULL, 
	unit_price FLOAT, 
	currency VARCHAR(10), 
	moq INTEGER, 
	sample_time_days INTEGER, 
	fabric_lead_time_days INTEGER, 
	trim_lead_time_days INTEGER, 
	production_time_days INTEGER, 
	qc_time_days INTEGER, 
	packaging_time_days INTEGER, 
	logistics_time_days INTEGER, 
	total_lead_time_days INTEGER, 
	payment_terms VARCHAR(255), 
	trade_terms VARCHAR(100), 
	capacity_available INTEGER, 
	valid_until DATETIME(6), 
	supplier_notes TEXT, 
	missing_fields JSON, 
	risk_flags JSON, 
	evidence_source JSON, 
	ai_generated BOOL NOT NULL, 
	human_confirmed BOOL NOT NULL, 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	UNIQUE (supplier_response_id), 
	FOREIGN KEY(supplier_response_id) REFERENCES supplier_responses (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE quality_incidents (
	id CHAR(32) NOT NULL, 
	order_id CHAR(32) NOT NULL, 
	qc_record_id CHAR(32), 
	responsible_participant_id CHAR(32) NOT NULL, 
	incident_type VARCHAR(100) NOT NULL, 
	description TEXT, 
	created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), 
	PRIMARY KEY (id), 
	FOREIGN KEY(order_id) REFERENCES orders (id), 
	FOREIGN KEY(qc_record_id) REFERENCES qc_records (id), 
	FOREIGN KEY(responsible_participant_id) REFERENCES participants (id)
)CHARSET=utf8mb4 COLLATE utf8mb4_bin;


-- Version baseline for this complete, empty-database-only schema.
CREATE TABLE alembic_version (version_num VARCHAR(32) NOT NULL PRIMARY KEY) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin;
INSERT INTO alembic_version (version_num) VALUES ('f6a7b8c9d0e1');
